"""Orchestrator - run every stage in order with CLI flags passed through."""

from __future__ import annotations

import argparse
import subprocess
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parent
STAGES = [
    ("Stage 0", "scripts/00_validate_data.py"),
    ("Stage 1", "scripts/01_extract_keywords.py"),
    ("Stage 2", "scripts/02_merge_keywords.py"),
    ("Stage 3", "scripts/03_build_autoencoder.py"),
    ("Stage 4/5", "scripts/04_rank_and_evaluate.py"),
    ("Stage 6", "scripts/05_error_analysis.py"),
    ("Stage 7a", "scripts/06_make_figures.py"),
    ("Stage 7b", "scripts/07_build_report.py"),
]


def main() -> int:
    ap = argparse.ArgumentParser(description="Run the full AI CV matching pipeline")
    ap.add_argument("--config", default="config.yaml")
    ap.add_argument("--force", action="store_true")
    ap.add_argument("--limit", type=int, default=None)
    ap.add_argument("--model", default=None)
    ap.add_argument("--stage", type=int, default=None, help="run only this stage number (0-7)")
    ap.add_argument("--skip-llm", action="store_true", help="reuse the LLM cache without re-calling")
    args = ap.parse_args()

    cfg_path = str((ROOT / args.config) if not Path(args.config).is_absolute() else Path(args.config))

    failed: list[str] = []
    for i, (label, script) in enumerate(STAGES):
        if args.stage is not None and i != args.stage:
            continue
        cmd = [sys.executable, str(ROOT / script), "--config", cfg_path]
        if args.force and script != "scripts/07_build_report.py":
            cmd.append("--force")
        if args.limit and script in {"scripts/01_extract_keywords.py"}:
            cmd += ["--limit", str(args.limit)]
        if args.model and script == "scripts/01_extract_keywords.py":
            cmd += ["--model", args.model]

        print("\n" + "=" * 78)
        print(f"{label}: {' '.join(cmd)}")
        print("=" * 78, flush=True)
        t0 = time.time()
        result = subprocess.run(cmd, cwd=str(ROOT))
        print(f"{label} finished in {time.time() - t0:.1f}s with exit code {result.returncode}", flush=True)
        if result.returncode != 0:
            failed.append(label)
            if script != "scripts/07_build_report.py":
                print(f"Stopping: {label} failed.", flush=True)
                return result.returncode

    if failed:
        print(f"\nCompleted with problems in: {', '.join(failed)}")
        return 1
    print("\nAll stages completed.")
    print('Run the website with: py -m streamlit run "app.py"')
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
