"""Page 1 - Overview: dataset, pipeline, headline metrics."""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.overview import render  # noqa: E402
from src.web import apply_style, footer, sidebar  # noqa: E402

st.set_page_config(page_title="AI CV Matching — Baseline", layout="wide")
apply_style()
sidebar()
render()
footer()
