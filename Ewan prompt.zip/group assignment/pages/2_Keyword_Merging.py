"""Page 2 - keyword extraction and merging, made readable to a non-technical viewer."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.web import (  # noqa: E402
    FIGURES,
    OKABE_SEQUENCE,
    PALETTE,
    PROCESSED,
    apply_style,
    caption,
    footer,
    load_csv,
    load_extracted,
    load_json,
    metric_card,
    note,
    require,
    sidebar,
    warn,
)

st.set_page_config(page_title="AI CV Matching — Keyword merging", layout="wide")
apply_style()
sidebar()

st.title("Keyword extraction and merging")
st.markdown(
    "The local LLM turns each free-text CV/JD into structured keywords. Those keywords are then normalised and "
    "merged into canonical clusters so that `JS`, `JavaScript` and `Java Script` count as one concept — while "
    "`Java` and `JavaScript` stay apart."
)

ok = require(
    [
        PROCESSED / "keyword_clusters.csv",
        PROCESSED / "keyword_aliases.csv",
        PROCESSED / "keyword_table.csv",
        PROCESSED / "cluster_metrics.json",
    ],
    'py "scripts/02_merge_keywords.py" --config "config.yaml"',
)
if not ok:
    st.stop()

clusters = load_csv("keyword_clusters.csv")
aliases = load_csv("keyword_aliases.csv")
kw_table = load_csv("keyword_table.csv")
metrics = load_json("cluster_metrics.json")
edges = load_csv("keyword_edges.csv")
extracted = load_extracted()

# ------------------------------------------------------------------ summary
st.markdown("### How much did the merge do?")
c1, c2, c3, c4, c5 = st.columns(5)
metric_card(c1, "Raw keywords", f"{metrics['n_keywords_all']:,}", "distinct normalised terms")
metric_card(c2, "Canonical clusters", f"{metrics['n_clusters']}", f"fit on {metrics['n_keywords_train']:,} training terms")
metric_card(c3, "Alias entries", f"{metrics['n_aliases']}", f"{metrics['n_canonical_terms']} canonical concepts")
metric_card(c4, "Mapping coverage", f"{metrics['keyword_to_cluster_coverage']:.1%}", "keywords mapped to a cluster")
metric_card(c5, "Merge review", f"{metrics['manual_merge_review']['accuracy']:.0%}", f"{metrics['manual_merge_review']['n_reviewed']} sampled decisions")

caption(
    f"Embedding method: `{metrics['embedding_method']}` ({metrics['embedding_notes']}). "
    f"Clustering: `{metrics['cluster_method']}`. Held-out unmatched keyword rate: "
    f"{metrics['heldout_unmatched_rate']:.1%}."
)

st.divider()

# --------------------------------------------------------- document viewer
st.markdown("### 1 · What the LLM extracted from one document")
col_a, col_b = st.columns([1, 1])
with col_a:
    doc_type = st.radio("Document type", ["CV", "JD"], horizontal=True, key="kw_doctype")
with col_b:
    if doc_type == "CV":
        options = sorted([d for d, r in extracted.items() if r["doc_type"] in {"pool_cv", "gt_cv"}])
    else:
        options = sorted([d for d, r in extracted.items() if r["doc_type"] in {"gt_jd", "unlabelled_jd"}])
    doc_id = st.selectbox("Document", options, index=0)

record = extracted[doc_id]
payload = record["payload"]

left, right = st.columns([1, 1.15])
with left:
    st.markdown(f"**Source text** — `{doc_id}` · {' · '.join([str(record['title']), str(record['role_family'])])}")
    st.text_area("document excerpt", record.get("source_path", "") + "\n\n(see data/processed/documents.jsonl)", height=80, disabled=True, label_visibility="collapsed")

    # show the actual raw text excerpt
    from src.web import load_jsonl_cached

    docs = {r["doc_id"]: r for r in load_jsonl_cached(str(PROCESSED / "documents.jsonl"))}
    raw = docs.get(doc_id, {}).get("raw_text", "")
    st.text_area("document text (first 1500 characters)", raw[:1500], height=380, disabled=True)

with right:
    st.markdown("**Extracted fields**")
    field_labels = {
        "must_have_keywords": ("Must-have (JD)", PALETTE["coral"]),
        "nice_to_have_keywords": ("Nice-to-have (JD)", PALETTE["orange"]),
        "tools_technologies": ("Tools / technologies", PALETTE["blue"]),
        "skills": ("Skills (CV)", PALETTE["hit"]),
        "domains": ("Domains", PALETTE["sky"]),
        "domain_knowledge": ("Domain knowledge", PALETTE["sky"]),
        "soft_skills": ("Soft skills", PALETTE["neutral"]),
        "certifications": ("Certifications", PALETTE["grey"]),
        "languages": ("Languages", PALETTE["grey"]),
        "locations": ("Locations", PALETTE["grey"]),
    }
    shown = False
    for field, (label, colour) in field_labels.items():
        values = payload.get(field) or []
        if not values:
            continue
        shown = True
        chips = "".join(
            f'<span class="badge" style="background:{colour}1A;color:{colour};margin:2px 3px 2px 0;">{v}</span>'
            for v in values
        )
        st.markdown(f"<div style='font-size:0.8rem;color:#5A6B82;margin-top:6px'>{label}</div>{chips}", unsafe_allow_html=True)
    if not shown:
        warn("No keywords extracted for this document.")

    st.markdown(
        f"<div style='font-size:0.8rem;color:#5A6B82;margin-top:10px'>"
        f"status <b>{record.get('status')}</b> · model <b>{record.get('model')}</b> · "
        f"{record.get('n_dropped_keywords', 0)} unsupported keywords dropped</div>",
        unsafe_allow_html=True,
    )

st.divider()

# ------------------------------------------------------------ keyword table
st.markdown("### 2 · Search the keyword table")
st.markdown("Every distinct normalised keyword, its canonical cluster, cluster size and document frequency.")
search = st.text_input("Filter keywords (substring)", "")
cl = clusters.set_index("cluster_id")
tbl = kw_table.copy()
tbl["cluster_label"] = tbl["cluster_id"].map(lambda c: cl.loc[c, "canonical_label"] if c in cl.index and pd.notna(c) else "(unmapped)")
tbl["cluster_size"] = tbl["cluster_id"].map(lambda c: cl.loc[c, "size"] if c in cl.index and pd.notna(c) else 0)
if search:
    mask = (
        tbl["keyword"].str.contains(search, case=False, na=False)
        | tbl["cluster_label"].str.contains(search, case=False, na=False)
    )
    tbl = tbl[mask]
st.dataframe(
    tbl[["keyword", "cluster_label", "cluster_size", "doc_frequency", "total_frequency", "doc_types"]]
    .sort_values(["doc_frequency"], ascending=False)
    .head(400)
    .rename(
        columns={
            "keyword": "raw term",
            "cluster_label": "canonical cluster",
            "cluster_size": "cluster size",
            "doc_frequency": "doc frequency",
            "total_frequency": "total frequency",
            "doc_types": "doc types",
        }
    ),
    hide_index=True,
    height=340,
    width='stretch',
)
caption("Document frequency counts training documents only (the primary protocol); `*_all` columns in the CSV cover the full corpus.")

st.divider()

# -------------------------------------------------------- cluster explorer
st.markdown("### 3 · Explore a cluster")
labels = clusters.sort_values("doc_frequency", ascending=False)["canonical_label"].tolist()
pick = st.selectbox("Cluster (sorted by document frequency)", labels, index=0)
row = clusters[clusters["canonical_label"] == pick].iloc[0]
c1, c2, c3, c4 = st.columns(4)
metric_card(c1, "Members", f"{int(row['size'])}", "merged raw variants")
metric_card(c2, "Document frequency", f"{int(row['doc_frequency'])}", "training documents")
metric_card(c3, "Total frequency", f"{int(row['total_frequency'])}", "occurrences")
metric_card(c4, "Coherence", f"{row['coherence']:.2f}", "mean pairwise cosine")

st.markdown(
    "**Members:** " + " · ".join(f"`{m}`" for m in str(row["members"]).split("|"))
)
if row.get("definition"):
    st.markdown(f"**Definition:** {row['definition']}")
caption(f"Merge method: {row['merge_method']} · confidence: {row['confidence']}")

with st.expander("All clusters (sortable)"):
    st.dataframe(
        clusters[["cluster_id", "canonical_label", "size", "doc_frequency", "total_frequency", "coherence", "merge_method"]],
        hide_index=True,
        height=340,
        width='stretch',
    )

st.divider()

# ------------------------------------------------------------ network graph
st.markdown("### 4 · Cluster co-occurrence network")
st.markdown(
    "Two clusters are linked when they appear together in at least two documents. Big nodes are frequent concepts; "
    "the layout groups concepts that tend to be required together."
)


@st.cache_data(show_spinner=False)
def _network_layout(n_nodes: int) -> pd.DataFrame:
    import networkx as nx

    G = nx.Graph()
    for _, r in clusters.iterrows():
        G.add_node(int(r["cluster_id"]), label=r["canonical_label"], dfreq=float(r["doc_frequency"]), coh=float(r["coherence"]))
    label_to_id = {r["canonical_label"]: int(r["cluster_id"]) for _, r in clusters.iterrows()}
    for _, e in edges.iterrows():
        a, b = label_to_id.get(e["source"]), label_to_id.get(e["target"])
        if a is not None and b is not None and a != b:
            G.add_edge(a, b, weight=float(e["weight"]))
    if G.number_of_nodes() == 0:
        return pd.DataFrame()
    pos = nx.spring_layout(G, seed=42, k=0.55, iterations=80)
    rows = []
    for n in G.nodes():
        rows.append(
            {
                "cluster_id": n,
                "label": G.nodes[n]["label"],
                "x": pos[n][0],
                "y": pos[n][1],
                "dfreq": G.nodes[n]["dfreq"],
                "coh": G.nodes[n]["coh"],
            }
        )
    df = pd.DataFrame(rows)
    edge_rows = [{"a": a, "b": b, "weight": d["weight"]} for a, b, d in G.edges(data=True)]
    return df, pd.DataFrame(edge_rows)


layout = _network_layout(0)
fig = go.Figure()
if isinstance(layout, tuple) and len(layout) == 2 and not layout[0].empty:
    nodes_df, edges_df = layout
    pos = nodes_df.set_index("cluster_id")[["x", "y"]]
    xs, ys = [], []
    for _, e in edges_df.iterrows():
        if e["a"] in pos.index and e["b"] in pos.index:
            xs += [pos.loc[e["a"], "x"], pos.loc[e["b"], "x"], None]
            ys += [pos.loc[e["a"], "y"], pos.loc[e["b"], "y"], None]
    fig.add_trace(go.Scattergl(x=xs, y=ys, mode="lines", line=dict(color="#CBD5E1", width=0.7), hoverinfo="skip", showlegend=False))
    sizes = 8 + 26 * (nodes_df["dfreq"] / nodes_df["dfreq"].max())
    fig.add_trace(
        go.Scattergl(
            x=nodes_df["x"],
            y=nodes_df["y"],
            mode="markers+text",
            text=[l if d >= nodes_df["dfreq"].quantile(0.85) else "" for l, d in zip(nodes_df["label"], nodes_df["dfreq"])],
            textposition="top center",
            textfont=dict(size=8, color="#0B2545"),
            marker=dict(
                size=sizes,
                color=nodes_df["coh"],
                colorscale="Viridis",
                showscale=True,
                colorbar=dict(title="coherence", thickness=10, len=0.5),
                line=dict(width=0.5, color="white"),
            ),
            customdata=[
                [l, d, c, len(edges_df[(edges_df["a"] == cid) | (edges_df["b"] == cid)])]
                for cid, l, d, c in zip(nodes_df["cluster_id"], nodes_df["label"], nodes_df["dfreq"], nodes_df["coh"])
            ],
            hovertemplate="<b>%{customdata[0]}</b><br>doc frequency %{customdata[1]:.0f}<br>coherence %{customdata[3]:.2f}<extra></extra>",
            showlegend=False,
        )
    )
    fig.update_layout(
        height=600,
        margin=dict(l=0, r=0, t=10, b=0),
        xaxis=dict(visible=False),
        yaxis=dict(visible=False),
        plot_bgcolor="white",
        paper_bgcolor="white",
    )
    st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    caption("Hover a node for its label, document frequency and coherence. Only the top ~15% most frequent labels are drawn.")
else:
    st.info("No edges with weight >= 2 were found.")

png = FIGURES / "03_keyword_cluster_network.png"
if png.is_file():
    with st.expander("Static version (results/figures/03_keyword_cluster_network.png)"):
        st.image(str(png), width='stretch')

st.divider()

# -------------------------------------------------------- merge quality
st.markdown("### 5 · Merge quality and guardrails")
c1, c2, c3 = st.columns(3)
metric_card(c1, "Singleton rate", f"{metrics['singleton_rate']:.2f}", "clusters with one member")
metric_card(c2, "Mean coherence", f"{metrics['mean_coherence']:.2f}", "mean pairwise cosine")
metric_card(c3, "Silhouette (cosine)", f"{metrics['silhouette_cosine']:.3f}" if metrics.get("silhouette_cosine") is not None else "n/a", "descriptive only")

st.markdown("**Guardrails — these concepts must never be merged:**")
g_rows = []
for pair, v in metrics["guardrails"].items():
    g_rows.append(
        {
            "pair": pair,
            "status": "PASS" if not v["merged"] else "FAIL",
            "cluster_a": ", ".join(map(str, v["clusters_a"])) or "-",
            "cluster_b": ", ".join(map(str, v["clusters_b"])) or "-",
        }
    )
gdf = pd.DataFrame(g_rows)
st.dataframe(gdf, hide_index=True, width='stretch')
if (gdf["status"] == "FAIL").any():
    warn("At least one confusable pair shares a cluster — inspect keyword_clusters.csv.")
else:
    note("All guardrail pairs are separated: Java/JavaScript, C/C++, C#/C++, SQL/NoSQL, WMS/OMS, UI/UX, Azure/AWS, Power BI/Tableau.")

with st.expander("Manual merge review (30 sampled decisions)"):
    review = load_csv("manual_merge_review.csv")
    st.dataframe(review.rename(columns={"term_a": "term A", "term_b": "term B"}), hide_index=True, width='stretch')
    caption(
        f"{metrics['manual_merge_review']['n_correct']} of {metrics['manual_merge_review']['n_reviewed']} decisions "
        f"correct (accuracy {metrics['manual_merge_review']['accuracy']:.0%})."
    )

with st.expander("Cluster QA table (largest 20 and lowest-coherence 20)"):
    st.dataframe(load_csv("cluster_qa.csv"), hide_index=True, width='stretch')

for name, title in (
    ("04_keyword_cluster_sizes.png", "30 largest clusters"),
    ("05_keyword_merge_examples.png", "Raw variants → canonical labels"),
    ("05b_keyword_coverage_heatmap.png", "Top clusters × role family"),
):
    p = FIGURES / name
    if p.is_file():
        with st.expander(f"Figure: {title}"):
            st.image(str(p), width='stretch')

footer()
