"""Page 4 - the recruiter view: pick a JD, pick a model, see the top 10."""

from __future__ import annotations

import json
import sys
from pathlib import Path

import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.web import (  # noqa: E402
    PALETTE,
    PROCESSED,
    TABLES,
    apply_style,
    caption,
    footer,
    load_csv,
    load_extracted,
    load_json,
    metric_card,
    note,
    require,
    sidebar,
    warn,
)

st.set_page_config(page_title="AI CV Matching — Search results", layout="wide")
apply_style()
sidebar()

st.title("Search results")
st.markdown(
    "Pick a job description and a ranking model. The hired (ground-truth) candidate is highlighted. "
    "Reasons are generated from a deterministic template, not by an LLM, so they are reproducible."
)

ok = require(
    [PROCESSED / "top10.csv", PROCESSED / "rankings.csv", PROCESSED / "ground_truth.csv"],
    'py "scripts/04_rank_and_evaluate.py" --config "config.yaml"',
)
if not ok:
    st.stop()

top10 = load_csv("top10.csv")
rankings = load_csv("rankings.csv")
gt = load_csv("ground_truth.csv", keep_default_na=False, na_values=[""])
extracted = load_extracted()
summary = load_csv("metrics_summary.csv")
keyword_to_cluster = {k: int(v) for k, v in json.loads((PROCESSED / "keyword_to_cluster.json").read_text()).items()}

MODEL_LABELS = {
    "M3": "M3 · AE-32 cosine (primary)",
    "M1": "M1 · TF-IDF keyword cosine",
    "M2": "M2 · SVD-32 cosine",
    "M4": "M4 · AE + metadata",
    "M5": "M5 · Hybrid AE + must-have (exploratory)",
    "M6": "M6 · Role-family heuristic (exploratory)",
    "M0": "M0 · Random (floor baseline)",
}

c1, c2 = st.columns([1.2, 1])
with c1:
    jd_choices = [f"{r['jd_id']} · {r['jd_title']}" for _, r in gt.iterrows()]
    jd_pick = st.selectbox("Job description", jd_choices, index=0)
    jd_id = jd_pick.split(" · ")[0]
with c2:
    model_pick = st.selectbox("Ranking model", list(MODEL_LABELS), format_func=lambda k: MODEL_LABELS[k], index=0)

g = gt[gt["jd_id"] == jd_id].iloc[0]
jd_payload = extracted[jd_id]["payload"]

# --------------------------------------------------------------- JD summary
st.markdown(f"### {g['jd_title']}")
c1, c2, c3, c4 = st.columns(4)
metric_card(c1, "Role family", str(g["role_family"]), "JD metadata")
metric_card(c2, "Location", str(g["jd_location"]) if pd.notna(g["jd_location"]) else "not stated", "baseline ignores this")
metric_card(c3, "Salary", str(g["jd_salary"]) if pd.notna(g["jd_salary"]) else "not stated", "baseline ignores this")
metric_card(c4, "Seniority", str(jd_payload.get("seniority") or "unknown"), f"min years: {jd_payload.get('min_years_experience') or 'n/a'}")

with st.expander("Top must-have keywords for this JD", expanded=True):
    musts = jd_payload.get("must_have_keywords") or []
    nices = jd_payload.get("nice_to_have_keywords") or []
    if musts:
        st.markdown(
            "".join(
                f'<span class="badge" style="background:{PALETTE["coral"]}1A;color:{PALETTE["coral"]};margin:2px 4px 2px 0;font-size:0.78rem">{m}</span>'
                for m in musts
            ),
            unsafe_allow_html=True,
        )
    else:
        warn("No must-have keywords extracted for this JD.")
    if nices:
        st.markdown(
            "".join(
                f'<span class="badge" style="background:{PALETTE["orange"]}1A;color:{PALETTE["orange"]};margin:2px 4px 2px 0;font-size:0.78rem">{m}</span>'
                for m in nices
            ),
            unsafe_allow_html=True,
        )
    caption("Red = must-have, orange = nice-to-have. Extracted by the local LLM and grounded against the source text.")

st.divider()

# --------------------------------------------------------------- results
sub = top10[(top10["model"] == model_pick) & (top10["jd_id"] == jd_id)].sort_values("rank")
hired_id = g["hired_cv_id"]
hired_row = rankings[(rankings["model"] == model_pick) & (rankings["jd_id"] == jd_id) & (rankings["cv_id"] == hired_id)].iloc[0]
s = summary[summary["model"] == model_pick].iloc[0]

c1, c2, c3, c4 = st.columns(4)
metric_card(c1, "Hired CV rank", f"#{int(hired_row['rank'])}", "ground truth position")
metric_card(c2, "Hired CV score", f"{hired_row['score']:.4f}", f"top-1: {sub.iloc[0]['score']:.4f}")
metric_card(c3, "Model recall@10", f"{s['recall_at_10']:.2f}", f"{int(s['hits'])}/10 across all JDs")
metric_card(c4, "Ranking pool", f"{len(rankings[(rankings['model'] == model_pick) & (rankings['jd_id'] == jd_id)])}", "candidates scored")

if int(hired_row["rank"]) <= 10:
    note(f"Hired candidate **{hired_id}** appears at rank **{int(hired_row['rank'])}** in the top 10.")
else:
    warn(
        f"Hired candidate **{hired_id}** ranked **#{int(hired_row['rank'])}** with score "
        f"{hired_row['score']:.4f} — outside the top 10 for this model. "
        f"Top-1 was {sub.iloc[0]['cv_id']} at {sub.iloc[0]['score']:.4f}."
    )

st.markdown("### Top 10")
disp = sub.copy()
disp["rank"] = disp["rank"].astype(int)
disp["badge"] = disp["is_relevant"].map({1: "HIRED (ground truth)", 0: ""})
disp["score"] = disp["score"].round(4)
disp["must_have"] = disp["must_have_matches"].astype(int)

st.dataframe(
    disp[["rank", "cv_id", "cv_title", "cv_company", "role_family", "score", "must_have", "badge", "reason"]].rename(
        columns={
            "rank": "Rank",
            "cv_id": "CV",
            "cv_title": "Current title",
            "cv_company": "Company",
            "role_family": "Role family",
            "score": "Score",
            "must_have": "Must-have hits",
            "badge": "",
            "reason": "Reason",
        }
    ),
    hide_index=True,
    width='stretch',
    column_config={
        "Score": st.column_config.NumberColumn(format="%.4f"),
        "Reason": st.column_config.TextColumn(width="large"),
    },
)
caption("Rows are ordered by score descending, ties broken by CV ID. The hired CV is the only relevant label for this JD.")

# -------------------------------------------------------- candidate detail
st.markdown("### Candidate detail")
pick = st.selectbox("Candidate", disp["cv_id"].tolist(), index=0)
row = disp[disp["cv_id"] == pick].iloc[0]
cv_payload = extracted[pick]["payload"]

c1, c2 = st.columns([1, 1])
with c1:
    st.markdown(
        f"**{cv_payload.get('current_title') or 'unknown title'}** at "
        f"**{cv_payload.get('current_company') or 'unknown company'}**"
    )
    st.markdown(
        f"Years: `{cv_payload.get('total_years_experience') or 'unknown'}` · "
        f"Seniority: `{cv_payload.get('seniority') or 'unknown'}` · "
        f"Role family: `{extracted[pick]['role_family']}` · "
        f"Locations: `{', '.join(cv_payload.get('locations') or []) or 'unknown'}`"
    )
    skills = (cv_payload.get("skills") or []) + (cv_payload.get("tools_technologies") or [])
    chips = "".join(
        f'<span class="badge" style="background:{PALETTE["blue"]}14;color:{PALETTE["blue"]};margin:2px 3px 2px 0">{s0}</span>'
        for s0 in skills[:32]
    )
    st.markdown(f"<div style='margin-top:8px'>{chips}</div>", unsafe_allow_html=True)

with c2:
    n_match = int(row["must_have_matches"])
    n_total = len(jd_payload.get("must_have_keywords") or [])
    st.markdown(f"**Must-have coverage:** {n_match}/{n_total or '?'}")
    if n_total:
        st.progress(min(1.0, n_match / max(1, n_total)))
    missing = str(row["missing_must_haves"] or "")
    if missing:
        st.markdown(f"**Missing:** {missing}")
    st.markdown("**Reason (template):**")
    st.info(str(row["reason"]))
    if row.get("filter_note"):
        warn(f"Visible hard-filter mismatch the baseline does **not** apply: {row['filter_note']}")

st.divider()

# --------------------------------------------------------------- downloads
st.markdown("### Download")
c1, c2, c3 = st.columns(3)
c1.download_button(
    "Top 10 for this model + JD (CSV)",
    data=sub.to_csv(index=False).encode("utf-8"),
    file_name=f"top10_{model_pick}_{jd_id}.csv",
    mime="text/csv",
)
full = rankings[(rankings["model"] == model_pick) & (rankings["jd_id"] == jd_id)].sort_values("rank")
c2.download_button(
    "Full ranking for this model + JD (CSV)",
    data=full.to_csv(index=False).encode("utf-8"),
    file_name=f"rankings_{model_pick}_{jd_id}.csv",
    mime="text/csv",
)
c3.download_button(
    "All top-10 rows (CSV)",
    data=top10.to_csv(index=False).encode("utf-8"),
    file_name="top10_all.csv",
    mime="text/csv",
)

note(
    "The baseline does not apply salary, notice-period, location or language filters. "
    "A candidate can therefore appear here who a recruiter would rule out on those grounds."
)

footer()
