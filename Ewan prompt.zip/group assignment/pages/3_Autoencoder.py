"""Page 3 - the autoencoder: what it is, how it trained, whether it learned anything useful."""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.web import (  # noqa: E402
    FIGURES,
    MODELS,
    OKABE_SEQUENCE,
    PALETTE,
    PROCESSED,
    TABLES,
    apply_style,
    caption,
    footer,
    load_csv,
    load_json,
    metric_card,
    note,
    require,
    sidebar,
    warn,
)

st.set_page_config(page_title="AI CV Matching — Autoencoder", layout="wide")
apply_style()
sidebar()

st.title("The autoencoder")
st.markdown(
    "The AE compresses each document's weighted keyword-cluster profile into a 32-dimensional vector, then "
    "reconstructs the profile. Both CVs and JDs go through the same encoder, so a cosine similarity between a JD "
    "vector and a CV vector is meaningful. It is trained **without** the 10 labelled JDs and 10 hired CVs."
)

ok = require(
    [
        PROCESSED / "document_embeddings.csv",
        PROCESSED / "ae_reconstruction.csv",
        MODELS / "autoencoder_config.json",
        MODELS / "ae_training_history.csv",
        PROCESSED / "ae_ablation.csv",
    ],
    'py "scripts/03_build_autoencoder.py" --config "config.yaml"',
)
if not ok:
    st.stop()

ae = load_json("autoencoder_config.json", "models")
emb = load_csv("document_embeddings.csv")
recon = load_csv("ae_reconstruction.csv")
history = load_csv("ae_training_history.csv", subdir="processed") if (PROCESSED / "ae_training_history.csv").is_file() else pd.read_csv(MODELS / "ae_training_history.csv")
ablation = load_csv("ae_ablation.csv")
gt = load_csv("ground_truth.csv", keep_default_na=False, na_values=[""])

# --------------------------------------------------------------- config cards
st.markdown("### Training configuration")
c1, c2, c3, c4, c5 = st.columns(5)
metric_card(c1, "Input dim", f"{ae['input_dim']}", "keyword clusters")
metric_card(c2, "Latent dim", f"{ae['latent_dim']}", "bottleneck")
metric_card(c3, "Best epoch", f"{ae['best_epoch']}", f"of {ae['epochs_run']} run")
metric_card(c4, "Validation MSE", f"{ae['val_mse']:.2e}", "reconstruction loss")
metric_card(c5, "Train / val docs", f"{ae['n_train']}/{ae['n_val']}", "85/15 split")

st.markdown(
    f"""
| Setting | Value |
|---|---|
| Architecture | `{ae['architecture']}` |
| Hidden dims | `{ae['hidden_dims']}` |
| Dropout | `{ae['dropout']}` |
| Denoising | `{ae['denoising']}` |
| Loss | mean squared error on the TF-IDF cluster profile |
| Optimizer | Adam, lr 1e-3, weight decay 1e-4, gradient clipping 1.0 |
| Early stopping | patience 40 on validation MSE |
| Training corpus | {ae['training_corpus']} |
| Selected by | {ae['selected_by']} |
| Cluster method | `{ae['cluster_method']}` |
| Vectorizer hash | `{ae['vectorizer_hash']}` |
| NaNs during training | `{ae['nan_seen']}` · dead latent units: `{ae['dead_units']}` |
"""
)

img = FIGURES / "06_ae_architecture.png"
if img.is_file():
    st.image(str(img), width='stretch')
    caption("Encoder: input → 256 → 64 → 32. Decoder mirrors it. GELU activation, dropout 0.2 after each hidden layer.")

st.divider()

# -------------------------------------------------------------- loss curves
st.markdown("### Training behaviour")
left, right = st.columns([1.35, 1])
with left:
    fig = go.Figure()
    fig.add_trace(go.Scatter(x=history["epoch"], y=history["train_mse"], name="train MSE", line=dict(color=PALETTE["blue"], width=2)))
    fig.add_trace(go.Scatter(x=history["epoch"], y=history["val_mse"], name="validation MSE", line=dict(color=PALETTE["miss"], width=2)))
    fig.add_vline(x=ae["best_epoch"], line_dash="dash", line_color=PALETTE["hit"], annotation_text=f"best epoch {ae['best_epoch']}", annotation_font_size=10)
    fig.update_layout(
        height=380,
        xaxis_title="epoch",
        yaxis_title="MSE (log scale)",
        yaxis_type="log",
        margin=dict(l=10, r=10, t=20, b=10),
        legend=dict(orientation="h", y=1.05),
    )
    st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    caption("Validation loss bottoms out early and then flattens: with ~150 training documents, capacity is not the constraint.")
with right:
    st.markdown("**Ablation (selected by validation MSE only)**")
    st.dataframe(
        ablation.rename(
            columns={
                "latent_dim": "latent",
                "dropout": "dropout",
                "denoising": "denoise",
                "train_mse": "train MSE",
                "val_mse": "val MSE",
                "best_epoch": "best epoch",
                "epochs_run": "epochs",
                "nan_seen": "NaN",
            }
        ),
        hide_index=True,
        width='stretch',
        height=330,
    )
    caption("Never selected on test recall — that would be test-set tuning.")

st.divider()

# ------------------------------------------------------ reconstruction error
st.markdown("### Reconstruction quality")
left, right = st.columns(2)
with left:
    fig = px.histogram(
        recon,
        x="reconstruction_mse",
        color="doc_type",
        barmode="overlay",
        nbins=26,
        opacity=0.7,
        color_discrete_sequence=OKABE_SEQUENCE,
        labels={"reconstruction_mse": "per-document reconstruction MSE", "doc_type": "document type"},
    )
    fig.update_layout(height=340, margin=dict(l=10, r=10, t=20, b=10), legend=dict(orientation="h", y=1.08))
    st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    caption("Held-out documents (hired CVs, GT JDs) reconstruct less accurately than training documents — expected.")
with right:
    st.markdown("**AE vs SVD / PCA on the same matrix**")
    p = TABLES / "ae_vs_svd.csv"
    if p.is_file():
        st.dataframe(
            load_csv("ae_vs_svd.csv", subdir="tables").rename(
                columns={
                    "model": "model",
                    "reconstruction_mse": "reconstruction MSE",
                    "mean_cosine_reconstruction": "mean cosine reconstruction",
                    "explained_variance": "explained variance",
                    "n_components": "components",
                }
            ),
            hide_index=True,
            width='stretch',
        )
        caption("The AE is not automatically better than SVD at reconstruction; the AE's value is the non-linear bottleneck, if any.")
    st.markdown("**Per-document reconstruction**")
    st.dataframe(
        recon.sort_values("reconstruction_mse", ascending=False)
        .head(12)[["doc_id", "doc_type", "split", "reconstruction_mse", "cosine_reconstruction"]]
        .rename(
            columns={
                "doc_id": "doc",
                "doc_type": "type",
                "split": "split",
                "reconstruction_mse": "MSE",
                "cosine_reconstruction": "cosine",
            }
        ),
        hide_index=True,
        width='stretch',
    )

png = FIGURES / "08b_ae_reconstruction_examples.png"
if png.is_file():
    with st.expander("Figure: top-10 clusters, input vs reconstruction"):
        st.image(str(png), width='stretch')

st.divider()

# ---------------------------------------------------------- latent space
st.markdown("### Latent space")
st.markdown(
    "Interactive PCA projection. Hover for the document, title and role family. "
    "Lines connect each labelled JD to the CV that was actually hired for it."
)

dims = [c for c in emb.columns if c.startswith("dim_")]


@st.cache_data(show_spinner=False)
def project(method: str) -> pd.DataFrame:
    from sklearn.decomposition import PCA

    X = emb[dims].to_numpy()
    if method == "PCA":
        coords = PCA(n_components=2, random_state=42).fit_transform(X)
    else:
        try:
            import umap  # type: ignore

            coords = umap.UMAP(n_neighbors=12, min_dist=0.15, random_state=42).fit_transform(X)
        except Exception:
            from sklearn.manifold import TSNE

            coords = TSNE(
                n_components=2, perplexity=min(20, max(5, len(X) // 8)), random_state=42, init="pca"
            ).fit_transform(X)
    out = emb.copy()
    out["x"] = coords[:, 0]
    out["y"] = coords[:, 1]
    return out


tab_pca, tab_manifold = st.tabs(["PCA (2D)", "UMAP / t-SNE (2D)"])
for tab, method in ((tab_pca, "PCA"), (tab_manifold, "UMAP")):
    with tab:
        proj = project(method)
        colour_by = st.radio("Colour by", ["doc_type", "role_family"], horizontal=True, key=f"colour_{method}")
        show_links = st.checkbox("Show the 10 ground-truth pair links", value=True, key=f"links_{method}")
        fig = go.Figure()
        if show_links:
            pos = proj.set_index("doc_id")
            for _, r in gt.iterrows():
                if r["jd_id"] in pos.index and r["hired_cv_id"] in pos.index:
                    fig.add_trace(
                        go.Scatter(
                            x=[pos.loc[r["jd_id"], "x"], pos.loc[r["hired_cv_id"], "x"]],
                            y=[pos.loc[r["jd_id"], "y"], pos.loc[r["hired_cv_id"], "y"]],
                            mode="lines",
                            line=dict(color=PALETTE["coral"], width=1.1),
                            hoverinfo="skip",
                            showlegend=False,
                        )
                    )
        for i, (k, grp) in enumerate(proj.groupby(colour_by)):
            fig.add_trace(
                go.Scatter(
                    x=grp["x"],
                    y=grp["y"],
                    mode="markers",
                    name=str(k),
                    marker=dict(size=7, color=OKABE_SEQUENCE[i % len(OKABE_SEQUENCE)], opacity=0.85, line=dict(width=0.5, color="white")),
                    text=grp["doc_id"] + " · " + grp["title"].fillna("") + " · " + grp["role_family"].fillna(""),
                    hoverinfo="text",
                )
            )
        fig.update_layout(
            height=560,
            margin=dict(l=10, r=10, t=20, b=10),
            xaxis_title="component 1",
            yaxis_title="component 2",
            legend=dict(orientation="v", x=1.01, y=1),
            plot_bgcolor="white",
        )
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
        caption("Separation by role family is the visual test of whether the AE learned something structural.")

st.divider()

# ---------------------------------------------------------------- meaning
st.markdown("### What this means")
st.markdown(
    f"""
- **Does it reconstruct?** Train MSE {ae['train_mse']:.2e} vs validation MSE {ae['val_mse']:.2e}. The gap of
  {ae['val_gap']:.2e} reflects a small corpus (~150 documents), not a bug.
- **Does it separate role families?** Inspect the role-family colouring above. Overlap between `Engineering`,
  `Data & AI` and `Product` is expected because their keyword profiles genuinely overlap.
- **Is the GT pair close?** The coral lines connect each JD to its hired CV. Short lines are good evidence; long
  lines explain misses.
- **Caveat.** Reconstruction is **not** ranking. A low reconstruction error means the bottleneck preserves the
  cluster profile, not that it orders candidates the way a recruiter would.
- **Held-out keywords.** Keywords from held-out documents that could not be mapped to a training cluster were
  excluded, so rare must-have skills can be invisible to the AE. This is a real failure mode, not an
  implementation detail.
"""
)

for name, title in (
    ("07_ae_loss_curves.png", "Loss curves"),
    ("08_ae_reconstruction_error.png", "Reconstruction error by type"),
    ("09_latent_space_pca.png", "PCA with GT pair links"),
):
    p = FIGURES / name
    if p.is_file():
        with st.expander(f"Figure: {title}"):
            st.image(str(p), width='stretch')

footer()
