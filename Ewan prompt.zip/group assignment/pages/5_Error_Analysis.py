"""Page 5 - recall, failure taxonomy, case studies, recommendations, limitations."""

from __future__ import annotations

import sys
from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from src.web import (  # noqa: E402
    FIGURES,
    OKABE_SEQUENCE,
    PALETTE,
    PROCESSED,
    RESULTS,
    TABLES,
    apply_style,
    caption,
    footer,
    load_csv,
    load_extracted,
    load_json,
    metric_card,
    note,
    require,
    sidebar,
    warn,
)

st.set_page_config(page_title="AI CV Matching — Recall & errors", layout="wide")
apply_style()
sidebar()

st.title("Recall and error analysis")
st.markdown(
    "This page makes the evaluation impossible to misread: exactly one relevant CV per query, n = 10, "
    "wide confidence intervals, and every miss categorised with evidence."
)

ok = require(
    [
        PROCESSED / "metrics_summary.csv",
        PROCESSED / "metrics_per_query.csv",
        PROCESSED / "error_analysis.csv",
        PROCESSED / "ground_truth.csv",
    ],
    'py "scripts/04_rank_and_evaluate.py" --config "config.yaml" && py "scripts/05_error_analysis.py" --config "config.yaml"',
)
if not ok:
    st.stop()

summary = load_csv("metrics_summary.csv")
per_q = load_csv("metrics_per_query.csv")
err = load_csv("error_analysis.csv")
gt = load_csv("ground_truth.csv", keep_default_na=False, na_values=[""])
tax = load_csv("failure_taxonomy.csv")
cmp_df = load_csv("ae_vs_tfidf.csv", subdir="tables")
recs = load_csv("recommendations.csv")
rb = load_csv("random_baseline.csv") if (PROCESSED / "random_baseline.csv").is_file() else None

primary = summary[summary["model"] == "M3"].iloc[0]
m0 = summary[summary["model"] == "M0"].iloc[0]

# ----------------------------------------------------------- metric cards
st.markdown("### Primary model (M3 · AE-32 cosine)")
c1, c2, c3, c4, c5 = st.columns(5)
metric_card(c1, "Recall@10", f"{primary['recall_at_10']:.2f}", f"{int(primary['hits'])}/10 hits")
metric_card(c2, "Hit@1", f"{primary['hit_at_1']:.2f}", "hired CV first")
metric_card(c3, "Hit@5", f"{primary['hit_at_5']:.2f}", "within top 5")
metric_card(c4, "MRR@10", f"{primary['mrr_at_10']:.3f}", "mean reciprocal rank")
metric_card(c5, "Precision@10", f"{primary['precision_at_10']:.2f}", "max 0.1 — not recall")

st.markdown(
    f"95% Wilson CI for Recall@10: **[{(primary['wilson_ci_low'])}**, **{primary['wilson_ci_high']}]**. "
    f"Bootstrap CI (10,000 resamples): [{primary['bootstrap_ci_low']}, {primary['bootstrap_ci_high']}]. "
    f"Random baseline: expected {m0['recall_at_10']:.2f}"
    + (f", empirical mean {rb.iloc[0]['empirical_mean']:.3f} over {int(rb.iloc[0]['n_permutations'])} permutations." if rb is not None else ".")
)

with st.expander("Exact metric definitions"):
    st.markdown(
        """
- **Recall@10** = (# relevant retrieved in the top 10) / (# relevant total). With exactly one relevant CV per JD
  this is **1 if the hired CV is in the top 10, else 0**. Mean Recall@10 = hits / 10 — a hit rate.
- **Hit@K** = fraction of queries whose hired CV is within the top K.
- **MRR@10** = mean of 1/rank for hits within the top 10, else 0.
- **nDCG@10** = mean of 1/log2(rank+1) for hits within the top 10, else 0 (binary relevance, one relevant item).
- **Precision@10** = (# relevant in the top 10) / 10. Maximum is **0.1** here. It is **not** recall.
- **Wilson 95% CI** for the hit proportion; **bootstrap 95% CI** for mean Recall@10.
        """
    )

st.divider()

# ------------------------------------------------------------- per-JD chart
st.markdown("### Where did the hired CV land?")
models = st.multiselect("Models", sorted(per_q["model"].unique()), default=["M3", "M1"])
if models:
    fig = go.Figure()
    for i, m in enumerate(models):
        sub = per_q[per_q["model"] == m].sort_values("jd_id")
        fig.add_trace(
            go.Bar(
                x=sub["jd_id"],
                y=sub["rank"].clip(upper=60),
                name=m,
                marker_color=[PALETTE["hit"] if r <= 10 else PALETTE["miss"] for r in sub["rank"]],
                text=[f"#{int(r)}" for r in sub["rank"]],
                textposition="outside",
                opacity=0.9 if i == 0 else 0.65,
            )
        )
    fig.add_hline(y=10, line_dash="dash", line_color=PALETTE["navy"], annotation_text="top-10 cut-off")
    fig.update_layout(
        height=430,
        barmode="group",
        yaxis_title="rank of the hired CV (lower is better, clipped at 60)",
        xaxis_title="labelled JD",
        yaxis=dict(range=[0, 65]),
        margin=dict(l=10, r=10, t=30, b=10),
        legend=dict(orientation="h", y=1.1),
    )
    st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    caption("Green = the hired CV is inside the top 10 (a hit). Red = a miss. Bars are clipped at 60 for readability.")

st.divider()

# --------------------------------------------------------- model comparison
st.markdown("### Model comparison (all of M0–M6, not just the best)")
c1, c2 = st.columns([1.25, 1])
with c1:
    metrics = ["recall_at_10", "hit_at_1", "hit_at_5", "mrr_at_10"]
    fig = go.Figure()
    for i, (m, label) in enumerate(
        zip(metrics, ["Recall@10", "Hit@1", "Hit@5", "MRR@10"])
    ):
        fig.add_trace(go.Bar(x=summary["model"], y=summary[m], name=label, marker_color=OKABE_SEQUENCE[i]))
    fig.update_layout(
        height=400,
        barmode="group",
        yaxis_title="score",
        xaxis_title="model",
        yaxis=dict(range=[0, 1]),
        margin=dict(l=10, r=10, t=20, b=10),
        legend=dict(orientation="h", y=1.12),
    )
    st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    caption("M3 is the pre-registered primary model. M4–M6 are ablations; M5 and M6 are exploratory.")
with c2:
    st.dataframe(
        summary[
            ["model", "hits", "recall_at_10", "hit_at_1", "hit_at_5", "mrr_at_10", "wilson_ci_low", "wilson_ci_high"]
        ].rename(
            columns={
                "model": "Model",
                "hits": "Hits",
                "recall_at_10": "Recall@10",
                "hit_at_1": "Hit@1",
                "hit_at_5": "Hit@5",
                "mrr_at_10": "MRR@10",
                "wilson_ci_low": "CI low",
                "wilson_ci_high": "CI high",
            }
        ),
        hide_index=True,
        width='stretch',
        height=400,
    )

st.divider()

# ---------------------------------------------------------- rank distribution
st.markdown("### Rank distribution and score margin")
c1, c2 = st.columns(2)
with c1:
    buckets = [(1, 1, "1"), (2, 5, "2–5"), (6, 10, "6–10"), (11, 20, "11–20"), (21, 50, "21–50"), (51, 110, "51–110")]
    rows = []
    for m in ["M1", "M2", "M3", "M5", "M6"]:
        ranks = per_q[per_q["model"] == m]["rank"]
        for lo, hi, label in buckets:
            rows.append({"model": m, "bucket": label, "count": int(((ranks >= lo) & (ranks <= hi)).sum())})
    dist = pd.DataFrame(rows)
    order = [b[2] for b in buckets]
    fig = px.bar(dist, x="bucket", y="count", color="model", barmode="group", category_orders={"bucket": order}, color_discrete_sequence=OKABE_SEQUENCE)
    fig.update_layout(height=340, margin=dict(l=10, r=10, t=20, b=10), legend=dict(orientation="h", y=1.12))
    st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    caption("Distribution of the hired CV's rank. A perfect model puts all 10 bars in the first bucket.")
with c2:
    sub = per_q[per_q["model"] == "M3"].sort_values("jd_id")
    fig = go.Figure(
        go.Bar(
            x=sub["jd_id"],
            y=sub["score_margin"],
            marker_color=[PALETTE["hit"] if r <= 10 else PALETTE["miss"] for r in sub["rank"]],
            text=[f"{v:+.3f}" for v in sub["score_margin"]],
            textposition="outside",
        )
    )
    fig.add_hline(y=0, line_color=PALETTE["navy"])
    fig.update_layout(
        height=340,
        yaxis_title="hired score − top-1 score",
        xaxis_title="labelled JD",
        margin=dict(l=10, r=10, t=20, b=10),
    )
    st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    caption("Positive = the hired CV is ranked first. Negative = a false positive outranks it.")

st.divider()

# ---------------------------------------------------------- failure taxonomy
st.markdown("### Failure taxonomy (M3 misses)")
c1, c2 = st.columns([1, 1.2])
with c1:
    nz = tax[tax["count"] > 0].sort_values("count")
    if len(nz):
        fig = px.bar(
            nz,
            x="count",
            y=nz["code"] + " " + nz["category"],
            orientation="h",
            color_discrete_sequence=[PALETTE["miss"]],
            labels={"y": "", "count": "misses"},
            text="count",
        )
        fig.update_layout(height=320, margin=dict(l=10, r=10, t=20, b=10), showlegend=False)
        st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    else:
        note("No misses under M3 — the taxonomy is empty.")
with c2:
    st.dataframe(
        tax[["code", "category", "count", "definition"]].rename(
            columns={"code": "Code", "category": "Category", "count": "Misses", "definition": "Definition"}
        ),
        hide_index=True,
        width='stretch',
        height=320,
    )

st.markdown("#### Per-miss evidence")
m3_err = err[(err["model"] == "M3")]
misses = m3_err[m3_err["hired_rank"] > 10]
if len(misses):
    st.dataframe(
        misses[
            [
                "jd_id",
                "hired_rank",
                "top1_cv_id",
                "top1_title",
                "must_have_coverage_hired",
                "must_have_coverage_top1",
                "primary_failure_category",
                "secondary_failure_category",
                "comment",
            ]
        ].rename(
            columns={
                "jd_id": "JD",
                "hired_rank": "Rank",
                "top1_cv_id": "Top-1 CV",
                "top1_title": "Top-1 title",
                "must_have_coverage_hired": "Cov. hired",
                "must_have_coverage_top1": "Cov. top-1",
                "primary_failure_category": "Primary",
                "secondary_failure_category": "Secondary",
                "comment": "Evidence",
            }
        ),
        hide_index=True,
        width='stretch',
    )
    caption("Categories are assigned by an explicit rule using only evidence visible in the extracted payloads.")
else:
    note("Every query is a hit under M3.")

st.divider()

# ------------------------------------------------------------- case studies
st.markdown("### Case studies")
case_jds = sorted(err["jd_id"].unique())
pick = st.selectbox("Case study JD", case_jds, index=0)
row = err[(err["model"] == "M3") & (err["jd_id"] == pick)].iloc[0]
g = gt[gt["jd_id"] == pick].iloc[0]

c1, c2 = st.columns([1.1, 1])
with c1:
    st.markdown(
        f"**{g['jd_title']}** · {g['role_family']}  \n"
        f"Hired **{g['hired_cv_id']}** ({g['hired_cv_title']} at {g['hired_cv_company']}) "
        f"ranked **#{int(row['hired_rank'])}** with score {row['hired_score']:.4f}. "
        f"Top-1 was **{row['top1_cv_id']}** ({row['top1_title']}) at {row['top1_score']:.4f}."
    )
    st.markdown(
        f"- Must-have coverage: hired **{row['must_have_coverage_hired']:.2f}** vs top-1 **{row['must_have_coverage_top1']:.2f}**\n"
        f"- Missing must-haves (hired): {row['missing_must_haves_hired'] or 'none'}\n"
        f"- Missing must-haves (top-1): {row['missing_must_haves_top1'] or 'none'}\n"
        f"- Failure category: `{row['primary_failure_category']}` / `{row['secondary_failure_category'] or '-'}`\n"
        f"- Evidence: {row['comment']}"
    )
with c2:
    p = TABLES / f"case_study_{pick}_M3.csv"
    if p.is_file():
        st.dataframe(
            load_csv(f"case_study_{pick}_M3.csv", subdir="tables").rename(
                columns={
                    "rank": "Rank",
                    "cv_id": "CV",
                    "title": "Title",
                    "company": "Company",
                    "role_family": "Role family",
                    "score": "Score",
                    "must_have_coverage": "Coverage",
                    "is_hired": "Hired",
                }
            ),
            hide_index=True,
            width='stretch',
        )
        caption("Top 10 for the case-study JD under M3. `Hired = 1` marks the ground truth.")

p = FIGURES / f"18_case_study_{pick}.png"
if p.is_file():
    st.image(str(p), width='stretch')
    caption("Rows = top-10 candidates, columns = the JD's must-have clusters; 'yes' means the CV has that cluster.")

with st.expander("Reference narrative (results/error_analysis.md)"):
    md = RESULTS / "error_analysis.md"
    if md.is_file():
        text = md.read_text(encoding="utf-8")
        start = text.find(f"### {pick}")
        if start >= 0:
            st.markdown(text[start : start + 2200])
        else:
            st.info("Section not found in the markdown.")
    else:
        st.info("Run `py \"scripts/05_error_analysis.py\"` to generate the narrative.")

st.divider()

# ---------------------------------------------------------- AE vs TF-IDF
st.markdown("### AE vs TF-IDF per query")
c1, c2 = st.columns([1.2, 1])
with c1:
    fig = go.Figure()
    for i, (_, r) in enumerate(cmp_df.sort_values("jd_id").iterrows()):
        idx = list(cmp_df.sort_values("jd_id")["jd_id"]).index(r["jd_id"])
        colour = PALETTE["hit"] if r["delta"] < 0 else (PALETTE["miss"] if r["delta"] > 0 else PALETTE["neutral"])
        fig.add_trace(
            go.Scatter(
                x=[r["jd_id"], r["jd_id"]],
                y=[r["tfidf_rank"], r["ae_rank"]],
                mode="lines",
                line=dict(color=colour, width=2.4),
                hoverinfo="skip",
                showlegend=False,
            )
        )
        fig.add_trace(
            go.Scatter(x=[r["jd_id"]], y=[r["tfidf_rank"]], mode="markers", marker=dict(color=PALETTE["blue"], size=9), name="M1 TF-IDF", showlegend=(idx == 0), hoverinfo="skip")
        )
        fig.add_trace(
            go.Scatter(x=[r["jd_id"]], y=[r["ae_rank"]], mode="markers", marker=dict(color=PALETTE["orange"], size=9, symbol="square"), name="M3 AE", showlegend=(idx == 0), hoverinfo="skip")
        )
    fig.add_hline(y=10, line_dash="dash", line_color=PALETTE["navy"])
    fig.update_layout(
        height=380,
        yaxis_title="rank of the hired CV (lower is better)",
        xaxis_title="labelled JD",
        margin=dict(l=10, r=10, t=20, b=10),
        legend=dict(orientation="h", y=1.12),
    )
    st.plotly_chart(fig, width='stretch', config={"displayModeBar": False})
    caption("A line going down means the AE improved the hire's rank; going up means it hurt.")
with c2:
    st.dataframe(
        cmp_df[["jd_id", "tfidf_rank", "ae_rank", "delta", "winner"]].rename(
            columns={"jd_id": "JD", "tfidf_rank": "TF-IDF", "ae_rank": "AE", "delta": "Δ", "winner": "Winner"}
        ),
        hide_index=True,
        width='stretch',
        height=380,
    )

st.divider()

# -------------------------------------------------- extraction & merge quality
st.markdown("### Extraction and merge quality")
q = load_csv("extraction_quality.csv")
okq = q[q["status"] == "ok"]
metrics = load_json("cluster_metrics.json")
c1, c2, c3, c4 = st.columns(4)
metric_card(c1, "Extraction macro F1", f"{okq['f1'].mean():.2f}", "vs Excel Skills")
metric_card(c2, "Extraction macro P", f"{okq['precision'].mean():.2f}", "precision")
metric_card(c3, "Merge accuracy", f"{metrics['manual_merge_review']['accuracy']:.0%}", f"{metrics['manual_merge_review']['n_reviewed']} sampled")
metric_card(c4, "Held-out unmatched", f"{metrics['heldout_unmatched_rate']:.1%}", "keywords with no cluster")

c1, c2 = st.columns([1, 1])
with c1:
    st.markdown("**Worst 5 pool CVs by extraction F1**")
    st.dataframe(okq.nsmallest(5, "f1")[["doc_id", "precision", "recall", "f1"]].rename(columns={"doc_id": "CV"}), hide_index=True, width='stretch')
with c2:
    st.markdown("**Held-out coverage**")
    hc = load_csv("heldout_keyword_coverage.csv")
    st.dataframe(hc.sort_values("unmatched_rate", ascending=False).head(10), hide_index=True, width='stretch')
    caption("Unmatched keywords are excluded from the AE input — a real disadvantage for rare must-have skills.")

p = FIGURES / "20_extraction_quality.png"
if p.is_file():
    with st.expander("Figure: extraction quality"):
        st.image(str(p), width='stretch')

st.divider()

# ------------------------------------------------------------ recommendations
st.markdown("### Recommendations")
prio = st.multiselect("Priority filter", ["P0", "P1", "P2"], default=["P0", "P1", "P2"])
st.dataframe(
    recs[recs["priority"].isin(prio)][["priority", "issue", "evidence", "proposed_fix", "expected_impact", "effort"]].rename(
        columns={
            "priority": "Priority",
            "issue": "Issue",
            "evidence": "Evidence",
            "proposed_fix": "Proposed fix",
            "expected_impact": "Expected impact",
            "effort": "Effort",
        }
    ),
    hide_index=True,
    width='stretch',
)
caption("All impact estimates are hypotheses; none was validated on the 10 queries.")

st.divider()

# ---------------------------------------------------------------- downloads
st.markdown("### Downloads")
c1, c2, c3 = st.columns(3)
c1.download_button("metrics_summary.csv", (PROCESSED / "metrics_summary.csv").read_bytes(), "metrics_summary.csv", "text/csv")
c2.download_button("error_analysis.csv", (PROCESSED / "error_analysis.csv").read_bytes(), "error_analysis.csv", "text/csv")
md = RESULTS / "error_analysis.md"
if md.is_file():
    c3.download_button("error_analysis.md", md.read_bytes(), "error_analysis.md", "text/markdown")

st.markdown("### Limitations")
st.markdown(
    """
- **n = 10 labelled queries, one relevant CV each.** Recall@10 is a hit rate; one query changes the mean by 0.10.
  The Wilson interval spans a wide band and nothing here is statistically significant.
- **The hired candidate is not necessarily the best on paper.** Interviews, salary, availability and recruiter
  judgement are invisible to the model.
- **Hard filters are not modelled** — salary, notice period, location, citizenship, work authorisation, language —
  even though several JDs state them explicitly (P01, P02, P07).
- **LLM extraction noise** and `…` truncation in the source PDFs mean a missing mention is not proof of a missing skill.
- **Keyword clustering is heuristic.** Rare domain synonyms can stay split, and held-out keywords can be unmatched.
- **The autoencoder optimises reconstruction, not ranking**; with ~150 training documents overfitting is expected.
- **The 110-CV pool may not represent the real candidate population.**
- **No statistical significance is claimed anywhere.**
    """
)

footer()
