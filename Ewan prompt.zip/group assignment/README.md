# AI CV Matching — Baseline

**Group assignment · STAT6207 · Second Talent AI CV matching baseline**

Given a job description (JD), rank a pool of candidate CVs and return the top 10 with a short, reproducible reason. This is a **baseline**, not a production system: a clean, honest, reproducible pipeline with a rigorous error analysis rather than a tuned score.

---

## 1. Summary

The pipeline is **keyword- and representation-based**:

1. **Stage 0** — read-only ingestion of the anonymised data, split the 10 labelled PDFs into a JD and the hired CV, build the ground truth, and verify there are no duplicates.
2. **Stage 1** — a **local** Ollama model extracts structured keywords and metadata from all 170 documents (JSON-schema validated, grounded against the source text, cached per document).
3. **Stage 2** — keywords are normalised, merged through a curated alias dictionary, and clustered into 100–200 canonical concepts with hard guardrails (Java ≠ JavaScript, C ≠ C++, SQL ≠ NoSQL).
4. **Stage 3** — a document × keyword-cluster matrix feeds a PyTorch autoencoder trained **only** on the training corpus (the 10 labelled JDs and 10 hired CVs are held out).
5. **Stage 4** — seven ranking models (M0 random … M6 heuristic) score all **110 candidates** for each of the **10** labelled JDs.
6. **Stage 5** — Recall@10, Hit@1/5/10, MRR@10, nDCG@10, Precision@10, Wilson and bootstrap confidence intervals, plus an independent recomputation from `rankings.csv`.
7. **Stage 6** — per-query error analysis, a failure taxonomy with evidence, four case studies, AE vs TF-IDF comparison, and prioritised recommendations.
8. **Stage 7** — 20+ static figures at ≥200 dpi, a five-page Streamlit website, and a standalone HTML report.

**Primary model (chosen a priori, never by test recall): `M3` — cosine on the 32-d autoencoder bottleneck.**

---

## 2. Data inventory

| Path | Contents | Count |
|---|---|---|
| `data/Anonymised CVs/CV-001.pdf` … `CV-100.pdf` | anonymised pool CVs | 100 |
| `data/JD + Hired CV examples/P01 … P10.pdf` | each PDF = one JD + the CV of the person hired | 10 (→ 10 JDs + 10 CVs) |
| `data/Manatal Examples – JD & CV (anonymised).xlsx`, sheet `JD Examples` | unlabelled JDs (**not** ground truth) | 50 |
| same workbook, sheet `CV Examples` | CV metadata (silver standard for extraction quality only) | 100 |
| `data/AI_CV_Matching_Project_Plan.pdf` | project brief | 2 pages |

**Candidate pool = 110 unique CVs**: the 100 pool CVs plus the 10 hired CVs added with neutral IDs `CAND-101` … `CAND-110`. Verified: **0 true duplicates** (the highest hired↔pool TF-IDF cosine is ≈0.35, far below the 0.95 duplicate threshold).

**Ground truth = 10 rows** in `data/processed/ground_truth.csv`. The only relevant CV for `Pxx` is that PDF's hired CV. Every other one of the 109 candidates is non-relevant. This is a **sparse-label** setup and is treated as such throughout.

Two unlabelled JDs (`JD-004`, `JD-028`) are near-duplicates of labelled JDs `P04` and `P09` (cosine ≥ 0.90) and are **excluded from training** so the evaluation JD text does not leak into the autoencoder.

### The 10 labelled pairs

| JD | JD title | Role family | Hired CV | Hired title / company |
|---|---|---|---|---|
| P01 | Regional Finance Controller | Finance & Legal | CAND-101 | Regional Finance Manager · Cardia Bioplastics (Malaysia) Sdn Bhd |
| P02 | Sales Manager in Indonesia | Sales & BD | CAND-102 | Technical Sales Specialist · PT. Chemico Surabaya |
| P03 | GTM Marketing Manager / Lead | Marketing | CAND-103 | Head of Growth & Digital Transformation · Step Ahead |
| P04 | Data Engineer | Data & AI | CAND-104 | Data Engineer · BP |
| P05 | Product Manager — WMS & Warehouse Integrations | Product | CAND-105 | Senior Product Manager · Shopee International |
| P06 | Deployment Strategist | Data & AI | CAND-106 | Principal, Data Science · Boston Consulting Group |
| P07 | Marketing Manager (HK & SG) | Marketing | CAND-107 | Marketing Manager · HKT Enterprise Solutions |
| P08 | Field Service Engineer (FSE) | Engineering | CAND-108 | Field Service Engineer · Tokyo Electron Singapore Pte Ltd |
| P09 | Tech Lead | Engineering | CAND-109 | Tech Lead · JaGaApp / Red Ideas Holdings Berhad |
| P10 | Regional Lead Designer UI/UX | Design & Creative | CAND-110 | Lead, UI/UX · My E.G. Services Bhd |

---

## 3. Environment

| Component | Version |
|---|---|
| OS | Windows 10/11 (PowerShell) |
| Python | 3.12.10 (`py` launcher) |
| PyTorch | 2.9.1+cpu |
| scikit-learn | 1.9.1 |
| pandas | 3.0.6 |
| NumPy | 2.5.4 |
| PyMuPDF | current (1.24+ API: `import pymupdf`) |
| Ollama | local server at `http://127.0.0.1:11434` |
| Local LLM | `qwen3:8b` (8.2 B, Q4_K_M) — **only** local models; no external API |
| Keyword embeddings | the first available of `sentence-transformers` → Ollama `nomic-embed-text` → char TF-IDF + SVD (recorded in `data/processed/cluster_metrics.json`) |

`qwen3:8b` replaces the `qwen3.5:4b` named in the brief because that model is not installed on this machine; only local models were used and the substitution is recorded in `VALIDATION.md`.

---

## 4. How to reproduce

All commands run from the project root — the folder that contains `config.yaml`. Quote the path because the folder name contains a space.

```powershell
cd "C:\Users\User\Documents\projects\dsbs\STAT6207\group assignment"

# 0. environment
py -m pip install -r requirements.txt

# 1. Ollama must be running with the local model
ollama list
Invoke-RestMethod http://127.0.0.1:11434/api/tags

# 2. run every stage in order
py "run_all.py" --config "config.yaml"
```

Or stage by stage:

```powershell
py "scripts/00_validate_data.py"     --config "config.yaml"
py "scripts/01_extract_keywords.py"  --config "config.yaml"     # long-running; cached per document
py "scripts/02_merge_keywords.py"    --config "config.yaml"
py "scripts/03_build_autoencoder.py" --config "config.yaml"
py "scripts/04_rank_and_evaluate.py" --config "config.yaml"
py "scripts/05_error_analysis.py"    --config "config.yaml"
py "scripts/06_make_figures.py"      --config "config.yaml"
py "scripts/07_build_report.py"      --config "config.yaml"
py "scripts/08_validate_outputs.py"  --config "config.yaml"   # regenerates VALIDATION.md

# optional verification
py "scripts/09_smoke_test_pages.py"                            # every page must load
py "scripts/10_capture_screenshots.py" --config "config.yaml"  # website_*.png (app must be running)
```

Flags available on every stage: `--config`, `--force` (bypass caches/overwrite), `--limit N` (smoke test), `--model` (override the Ollama model), `--seed`, `--quiet`.

**Smoke test first:**

```powershell
py "scripts/01_extract_keywords.py" --config "config.yaml" --limit 3
```

**The website:**

```powershell
py -m streamlit run "app.py"
```

Open `http://localhost:8501`. Five pages: Overview, Keyword merging, Autoencoder, Search results, Recall & errors. The app is fully offline; no external fonts, CDNs or images.

**Standalone report** (no Python needed): open `results/report.html` directly in a browser.

### Re-run behaviour

- The LLM cache is keyed by `doc_id` **and** a hash of all prompt templates. Changing a prompt invalidates only the affected documents.
- `--force` re-runs a stage and overwrites its outputs.
- A full extraction run is resumable: interrupting it and re-running continues from the cache.

---

## 5. Metric definitions

With exactly one relevant CV per JD, **Recall@10 is a hit rate**, not a proportion of the top 10.

| Metric | Definition |
|---|---|
| **Recall@10** | (# relevant retrieved in the top 10) / (# relevant total). With one relevant item: 1 if the hired CV is in the top 10, else 0. Mean Recall@10 = hits / 10. |
| **Hit@1 / Hit@5 / Hit@10** | Fraction of queries whose hired CV is in the top 1 / 5 / 10. |
| **MRR@10** | Mean of 1/rank for hits within the top 10, else 0. |
| **nDCG@10** | Mean of 1/log2(rank+1) for hits within the top 10, else 0 (binary relevance, one relevant item). |
| **Precision@10** | (# relevant in the top 10) / 10. **Maximum is 0.1 here** and it is **not** recall. |
| **Wilson 95% CI** | Exact binomial interval for the hit proportion. |
| **Bootstrap 95% CI** | Percentile interval for mean Recall@10, 10,000 resamples, seed 42. |
| **Random baseline** | Expected Recall@10 = 10/110 = 0.0909, also measured empirically over 1,000 seeded permutations. |

The "nearest pool CV" lookalikes listed in the brief are hard negatives, **never** labels.

---

## 6. Headline results

Primary model **M3 = AE-32 cosine**, chosen before looking at test recall. All of M0–M6 are reported.

| Model | Definition | Hits@10 | Recall@10 | Hit@1 | Hit@5 | MRR@10 | nDCG@10 |
|---|---|---|---|---|---|---|---|
| M0 | Random (seeded) | 2/10 | 0.20 | 0.00 | 0.00 | 0.031 | 0.069 |
| M1 | TF-IDF keyword cosine | 7/10 | 0.70 | 0.30 | 0.50 | 0.427 | 0.491 |
| M2 | SVD-32 cosine | 7/10 | 0.70 | 0.30 | 0.50 | 0.406 | 0.475 |
| **M3** | **AE-32 cosine (primary)** | **4/10** | **0.40** | **0.10** | **0.40** | **0.173** | **0.227** |
| M4 | AE + metadata | 7/10 | 0.70 | 0.20 | 0.50 | 0.320 | 0.408 |
| M5 | Hybrid AE + must-have coverage (exploratory) | 5/10 | 0.50 | 0.00 | 0.30 | 0.144 | 0.229 |
| M6 | Role-family heuristic (exploratory) | 9/10 | 0.90 | 0.30 | 0.80 | 0.473 | 0.576 |

- **Primary model (M3) Recall@10 = 0.40 (4/10), 95% Wilson CI [0.17, 0.69].**
- Random baseline: expected 10/110 = 0.0909; empirical mean 0.081 over 1,000 seeded permutations.
- Precision@10 never exceeds 0.1, as it must with one relevant CV per JD.

**The autoencoder does not beat plain TF-IDF.** This is the headline finding and it is reported as-is:
TF-IDF (M1) retrieves the hired CV for 7 of 10 queries, the AE (M3) for 4. The AE wins on P08 (rank 45 → 5)
and P09 (rank 59 → 1) but loses badly on P03 (2 → 31), P04 (7 → 27) and P02 (2 → 24). Adding metadata to the
AE (M4) recovers 7/10, and the role-family heuristic (M6) reaches 9/10 — both pieces of evidence say that the
signal is in the vocabulary and the metadata, not in the learned bottleneck.

---

## 7. Key findings

See `results/error_analysis.md` for the evidence behind each finding.

1. **The autoencoder is not the win.** Trained to reconstruct, it smooths away exactly the rare must-have skills
   that discriminate between candidates. Plain TF-IDF on the same keyword-cluster matrix beats it 7/10 vs 4/10.
2. **Metadata carries information the keywords do not.** AE + metadata recovers 7/10 (from 4/10) and ranking
   same-role-family candidates first reaches 9/10. Role family alone is a very strong prior on this pool.
3. **Must-have coverage is the metric to build on.** M5 (AE + must-have coverage) is a 2-line change and already
   sits between M3 and M4; when the hired CV does win, coverage is usually the reason.
4. **Hard filters are ignored, and it shows.** Several JDs state location, citizenship or language requirements
   (P01 Malaysia/Thailand, P02 Indonesian citizen in Indonesia, P07 HK & SG) that the baseline never applies.
5. **Seniority and years are the main systematic error.** Four of the six M3 misses are categorised
   `E5 seniority_years_mismatch`: a much more senior candidate outranks the hire (P03 13y vs 8y, P05 18y vs 8y,
   P07 18y vs 9y) because the keyword-only score cannot see experience at all.

---

## 8. Limitations

- **n = 10** labelled queries with one relevant CV each. One query changes the mean by 0.10; the confidence interval is wide; **no statistical significance is claimed**.
- The hired candidate is not necessarily the best on paper — interviews, salary, availability and recruiter judgement are invisible to the model.
- **Salary, notice period, location, citizenship, work authorisation and language filters are not modelled.**
- LLM extraction is noisy and some source text is truncated with `…`; a missing mention is not proof that a candidate lacks a skill.
- Keyword clustering is heuristic: rare domain synonyms can stay split, and held-out keywords without a training cluster are excluded from the AE input.
- The autoencoder is trained on ~150 documents and optimises reconstruction, not ranking.
- The 110-CV pool may not represent the real candidate population.
- The 50 unlabelled JDs are not ground truth; they are training context only.

---

## 9. Privacy

All source documents are pre-anonymised by the dataset provider. Before any text reaches the model, email addresses, phone numbers, URLs and postal codes are regex-masked (`src/llm.py::mask_pii`). Only `http://127.0.0.1:11434` is contacted; there are **no** external API calls, no scraping and no data uploads. Ground-truth labels (`Hired for: …`, `P01`–`P10`, the candidate IDs) are stripped from all feature text and verified by automated leakage checks in `VALIDATION.md`.

---

## 10. Project layout

```text
group assignment/
├── PROMPT.md                    brief (unchanged)
├── README.md                    this file
├── VALIDATION.md                QA checklist with actual numbers
├── requirements.txt
├── config.yaml                  paths, model, seed, hyperparameters, top_k
├── run_all.py                   orchestrator
├── app.py                       Streamlit entry point
├── pages/                       5 pages of the website
├── scripts/                     00_validate_data … 10_capture_screenshots
├── src/                         config, data, llm, extraction, keywords,
│                                autoencoder, retrieval, metrics, analysis,
│                                plots, web, overview
├── prompts/                     system + JD/CV extraction + merge + naming
├── data/                        raw inputs (read-only) and processed artifacts
├── models/                      autoencoder.pt, configs, cluster model
├── logs/                        one log file per stage
└── results/
    ├── figures/                 all PNGs (>=200 dpi)
    ├── tables/                  report-ready CSVs
    ├── error_analysis.md
    └── report.html              standalone offline report
```

## 11. Assumptions

Where the brief left a choice open, these were taken and are recorded here and in `VALIDATION.md`:

1. **Model substitution.** `qwen3.5:4b` is not installed; `qwen3:8b` (local) is used for all extraction. Only local models were used; no external provider was contacted at any point.
2. **Primary clustering protocol.** Clusters and the keyword vocabulary are fit on the **training corpus only** (100 pool CVs + 50 unlabelled JDs minus GT near-duplicates). Held-out keywords are assigned to the nearest centroid above a similarity threshold and the unmatched rate is reported.
3. **Embedding post-processing.** The local dense embeddings are strongly anisotropic, so the standard *all-but-the-top* correction (remove the first principal component, renormalise) is applied before clustering and before held-out assignment. Without it, raw cosines occupy a narrow band and no threshold yields a usable cluster count.
4. **Linkage.** Complete linkage is used instead of average linkage: average linkage collapsed into a handful of giant heterogeneous clusters on this vocabulary. Guardrails are enforced independently of the linkage choice.
5. **Cluster size cap.** Any cluster above `max_cluster_size` is recursively re-clustered so the vocabulary stays interpretable; the guardrail mask is carried into every sub-problem.
6. **Primary AE configuration.** M3 keeps the pre-registered 32-d / dropout-0.2 configuration even though the ablation found a marginally lower validation MSE elsewhere. The validation-selected variant is saved as `models/autoencoder_valsel.pt` and reported as an ablation, never as the primary result.
7. **Reconstruction loss.** `MSE + (1 - cosine)`. Plain MSE collapsed the bottleneck to a constant point (verified), because the optimum for L2-normalised sparse rows is to predict the mean row.
8. **Role family for hired CVs.** Taken **only** from the LLM's reading of the CV text, never from the JD header, to avoid leaking the label into a candidate feature. Pool CVs use the Excel label, which describes the CV itself.
9. **Seven models.** M0–M6 are all reported; M3 is primary. M5 and M6 are labelled exploratory because they use metadata or coverage that a recruiter would treat as policy rather than a learned signal.
10. **CV pool size 110.** No true duplicate was found by the specified test (cosine ≥ 0.95 *and* title + company match; the highest observed cosine is 0.35), so all 10 hired CVs are added as candidates.
11. **Screenshots.** Playwright is unavailable, so `scripts/10_capture_screenshots.py` drives headless Microsoft Edge over the DevTools protocol. The five `website_*.png` files are real captures of the running app.
