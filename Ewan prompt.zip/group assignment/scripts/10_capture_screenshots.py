"""Capture real website screenshots for the report.

Two backends are tried in order:

1. ``playwright`` (the brief's recommendation) if it is installed;
2. headless Microsoft Edge via the DevTools protocol driven directly with
   ``websocket-client`` / ``requests`` — no extra packages required.

The result is five ``website_*.png`` files under ``results/figures/``. If neither
backend works the script says so and exits non-zero instead of writing blank
images (a blank screenshot is worse than none, because it looks like evidence).
"""

from __future__ import annotations

import argparse
import base64
import json
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

BROWSERS = [
    r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Microsoft\Edge\Application\msedge.exe",
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
]

PAGES = [
    ("website_overview.png", ""),
    ("website_keywords.png", "Keyword_Merging"),
    ("website_autoencoder.png", "Autoencoder"),
    ("website_results.png", "Search_Results"),
    ("website_errors.png", "Error_Analysis"),
]


def _find_browser() -> str | None:
    for p in BROWSERS:
        if Path(p).is_file():
            return p
    return shutil.which("msedge") or shutil.which("chrome")


# --------------------------------------------------------------------------- #
# Playwright backend
# --------------------------------------------------------------------------- #
def capture_playwright(base_url: str, out_dir: Path, width: int, height: int) -> bool:
    try:
        from playwright.sync_api import sync_playwright
    except Exception:
        return False

    with sync_playwright() as pw:
        browser = pw.chromium.launch(args=["--no-sandbox"])
        page = browser.new_page(viewport={"width": width, "height": height})
        for filename, route in PAGES:
            url = f"{base_url}/{route}" if route else base_url
            page.goto(url, wait_until="networkidle", timeout=60_000)
            page.wait_for_timeout(4_000)
            page.screenshot(path=str(out_dir / filename), full_page=True)
            print(f"  OK {filename} (playwright)")
        browser.close()
    return True


# --------------------------------------------------------------------------- #
# CDP backend (Edge / Chrome, no extra packages)
# --------------------------------------------------------------------------- #
def capture_cdp(browser: str, base_url: str, out_dir: Path, width: int, height: int) -> bool:
    import requests
    from websocket import create_connection  # websocket-client ships with many stacks

    with tempfile.TemporaryDirectory() as profile:
        port = 9333
        proc = subprocess.Popen(
            [
                browser,
                "--headless=new",
                "--disable-gpu",
                "--no-sandbox",
                "--hide-scrollbars",
                f"--window-size={width},{height}",
                f"--remote-debugging-port={port}",
                f"--user-data-dir={profile}",
                "about:blank",
            ],
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        try:
            # wait for the debugger
            for _ in range(60):
                try:
                    tabs = requests.get(f"http://127.0.0.1:{port}/json", timeout=1).json()
                    if any(t.get("type") == "page" for t in tabs):
                        break
                except Exception:
                    pass
                time.sleep(0.5)
            else:
                print("  CDP: debugger never became available")
                return False

            tabs = requests.get(f"http://127.0.0.1:{port}/json", timeout=5).json()
            tab = next(t for t in tabs if t.get("type") == "page")
            ws = create_connection(tab["webSocketDebuggerUrl"], timeout=90)
            msg_id = 0

            def send(method: str, params: dict | None = None) -> dict:
                nonlocal msg_id
                msg_id += 1
                ws.send(json.dumps({"id": msg_id, "method": method, "params": params or {}}))
                while True:
                    payload = json.loads(ws.recv())
                    if payload.get("id") == msg_id:
                        if "error" in payload:
                            raise RuntimeError(payload["error"])
                        return payload.get("result", {})

            send("Page.enable")
            send("Emulation.setDeviceMetricsOverride",
                 {"width": width, "height": height, "deviceScaleFactor": 1, "mobile": False})

            for filename, route in PAGES:
                url = f"{base_url}/{route}" if route else base_url
                send("Page.navigate", {"url": url})
                # wait for Streamlit's websocket render; poll the body text
                deadline = time.time() + 60
                ready = False
                while time.time() < deadline:
                    time.sleep(2.0)
                    res = send(
                        "Runtime.evaluate",
                        {"expression": "document.body.innerText.length", "returnByValue": True},
                    )
                    n = res.get("result", {}).get("value") or 0
                    if isinstance(n, (int, float)) and n > 600:
                        time.sleep(2.5)  # let charts finish drawing
                        ready = True
                        break
                if not ready:
                    print(f"  WARN {filename}: page text did not reach threshold")
                shot = send("Page.captureScreenshot", {"format": "png", "captureBeyondViewport": True})
                (out_dir / filename).write_bytes(base64.b64decode(shot["data"]))
                size = (out_dir / filename).stat().st_size
                print(f"  OK {filename} ({size:,d} bytes) {'ready' if ready else 'partial'}")

            ws.close()
            return True
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=15)
            except Exception:
                proc.kill()


def main() -> int:
    ap = argparse.ArgumentParser(description="Capture real Streamlit screenshots")
    ap.add_argument("--config", default=None)
    ap.add_argument("--base-url", default="http://localhost:8501")
    ap.add_argument("--width", type=int, default=1440)
    ap.add_argument("--height", type=int, default=1400)
    args = ap.parse_args()

    from src.config import load_config

    cfg = load_config(args.config)
    out_dir = cfg.ensure_dir("figures")

    # is the app actually up?
    try:
        import requests

        r = requests.get(args.base_url, timeout=10)
        if r.status_code != 200:
            print(f"app returned HTTP {r.status_code}; start it with `py -m streamlit run app.py`")
            return 2
    except Exception as exc:  # noqa: BLE001
        print(f"cannot reach {args.base_url}: {exc}")
        print("start the app first: py -m streamlit run \"app.py\"")
        return 2

    print(f"capturing {len(PAGES)} pages from {args.base_url}")
    if capture_playwright(args.base_url, out_dir, args.width, args.height):
        print("done (playwright)")
        return 0

    browser = _find_browser()
    if not browser:
        print("Playwright is unavailable and no Edge/Chrome binary was found — screenshots skipped.")
        print("This is documented in VALIDATION.md; the static PNGs are the permanent evidence.")
        return 2

    print(f"playwright unavailable; using {browser} over CDP")
    try:
        ok = capture_cdp(browser, args.base_url, out_dir, args.width, args.height)
    except ImportError:
        print("websocket-client is not installed; run `py -m pip install websocket-client`")
        print("screenshots skipped (documented in VALIDATION.md)")
        return 2

    if ok:
        # sanity: reject blank captures
        blanks = [f for f, _ in PAGES if (out_dir / f).is_file() and (out_dir / f).stat().st_size < 30_000]
        if blanks:
            print(f"WARNING: these captures look blank: {blanks}")
            return 1
        print("all screenshots captured and non-blank")
        return 0
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
