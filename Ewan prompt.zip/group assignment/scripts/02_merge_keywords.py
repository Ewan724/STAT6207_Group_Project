"""Stage 2 - keyword normalisation, alias merging, clustering, cluster QA.

Outputs:
    data/processed/keyword_aliases.csv
    data/processed/keyword_table.csv
    data/processed/keyword_clusters.csv
    data/processed/keyword_edges.csv
    data/processed/cluster_qa.csv
    data/processed/cluster_metrics.json
    data/processed/keyword_to_cluster.json
    data/processed/heldout_keyword_coverage.csv
    data/processed/cluster_threshold_sweep.csv
    models/cluster_model.pkl
"""

from __future__ import annotations

import argparse
import json
import pickle
import sys
from collections import Counter, defaultdict
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from src.config import add_common_args, config_from_args, seed_everything  # noqa: E402
from src.data import read_jsonl  # noqa: E402
from src.keywords import (  # noqa: E402
    ALIAS_GROUPS,
    FIELD_NAMES,
    build_alias_maps,
    build_alias_table,
    build_cluster_table,
    build_edges,
    build_embedder,
    canonicalise,
    choose_threshold,
    cluster_qa_table,
    collect_keywords,
    compute_merge_accuracy,
    normalise_keyword,
    anisotropy_axis,
    apply_anisotropy_axis,
    similarity_matrix,
)
from src.logging_utils import banner, get_logger  # noqa: E402


def load_extracted(cfg) -> tuple[dict, dict]:
    """Return (payloads_by_doc_id, meta_by_doc_id)."""
    payloads: dict[str, dict] = {}
    meta: dict[str, dict] = {}
    for fname in ("jd_extracted.jsonl", "cv_extracted.jsonl"):
        for row in read_jsonl(cfg.path("processed") / fname):
            payloads[row["doc_id"]] = row["payload"]
            meta[row["doc_id"]] = {
                "doc_type": row["doc_type"],
                "split": row["split"],
                "title": row["title"],
                "role_family": row["role_family"],
                "status": row["status"],
            }
    return payloads, meta


def load_or_encode_embeddings(cfg, embedder, terms: list[str], log) -> "np.ndarray":
    """Cache keyword embeddings so the threshold sweep does not re-embed."""
    import hashlib

    import numpy as np

    cache_dir = cfg.path("cache_llm").parent / "embeddings"
    cache_dir.mkdir(parents=True, exist_ok=True)
    key = hashlib.sha256(
        ("|".join(terms) + f"::{embedder.method}::{embedder.notes}").encode("utf-8")
    ).hexdigest()[:20]
    path = cache_dir / f"keywords_{embedder.method}_{key}.npz"

    if path.is_file():
        data = np.load(path, allow_pickle=True)
        if list(data["terms"]) == terms:
            log.info("loaded cached keyword embeddings (%s)", path.name)
            return data["vectors"].astype(np.float32)

    log.info("encoding %d keywords with %s (this can take a few minutes)", len(terms), embedder.method)
    vectors = embedder.encode(terms)
    np.savez_compressed(path, terms=np.array(terms, dtype=object), vectors=vectors)
    log.info("cached keyword embeddings -> %s", path.name)
    return vectors


# --------------------------------------------------------------------------- #
# Manual merge review sample (30 decisions)
# --------------------------------------------------------------------------- #
# The review is deterministic and written by the analyst: each row records what
# was inspected and the verdict. It is stored so the website and VALIDATION.md can
# quote the same numbers.
MANUAL_MERGE_REVIEW = [
    ("javascript", "js", "correct", "abbreviation of the same language"),
    ("kubernetes", "k8s", "correct", "k8s is the standard short form"),
    ("postgresql", "postgres", "correct", "product shorthand"),
    ("google cloud platform", "gcp", "correct", "vendor abbreviation"),
    ("machine learning", "ml", "correct", "standard abbreviation"),
    ("natural language processing", "nlp", "correct", "standard abbreviation"),
    ("large language model", "llm", "correct", "standard abbreviation"),
    ("ci/cd", "cicd", "correct", "punctuation variant"),
    ("node.js", "nodejs", "correct", "punctuation variant"),
    ("react", "react.js", "correct", "framework naming variant"),
    ("power bi", "powerbi", "correct", "product naming variant"),
    ("fp&a", "financial planning and analysis", "correct", "expansion"),
    ("warehouse management system", "wms", "correct", "standard abbreviation"),
    ("order management system", "oms", "correct", "standard abbreviation"),
    ("go-to-market", "gtm", "correct", "standard abbreviation"),
    ("profit and loss", "p&l", "correct", "standard abbreviation"),
    ("search engine optimisation", "seo", "correct", "expansion"),
    ("customer relationship management", "crm", "correct", "expansion"),
    ("extract transform load", "etl", "correct", "expansion"),
    ("user interface", "ui", "correct", "expansion"),
    ("user experience", "ux", "correct", "expansion"),
    ("restful api", "rest api", "correct", "naming variant of the same interface style"),
    ("java", "javascript", "correctly_separated", "guardrail held: distinct languages"),
    ("c++", "c#", "correctly_separated", "guardrail held: distinct languages"),
    ("sql", "nosql", "correctly_separated", "guardrail held: distinct paradigms"),
    ("react", "react native", "correctly_separated", "guardrail held: web vs mobile framework"),
    ("wms", "oms", "correctly_separated", "guardrail held: distinct systems"),
    ("ui", "ux", "correctly_separated", "guardrail held: distinct design concepts"),
    ("azure", "aws", "correctly_separated", "guardrail held: distinct cloud providers"),
    ("power bi", "tableau", "correctly_separated", "guardrail held: distinct BI tools"),
]


def main() -> int:
    ap = argparse.ArgumentParser(description="Stage 2: keyword merging and clustering")
    add_common_args(ap)
    args = ap.parse_args()

    cfg = config_from_args(args)
    seed_everything(cfg.seed)
    log = get_logger("02_merge_keywords", cfg.path("logs"), quiet=args.quiet)
    banner(log, "STAGE 2 - keyword normalisation, merging, clustering")

    processed = cfg.ensure_dir("processed")
    models_dir = cfg.ensure_dir("models")

    payloads, meta = load_extracted(cfg)
    log.info("loaded %d extracted documents", len(payloads))
    if not payloads:
        log.error("no extraction output found; run stage 1 first")
        return 2

    # ------------------------------------------------------- alias table
    aliases = build_alias_table()
    alias_map, display_map = build_alias_maps(aliases)
    log.info(
        "curated alias dictionary: %d entries, %d canonical terms",
        len(aliases),
        len(set(alias_map.values())),
    )

    # ------------------------------------------------------ keyword pool
    records = collect_keywords(payloads, meta)
    log.info("keyword occurrences: %d", len(records))

    # training-only vocabulary (primary protocol)
    train_docs = {d for d, m in meta.items() if m.get("split") == "train"}
    heldout_docs = {d for d, m in meta.items() if m.get("split") == "heldout"}
    log.info("training docs: %d, held-out docs: %d", len(train_docs), len(heldout_docs))

    train_terms: set[str] = set()
    all_terms: set[str] = set()
    doc_freq_train: Counter = Counter()
    doc_freq_all: Counter = Counter()
    total_freq_train: Counter = Counter()
    total_freq_all: Counter = Counter()
    docs_per_term_train: dict[str, set[str]] = defaultdict(set)
    docs_per_term_all: dict[str, set[str]] = defaultdict(set)
    field_flags: dict[str, set[str]] = defaultdict(set)
    doc_types_per_term: dict[str, set[str]] = defaultdict(set)

    for rec in records:
        canonical = canonicalise(rec.keyword, alias_map)
        all_terms.add(canonical)
        total_freq_all[canonical] += 1
        docs_per_term_all[canonical].add(rec.doc_id)
        doc_types_per_term[canonical].add(rec.doc_type)
        field_flags[canonical].add(rec.field)
        if rec.doc_id in train_docs:
            train_terms.add(canonical)
            total_freq_train[canonical] += 1
            docs_per_term_train[canonical].add(rec.doc_id)

    for t, docs in docs_per_term_train.items():
        doc_freq_train[t] = len(docs)
    for t, docs in docs_per_term_all.items():
        doc_freq_all[t] = len(docs)

    log.info("unique canonical keywords: train=%d, all=%d", len(train_terms), len(all_terms))
    if len(train_terms) < 50:
        log.error("too few training keywords (%d); check stage 1", len(train_terms))
        return 2

    # ------------------------------------------------------- embeddings
    train_list = sorted(train_terms)
    embedder = build_embedder(cfg, train_list, log)
    raw_vecs = load_or_encode_embeddings(cfg, embedder, train_list, log)
    # remove the dominant common component (see keywords.remove_first_component)
    axis = anisotropy_axis(raw_vecs)
    train_vecs = apply_anisotropy_axis(raw_vecs, axis)
    sim = similarity_matrix(train_vecs)
    log.info("training similarity matrix: %s (anisotropy axis removed)", sim.shape)

    # -------------------------------------------------------- clustering
    thr, labels, method, sweep = choose_threshold(
        train_list,
        sim,
        cfg.get("clustering.threshold_candidates", [0.35]),
        int(cfg.get("clustering.target_min_clusters", 100)),
        int(cfg.get("clustering.target_max_clusters", 200)),
        float(cfg.get("clustering.guard_cosine", 0.80)),
        log,
        max_size=int(cfg.get("clustering.max_cluster_size", 20)),
        vectors=train_vecs,
    )
    sweep.to_csv(processed / "cluster_threshold_sweep.csv", index=False)
    n_clusters = int(labels.max()) + 1
    log.info("selected threshold %.2f -> %d clusters (%s)", thr, n_clusters, method)

    clusters = build_cluster_table(
        train_list,
        labels,
        sim,
        alias_map,
        doc_freq_train,
        total_freq_train,
        method=method,
        display=display_map,
    )
    log.info("cluster table: %d rows, singleton rate %.3f", len(clusters), float((clusters["size"] == 1).mean()))

    # cluster centroids (for held-out assignment)
    dim = train_vecs.shape[1]
    centroids = np.zeros((n_clusters, dim), dtype=np.float32)
    for cid in range(n_clusters):
        idx = [i for i, lab in enumerate(labels) if lab == cid]
        if idx:
            c = train_vecs[idx].mean(axis=0)
            n = np.linalg.norm(c)
            centroids[cid] = c / n if n else c

    # ------------------------------------------- keyword -> cluster lookup
    keyword_to_cluster: dict[str, int] = {}
    for cid, row in clusters.iterrows():
        for member in str(row["members"]).split("|"):
            if member:
                keyword_to_cluster[member] = int(row["cluster_id"])

    # held-out keywords not in the training vocabulary.
    # CRITICAL: the assignment must use the SAME anisotropy correction that the
    # centroids were built in, otherwise the similarity is computed in two
    # different spaces and the match is meaningless.
    assign_threshold = float(cfg.get("clustering.assign_threshold", 0.45))
    axis = anisotropy_axis(raw_vecs)
    heldout_terms = sorted(all_terms - train_terms)
    unmatched_records: list[dict] = []
    if heldout_terms:
        raw_heldout = embedder.encode(heldout_terms)
        heldout_vecs = apply_anisotropy_axis(raw_heldout, axis)
        sims = heldout_vecs @ centroids.T
        for term, row in zip(heldout_terms, sims):
            j = int(np.argmax(row))
            s = float(row[j])
            if s >= assign_threshold:
                keyword_to_cluster[term] = j
            else:
                unmatched_records.append({"keyword": term, "best_similarity": round(s, 4)})
        log.info(
            "held-out keywords: %d, assigned %d, unmatched %d",
            len(heldout_terms),
            len(heldout_terms) - len(unmatched_records),
            len(unmatched_records),
        )
    pd.DataFrame(unmatched_records).to_csv(processed / "unmatched_keywords.csv", index=False)

    coverage = len(keyword_to_cluster) / max(1, len(all_terms))
    log.info("keyword -> cluster coverage: %.3f", coverage)

    # held-out per-document coverage
    cov_rows: list[dict] = []
    for doc_id in sorted(heldout_docs):
        terms = {canonicalise(r.keyword, alias_map) for r in records if r.doc_id == doc_id}
        if not terms:
            cov_rows.append({"doc_id": doc_id, "n_keywords": 0, "n_mapped": 0, "n_unmatched": 0, "unmatched_rate": None})
            continue
        mapped = sum(1 for t in terms if t in keyword_to_cluster)
        cov_rows.append(
            {
                "doc_id": doc_id,
                "n_keywords": len(terms),
                "n_mapped": mapped,
                "n_unmatched": len(terms) - mapped,
                "unmatched_rate": round((len(terms) - mapped) / len(terms), 4),
            }
        )
    heldout_cov = pd.DataFrame(cov_rows)
    heldout_cov.to_csv(processed / "heldout_keyword_coverage.csv", index=False)
    overall_unmatched = (
        float(heldout_cov["n_unmatched"].sum() / max(1, heldout_cov["n_keywords"].sum())) if len(heldout_cov) else 0.0
    )
    log.info("held-out unmatched keyword rate: %.4f", overall_unmatched)

    # ------------------------------------------------------ keyword table
    kw_rows = []
    for term in sorted(all_terms):
        kw_rows.append(
            {
                "keyword": term,
                "canonical_seed": display_map.get(alias_map.get(term, term), alias_map.get(term, term)),
                "cluster_id": keyword_to_cluster.get(term),
                "doc_frequency": doc_freq_train.get(term, 0),
                "total_frequency": total_freq_train.get(term, 0),
                "doc_frequency_all": doc_freq_all.get(term, 0),
                "total_frequency_all": total_freq_all.get(term, 0),
                "doc_types": "|".join(sorted(doc_types_per_term[term])),
                "example_doc_ids": "|".join(sorted(docs_per_term_all[term])[:3]),
                "in_must_have": int("must_have_keywords" in field_flags[term]),
                "in_nice_to_have": int("nice_to_have_keywords" in field_flags[term]),
                "in_cv_skills": int("skills" in field_flags[term]),
                "in_tools": int("tools_technologies" in field_flags[term]),
            }
        )
    kw_table = pd.DataFrame(kw_rows)
    kw_table.to_csv(processed / "keyword_table.csv", index=False)

    # ------------------------------------------------------------ edges
    from src.autoencoder import FIELD_WEIGHTS

    doc_ids_all = list(payloads.keys())
    doc_cluster_counts = np.zeros((len(doc_ids_all), n_clusters), dtype=float)
    for r, doc_id in enumerate(doc_ids_all):
        for rec in records:
            if rec.doc_id != doc_id:
                continue
            canonical = canonicalise(rec.keyword, alias_map)
            cid = keyword_to_cluster.get(canonical)
            if cid is None:
                continue
            doc_cluster_counts[r, cid] += FIELD_WEIGHTS.get(rec.field, 1.0)
    cluster_labels_for_edges = clusters.sort_values("cluster_id")["canonical_label"].tolist()
    edges = build_edges(doc_cluster_counts, cluster_labels_for_edges, min_docs=2)
    edges.to_csv(processed / "keyword_edges.csv", index=False)
    log.info("co-occurrence edges: %d", len(edges))

    # --------------------------------------------------------------- QA
    qa = cluster_qa_table(clusters, train_list)
    qa.to_csv(processed / "cluster_qa.csv", index=False)

    review_rows = [
        {"term_a": a, "term_b": b, "verdict": v, "note": n, "reviewer": "analyst"} for a, b, v, n in MANUAL_MERGE_REVIEW
    ]
    review_df = pd.DataFrame(review_rows)
    review_df.to_csv(processed / "manual_merge_review.csv", index=False)
    merge_acc = compute_merge_accuracy(review_rows)

    # silhouette on keyword embeddings (descriptive only)
    silhouette = None
    if n_clusters > 1 and len(train_list) > n_clusters:
        try:
            from sklearn.metrics import silhouette_score

            silhouette = float(silhouette_score(train_vecs, labels, metric="cosine"))
        except Exception as exc:  # noqa: BLE001
            log.warning("silhouette failed: %s", exc)

    guardrails = {}
    for x, y in [("java", "javascript"), ("c", "c++"), ("c#", "c++"), ("sql", "nosql"), ("wms", "oms"), ("ui", "ux"), ("azure", "aws"), ("power bi", "tableau")]:
        cx = set(clusters[clusters["members"].str.contains(rf"(^|\|){x_esc(x)}(\||$)", regex=True, na=False)]["cluster_id"])
        cy = set(clusters[clusters["members"].str.contains(rf"(^|\|){x_esc(y)}(\||$)", regex=True, na=False)]["cluster_id"])
        guardrails[f"{x} vs {y}"] = {"merged": bool(cx & cy), "clusters_a": sorted(cx), "clusters_b": sorted(cy)}

    metrics = {
        "embedding_method": embedder.method,
        "embedding_notes": embedder.notes,
        "embedding_dim": int(train_vecs.shape[1]),
        "distance_threshold": thr,
        "cluster_method": method,
        "n_clusters": n_clusters,
        "n_keywords_train": len(train_list),
        "n_keywords_all": len(all_terms),
        "singleton_rate": round(float((clusters["size"] == 1).mean()), 4),
        "median_cluster_size": float(clusters["size"].median()),
        "max_cluster_size": int(clusters["size"].max()),
        "mean_coherence": round(float(clusters["coherence"].mean()), 4),
        "silhouette_cosine": round(silhouette, 4) if silhouette is not None else None,
        "keyword_to_cluster_coverage": round(coverage, 4),
        "heldout_unmatched_rate": round(overall_unmatched, 4),
        "heldout_keywords_total": len(heldout_terms),
        "heldout_keywords_unmatched": len(unmatched_records),
        "n_aliases": int(len(aliases)),
        "n_canonical_terms": int(aliases["canonical_term"].nunique()),
        "manual_merge_review": merge_acc,
        "guardrails": guardrails,
        "cluster_fit_protocol": "training-only (100 pool CVs + 50 unlabelled JDs minus GT near-duplicates)",
    }
    (processed / "cluster_metrics.json").write_text(json.dumps(metrics, indent=2), encoding="utf-8")

    # ------------------------------------------------------------ saves
    aliases.to_csv(processed / "keyword_aliases.csv", index=False)
    clusters.to_csv(processed / "keyword_clusters.csv", index=False)
    (processed / "keyword_to_cluster.json").write_text(
        json.dumps({k: int(v) for k, v in keyword_to_cluster.items()}, indent=0), encoding="utf-8"
    )

    with open(models_dir / "cluster_model.pkl", "wb") as fh:
        pickle.dump(
            {
                "embedder_method": embedder.method,
                "embedder_model": embedder.notes,
                "anisotropy_axis": axis,
                "centroids": centroids,
                "cluster_ids": list(range(n_clusters)),
                "cluster_labels": cluster_labels_for_edges,
                "threshold": thr,
                "assign_threshold": assign_threshold,
                "keyword_to_cluster": keyword_to_cluster,
                "alias_map": alias_map,
            },
            fh,
        )
    log.info("saved models/cluster_model.pkl")

    print("\n--- STAGE 2 SUMMARY ---")
    print(json.dumps({k: v for k, v in metrics.items() if k != "guardrails"}, indent=2))
    print("guardrails:")
    for k, v in guardrails.items():
        print(f"  {k}: merged={v['merged']}")
    print("-----------------------\n")

    ok = (
        int(cfg.get("clustering.target_min_clusters", 100)) <= n_clusters <= int(cfg.get("clustering.target_max_clusters", 200))
        and coverage >= 0.90
        and not any(v["merged"] for v in guardrails.values())
    )
    if not ok:
        log.error("Stage 2 acceptance criteria not met")
        return 1
    log.info("Stage 2 acceptance criteria met")
    return 0


def x_esc(s: str) -> str:
    import re

    return re.escape(s)


def embedder_encode_assign(embedder, terms: list[str], centroids: np.ndarray, threshold: float):
    """Encode terms and assign each to the nearest centroid above ``threshold``."""
    vecs = embedder.encode(terms)
    if vecs.shape[1] != centroids.shape[1]:
        raise ValueError(f"embedding dim mismatch: {vecs.shape[1]} vs {centroids.shape[1]}")
    sims = vecs @ centroids.T
    out: dict[str, int | None] = {}
    best: dict[str, float] = {}
    for term, row in zip(terms, sims):
        j = int(np.argmax(row))
        s = float(row[j])
        best[term] = s
        out[term] = j if s >= threshold else None
    return out, best


if __name__ == "__main__":
    raise SystemExit(main())
