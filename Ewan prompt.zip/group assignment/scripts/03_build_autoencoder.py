"""Stage 3 - build the document x cluster matrix and train the autoencoder.

Outputs:
    data/processed/document_keyword_matrix.npz
    data/processed/document_matrix_index.csv
    data/processed/metadata_matrix.csv
    data/processed/document_embeddings.csv
    data/processed/ae_ablation.csv
    data/processed/ae_reconstruction.csv
    models/vectorizer.json
    models/autoencoder.pt
    models/autoencoder_config.json
    models/ae_training_history.csv
    results/tables/ae_vs_svd.csv
    results/tables/reconstruction_examples.csv
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
import scipy.sparse as sp  # noqa: E402

from src.autoencoder import (  # noqa: E402
    FIELD_WEIGHTS,
    TORCH_AVAILABLE,
    build_document_matrix,
    build_metadata_matrix,
    cosine_reconstruction,
    dead_unit_report,
    encode,
    per_document_mse,
    reconstruct,
    split_train_val,
    svd_baseline,
    pca_baseline,
    train_autoencoder,
)
from src.config import add_common_args, config_from_args, seed_everything  # noqa: E402
from src.data import read_jsonl  # noqa: E402
from src.logging_utils import banner, get_logger  # noqa: E402

ROLE_FAMILIES = [
    "Finance & Legal",
    "Sales & BD",
    "Marketing",
    "Data & AI",
    "Product",
    "Engineering",
    "Design & Creative",
    "Operations & HR",
    "Leadership",
    "unknown",
]


def load_all(cfg):
    payloads: dict[str, dict] = {}
    meta: dict[str, dict] = {}
    for fname in ("jd_extracted.jsonl", "cv_extracted.jsonl"):
        for row in read_jsonl(cfg.path("processed") / fname):
            payloads[row["doc_id"]] = row["payload"]
            meta[row["doc_id"]] = {
                "doc_type": row["doc_type"],
                "split": row["split"],
                "title": row["title"],
                "role_family": row["role_family"],
                "status": row["status"],
            }
    return payloads, meta


def main() -> int:
    ap = argparse.ArgumentParser(description="Stage 3: autoencoder document encoder")
    add_common_args(ap)
    args = ap.parse_args()

    cfg = config_from_args(args)
    seed_everything(cfg.seed)
    log = get_logger("03_build_autoencoder", cfg.path("logs"), quiet=args.quiet)
    banner(log, "STAGE 3 - document x cluster matrix + autoencoder")

    if not TORCH_AVAILABLE:
        log.error("PyTorch is not available")
        return 2

    import torch

    processed = cfg.ensure_dir("processed")
    models_dir = cfg.ensure_dir("models")
    tables = cfg.ensure_dir("tables")

    payloads, meta = load_all(cfg)
    keyword_to_cluster = {k: int(v) for k, v in json.loads((processed / "keyword_to_cluster.json").read_text()).items()}
    cluster_metrics = json.loads((processed / "cluster_metrics.json").read_text())
    n_clusters = int(cluster_metrics["n_clusters"])
    log.info("documents=%d clusters=%d keywords_mapped=%d", len(payloads), n_clusters, len(keyword_to_cluster))

    # ------------------------------------------------------------- matrix
    X, doc_ids, index = build_document_matrix(payloads, meta, keyword_to_cluster, n_clusters)
    log.info("document matrix: %s, nnz=%d, density=%.4f", X.shape, X.nnz, X.nnz / (X.shape[0] * X.shape[1]))

    sp.save_npz(processed / "document_keyword_matrix.npz", X)
    index.to_csv(processed / "document_matrix_index.csv", index=False)

    # metadata matrix
    excel_countries = sorted(
        {
            str(m.get("country"))
            for m in meta.values()
            if m.get("country") and str(m.get("country")) not in {"nan", "None"}
        }
    )[:15]
    countries = excel_countries + ["Malaysia", "Singapore", "Indonesia", "Hong Kong", "Vietnam"]
    countries = list(dict.fromkeys(countries))
    meta_df = build_metadata_matrix(payloads, meta, doc_ids, ROLE_FAMILIES, countries)
    meta_df.to_csv(processed / "metadata_matrix.csv", index=False)
    log.info("metadata matrix: %s", meta_df.shape)

    # ------------------------------------------------------- train/val split
    doc_types = [meta[d]["doc_type"] for d in doc_ids]
    splits = [meta[d]["split"] for d in doc_ids]
    train_pool = [i for i, s in enumerate(splits) if s == "train"]
    heldout_idx = [i for i, s in enumerate(splits) if s == "heldout"]
    log.info("training pool: %d, held-out: %d", len(train_pool), len(heldout_idx))

    X_train_pool = X[train_pool]
    pool_types = [doc_types[i] for i in train_pool]
    tr_idx, va_idx = split_train_val(X_train_pool, pool_types, float(cfg.get("autoencoder.val_fraction", 0.15)), cfg.seed)
    X_train = X_train_pool[tr_idx].toarray().astype(np.float32)
    X_val = X_train_pool[va_idx].toarray().astype(np.float32)
    X_all = X.toarray().astype(np.float32)
    log.info("AE train=%d val=%d all=%d input_dim=%d", len(X_train), len(X_val), len(X_all), X.shape[1])

    # ------------------------------------------------------------- ablation
    ablation_rows: list[dict] = []
    trained: dict[tuple[int, float, bool], AEResult] = {}

    def _train(latent: int, dropout: float, denoise: bool) -> AEResult:
        key = (latent, dropout, denoise)
        if key in trained:
            return trained[key]
        log.info("training: latent=%d dropout=%.1f denoising=%s", latent, dropout, denoise)
        res = train_autoencoder(
            X_train,
            X_val,
            hidden=[int(h) for h in cfg.get("autoencoder.hidden_dims", [256, 64])],
            latent_dim=int(latent),
            dropout=float(dropout),
            denoising=bool(denoise),
            denoise_rate=float(cfg.get("autoencoder.denoise_rate", 0.10)),
            lr=float(cfg.get("autoencoder.lr", 1e-3)),
            weight_decay=float(cfg.get("autoencoder.weight_decay", 1e-4)),
            batch_size=int(cfg.get("autoencoder.batch_size", 16)),
            max_epochs=int(cfg.get("autoencoder.max_epochs", 500)),
            patience=int(cfg.get("autoencoder.patience", 40)),
            grad_clip=float(cfg.get("autoencoder.grad_clip", 1.0)),
            seed=cfg.seed,
            log=log,
        )
        trained[key] = res
        return res

    ab = cfg.get("autoencoder.ablation", {})
    for latent in ab.get("latent_dims", [32]):
        for dropout in ab.get("dropouts", [0.2]):
            for denoise in ab.get("denoising", [False]):
                res = _train(int(latent), float(dropout), bool(denoise))
                ablation_rows.append(
                    {
                        "latent_dim": int(latent),
                        "dropout": float(dropout),
                        "denoising": bool(denoise),
                        "train_mse": round(res.train_mse, 6),
                        "val_mse": round(res.val_mse, 6),
                        "best_epoch": res.best_epoch,
                        "epochs_run": len(res.history),
                        "nan_seen": res.nan_seen,
                    }
                )

    ablation = pd.DataFrame(ablation_rows).sort_values("val_mse").reset_index(drop=True)
    ablation["is_primary_preregistered"] = [
        int(r["latent_dim"] == int(cfg.get("autoencoder.latent_dim", 32))
            and abs(r["dropout"] - float(cfg.get("autoencoder.dropout", 0.2))) < 1e-9
            and bool(r["denoising"]) == bool(cfg.get("autoencoder.denoising", False)))
        for _, r in ablation.iterrows()
    ]
    ablation["is_val_selected"] = (ablation.index == 0).astype(int)
    ablation.to_csv(processed / "ae_ablation.csv", index=False)
    log.info("ablation complete:\n%s", ablation.to_string(index=False))

    # The PRIMARY model is the a-priori configuration named in the brief
    # (latent 32, dropout 0.2, denoising off) and is *not* selected on test recall.
    primary_cfg = (
        int(cfg.get("autoencoder.latent_dim", 32)),
        float(cfg.get("autoencoder.dropout", 0.2)),
        bool(cfg.get("autoencoder.denoising", False)),
    )
    res = _train(*primary_cfg)
    log.info("primary (pre-registered) config: latent=%d dropout=%.1f denoising=%s", *primary_cfg)

    # The validation-MSE-selected config is saved separately as an exploratory variant.
    best_row = ablation.iloc[0]
    best_cfg = (int(best_row["latent_dim"]), float(best_row["dropout"]), bool(best_row["denoising"]))
    res_best = _train(*best_cfg)
    log.info("validation-selected config: latent=%d dropout=%.1f denoising=%s (val MSE %.6f)",
             *best_cfg, res_best.val_mse)
    if res.nan_seen:
        log.error("NaNs encountered during training")

    # save model (primary = pre-registered config)
    torch.save(res.model.state_dict(), models_dir / "autoencoder.pt")
    res.history.to_csv(models_dir / "ae_training_history.csv", index=False)

    # save the validation-selected variant separately for the ablation comparison
    if best_cfg != primary_cfg:
        torch.save(res_best.model.state_dict(), models_dir / "autoencoder_valsel.pt")
        res_best.history.to_csv(models_dir / "ae_training_history_valsel.csv", index=False)

    vectorizer = {
        "cluster_labels": json.loads((processed / "cluster_metrics.json").read_text()).get("cluster_method"),
        "n_clusters": n_clusters,
        "section_weights": FIELD_WEIGHTS,
        "document_order": doc_ids,
        "idf": None,
        "cluster_vocabulary": sorted(set(keyword_to_cluster.values())),
        "keyword_to_cluster_size": len(keyword_to_cluster),
        "tfidf": "TfidfTransformer(sublinear_tf=True, norm='l2') on log1p weighted counts",
    }
    (models_dir / "vectorizer.json").write_text(json.dumps(vectorizer, indent=2), encoding="utf-8")

    # ---------------------------------------------------------- encode all
    Z_all = encode(res.model, X_all)
    rec_all = reconstruct(res.model, X_all)
    doc_mse = per_document_mse(res.model, X_all)

    emb = pd.DataFrame(Z_all, columns=[f"dim_{i + 1:02d}" for i in range(Z_all.shape[1])])
    emb.insert(0, "doc_id", doc_ids)
    emb.insert(1, "doc_type", doc_types)
    emb.insert(2, "split", splits)
    emb.insert(3, "title", [meta[d]["title"] for d in doc_ids])
    emb.insert(4, "role_family", [meta[d]["role_family"] for d in doc_ids])
    emb.insert(5, "seniority", [payloads[d].get("seniority") for d in doc_ids])
    emb.to_csv(processed / "document_embeddings.csv", index=False)

    recon_df = pd.DataFrame(
        {
            "doc_id": doc_ids,
            "doc_type": doc_types,
            "split": splits,
            "reconstruction_mse": np.round(doc_mse, 6),
            "input_nnz": np.asarray((X_all > 0).sum(axis=1)).ravel(),
            "cosine_reconstruction": [round(cosine_reconstruction(X_all[i], rec_all[i]), 6) for i in range(len(doc_ids))],
        }
    )
    recon_df.to_csv(processed / "ae_reconstruction.csv", index=False)

    dead = dead_unit_report(Z_all)
    log.info("latent space check: %s", dead)

    cfg_out = {
        "input_dim": int(X.shape[1]),
        "hidden_dims": res.architecture[1:-2][: len(res.architecture) // 2 - 1],
        "latent_dim": res.latent_dim,
        "dropout": res.dropout,
        "denoising": res.denoising,
        "seed": cfg.seed,
        "best_epoch": res.best_epoch,
        "epochs_run": len(res.history),
        "train_mse": round(res.train_mse, 6),
        "val_mse": round(res.val_mse, 6),
        "val_gap": round(res.val_mse - res.train_mse, 6),
        "n_clusters": n_clusters,
        "n_train": res.n_train,
        "n_val": res.n_val,
        "n_documents": len(doc_ids),
        "architecture": res.architecture,
        "cluster_method": cluster_metrics["cluster_method"],
        "embedding_method": cluster_metrics["embedding_method"],
        "vectorizer_hash": __import__("hashlib").sha256(
            json.dumps(vectorizer, sort_keys=True).encode()
        ).hexdigest()[:16],
        "dead_units": dead["dead_units"],
        "training_corpus": "100 pool CVs + 50 unlabelled JDs (minus GT near-duplicates); held-out = 10 GT JDs + 10 hired CVs",
        "selected_by": "PRIMARY = a-priori config from the brief (latent 32, dropout 0.2, denoising off), never chosen on test recall",
        "validation_selected_config": {
            "latent_dim": int(best_cfg[0]),
            "dropout": float(best_cfg[1]),
            "denoising": bool(best_cfg[2]),
            "val_mse": round(res_best.val_mse, 6),
            "train_mse": round(res_best.train_mse, 6),
            "best_epoch": res_best.best_epoch,
            "role": "exploratory ablation variant, reported separately as M3v",
        },
        "loss": "MSE + (1 - cosine) composite reconstruction loss",
        "nan_seen": res.nan_seen,
    }
    (models_dir / "autoencoder_config.json").write_text(json.dumps(cfg_out, indent=2), encoding="utf-8")

    # ------------------------------------------------------- AE vs SVD/PCA
    latent = res.latent_dim
    rows: list[dict] = []
    ae_val_mse = float(((rec_all[train_pool][va_idx] - X_all[train_pool][va_idx]) ** 2).mean())
    rows.append(
        {
            "model": f"AE-{latent}",
            "reconstruction_mse": round(ae_val_mse, 6),
            "mean_cosine_reconstruction": round(float(recon_df["cosine_reconstruction"].mean()), 6),
            "explained_variance": None,
            "n_components": latent,
        }
    )
    for name, fn in (("SVD", svd_baseline), ("PCA", pca_baseline)):
        try:
            Zb, recb, fitted = fn(X_train, X_all, latent, cfg.seed)
            val_mse = float(((recb[train_pool][va_idx] - X_all[train_pool][va_idx]) ** 2).mean())
            ev = float(getattr(fitted, "explained_variance_ratio_", np.zeros(0)).sum()) if name == "PCA" else None
            cosines = [cosine_reconstruction(X_all[i], recb[i]) for i in range(len(doc_ids))]
            rows.append(
                {
                    "model": f"{name}-{latent}",
                    "reconstruction_mse": round(val_mse, 6),
                    "mean_cosine_reconstruction": round(float(np.mean(cosines)), 6),
                    "explained_variance": round(ev, 6) if ev is not None else None,
                    "n_components": latent,
                }
            )
        except Exception as exc:  # noqa: BLE001
            log.warning("%s baseline failed: %s", name, exc)
    ae_vs = pd.DataFrame(rows)
    ae_vs.to_csv(tables / "ae_vs_svd.csv", index=False)
    log.info("AE vs SVD/PCA:\n%s", ae_vs.to_string(index=False))

    # ------------------------------------------ reconstruction examples
    cluster_labels = (
        pd.read_csv(processed / "keyword_clusters.csv").sort_values("cluster_id")["canonical_label"].tolist()
    )
    ex_rows: list[dict] = []
    picks = []
    cvs = [d for d, t in zip(doc_ids, doc_types) if t in {"pool_cv", "gt_cv"}][:3]
    jds = [d for d, t in zip(doc_ids, doc_types) if t in {"gt_jd", "unlabelled_jd"}][:2]
    picks = cvs + jds
    for doc_id in picks:
        i = doc_ids.index(doc_id)
        inp = X_all[i]
        rec = rec_all[i]
        top_in = np.argsort(-inp)[:10]
        top_rec = np.argsort(-rec)[:10]
        for rank, (a, b) in enumerate(zip(top_in, top_rec), start=1):
            ex_rows.append(
                {
                    "doc_id": doc_id,
                    "doc_type": doc_types[i],
                    "rank": rank,
                    "input_cluster": cluster_labels[a] if a < len(cluster_labels) else a,
                    "input_value": round(float(inp[a]), 6),
                    "reconstructed_cluster": cluster_labels[b] if b < len(cluster_labels) else b,
                    "reconstructed_value": round(float(rec[b]), 6),
                    "overlap": int(a == b),
                }
            )
    pd.DataFrame(ex_rows).to_csv(tables / "reconstruction_examples.csv", index=False)

    summary = {
        "matrix_shape": list(X.shape),
        "matrix_nnz": int(X.nnz),
        "n_train_docs": int(len(X_train)),
        "n_val_docs": int(len(X_val)),
        "n_heldout_docs": len(heldout_idx),
        "selected": {
            "latent_dim": res.latent_dim,
            "dropout": res.dropout,
            "denoising": res.denoising,
            "best_epoch": res.best_epoch,
            "train_mse": round(res.train_mse, 6),
            "val_mse": round(res.val_mse, 6),
        },
        "dead_units": dead,
        "ablation_rows": len(ablation),
        "nan_seen": res.nan_seen,
    }
    (processed / "stage3_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    print("\n--- STAGE 3 SUMMARY ---")
    print(json.dumps(summary, indent=2))
    print("-----------------------\n")

    ok = (
        len(doc_ids) >= 160
        and not res.nan_seen
        and dead["dead_units"] == 0
        and (models_dir / "autoencoder.pt").is_file()
    )
    if not ok:
        log.error("Stage 3 acceptance criteria not met")
        return 1
    log.info("Stage 3 acceptance criteria met")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
