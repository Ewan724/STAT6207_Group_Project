"""Stage 7 (part 2) - build a standalone offline HTML report.

Everything is inlined or referenced with relative paths, so the report can be
opened from disk with no network access and no CDN.
"""

from __future__ import annotations

import argparse
import base64
import html
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

from src.config import add_common_args, config_from_args  # noqa: E402
from src.logging_utils import banner, get_logger  # noqa: E402

CSS = """
:root {--navy:#0B2545;--teal:#0F7B6C;--coral:#C1292E;--grey:#6B7280;--line:#DCE4EE;--bg:#F7F9FC;}
* {box-sizing:border-box;}
body {margin:0;padding:0;background:#fff;color:#1F2937;
      font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif;
      font-size:15px;line-height:1.55;}
header {background:var(--navy);color:#fff;padding:28px 40px 22px;}
header h1 {margin:0;font-size:1.7rem;font-weight:650;letter-spacing:-0.01em;}
header p {margin:6px 0 0;color:#C7D4E4;font-size:0.9rem;max-width:900px;}
nav {position:sticky;top:0;background:#fff;border-bottom:1px solid var(--line);padding:10px 40px;z-index:10;font-size:0.85rem;}
nav a {color:var(--navy);text-decoration:none;margin-right:18px;}
nav a:hover {color:var(--teal);text-decoration:underline;}
main {max-width:1180px;margin:0 auto;padding:30px 40px 60px;}
h2 {color:var(--navy);font-size:1.25rem;margin-top:2.2rem;border-bottom:2px solid var(--line);padding-bottom:6px;}
h3 {color:var(--navy);font-size:1.02rem;margin-top:1.6rem;}
table {border-collapse:collapse;width:100%;margin:14px 0;font-size:0.82rem;}
th {background:var(--bg);color:var(--navy);text-align:left;padding:7px 9px;border-bottom:2px solid var(--line);white-space:nowrap;}
td {padding:6px 9px;border-bottom:1px solid #EEF2F6;vertical-align:top;}
tr:hover td {background:#FAFCFE;}
.cards {display:flex;gap:14px;flex-wrap:wrap;margin:16px 0;}
.card {flex:1 1 150px;background:var(--bg);border:1px solid var(--line);border-radius:9px;padding:12px 16px;}
.card .label {font-size:0.7rem;color:#5A6B82;text-transform:uppercase;letter-spacing:0.05em;}
.card .value {font-size:1.5rem;color:var(--navy);font-weight:700;line-height:1.25;}
.card .sub {font-size:0.72rem;color:var(--grey);}
.hit {color:var(--teal);font-weight:600;}
.miss {color:var(--coral);font-weight:600;}
.pill {display:inline-block;padding:1px 8px;border-radius:999px;font-size:0.7rem;font-weight:650;background:#EEF2F6;color:#475569;}
.pill.hit {background:#DFF3EE;color:var(--teal);}
.pill.miss {background:#FBE9E7;color:var(--coral);}
.pill.hired {background:var(--navy);color:#fff;}
.note {background:var(--bg);border-left:3px solid var(--teal);padding:10px 16px;font-size:0.86rem;margin:14px 0;}
.warn {background:#FFF8E6;border-left:3px solid #E69F00;padding:10px 16px;font-size:0.86rem;margin:14px 0;color:#5C4400;}
figure {margin:18px 0;}
figure img {width:100%;border:1px solid var(--line);border-radius:8px;}
figcaption {font-size:0.76rem;color:var(--grey);margin-top:6px;}
code {background:#F1F5F9;padding:1px 5px;border-radius:4px;font-size:0.85em;
      font-family:ui-monospace,SFMono-Regular,Consolas,monospace;}
footer {border-top:1px solid var(--line);margin-top:40px;padding:18px 40px;font-size:0.75rem;color:var(--grey);}
.scroll {overflow-x:auto;}
"""

FIG_ORDER = [
    ("01_pipeline_diagram.png", "Seven-stage pipeline. Every stage is cached and resumable."),
    ("02_dataset_overview.png", "Document counts, role-family distribution and character-length distribution."),
    ("03_keyword_cluster_network.png", "Cluster co-occurrence network: node size = document frequency, colour = coherence."),
    ("04_keyword_cluster_sizes.png", "The 30 largest keyword clusters with member count and document frequency."),
    ("05_keyword_merge_examples.png", "Raw variants merged into each canonical label."),
    ("05b_keyword_coverage_heatmap.png", "Top 25 clusters against role family: the keyword landscape."),
    ("06_ae_architecture.png", "Autoencoder: input → 256 → 64 → 32 → 64 → 256 → input."),
    ("07_ae_loss_curves.png", "Train and validation reconstruction MSE per epoch, best epoch marked."),
    ("08_ae_reconstruction_error.png", "Per-document reconstruction error, split by document type."),
    ("08b_ae_reconstruction_examples.png", "Top-10 clusters: input profile vs AE reconstruction."),
    ("09_latent_space_pca.png", "PCA of the latent space; lines connect each labelled JD to its hired CV."),
    ("11_recall_by_jd.png", "Rank of the hired CV per labelled JD under the primary model M3."),
    ("12_metric_comparison.png", "Recall@10, Hit@1, Hit@5 and MRR@10 across M0–M6."),
    ("13_rank_distribution.png", "Distribution of the hired CV's rank in buckets."),
    ("14_score_margin.png", "Hired-CV score minus the top-1 score for each query."),
    ("15_case_study_keyword_coverage.png", "Case studies: must-have cluster coverage of the top-10 candidates."),
    ("16_ae_vs_tfidf_ranks.png", "Hired-CV rank under TF-IDF vs the autoencoder, per query."),
    ("17_error_taxonomy.png", "Primary failure category counts for the misses under M3."),
    ("19_recommendation_matrix.png", "Recommendations plotted by expected impact against implementation effort."),
    ("20_extraction_quality.png", "LLM extraction quality against the Excel `Skills` silver standard."),
]


def img_tag(path: Path) -> str:
    data = base64.b64encode(path.read_bytes()).decode("ascii")
    return f'<img alt="{html.escape(path.name)}" src="data:image/png;base64,{data}">'


def table_html(df: pd.DataFrame, max_rows: int | None = None) -> str:
    d = df.head(max_rows) if max_rows else df
    head = "".join(f"<th>{html.escape(str(c))}</th>" for c in d.columns)
    body = []
    for _, r in d.iterrows():
        cells = []
        for c in d.columns:
            v = r[c]
            if isinstance(v, float):
                txt = f"{v:.4f}" if abs(v) < 1000 else f"{v:.1f}"
            else:
                txt = "" if pd.isna(v) else str(v)
            cells.append(f"<td>{html.escape(txt)}</td>")
        body.append("<tr>" + "".join(cells) + "</tr>")
    return f'<div class="scroll"><table><thead><tr>{head}</tr></thead><tbody>{"".join(body)}</tbody></table></div>'


def main() -> int:
    ap = argparse.ArgumentParser(description="Stage 7b: standalone HTML report")
    add_common_args(ap)
    args = ap.parse_args()

    cfg = config_from_args(args)
    log = get_logger("07_build_report", cfg.path("logs"), quiet=args.quiet)
    banner(log, "STAGE 7b - standalone HTML report")

    processed = cfg.path("processed")
    figures = cfg.path("figures")
    tables = cfg.path("tables")
    results = cfg.ensure_dir("results")

    needed = [processed / "metrics_summary.csv", processed / "top10.csv", results / "error_analysis.md"]
    missing = [p for p in needed if not p.is_file()]
    if missing:
        log.error("cannot build the report, missing: %s", [str(m) for m in missing])
        return 2

    summary = pd.read_csv(processed / "metrics_summary.csv")
    per_q = pd.read_csv(processed / "metrics_per_query.csv")
    gt = pd.read_csv(processed / "ground_truth.csv", keep_default_na=False, na_values=[""])
    stage0 = json.loads((processed / "stage0_summary.json").read_text())
    ae = json.loads((cfg.path("models") / "autoencoder_config.json").read_text())
    metrics = json.loads((processed / "cluster_metrics.json").read_text())
    extraction = json.loads((processed / "extraction_summary.json").read_text())
    tax = pd.read_csv(processed / "failure_taxonomy.csv")
    cmp_df = pd.read_csv(tables / "ae_vs_tfidf.csv")
    recs = pd.read_csv(processed / "recommendations.csv")
    top10 = pd.read_csv(processed / "top10.csv")
    per_query_msg = pd.read_csv(processed / "metrics_per_query.csv")

    primary = summary[summary["model"] == "M3"].iloc[0]
    m0 = summary[summary["model"] == "M0"].iloc[0]

    parts: list[str] = []
    A = parts.append

    A("<!DOCTYPE html><html lang='en'><head><meta charset='utf-8'>")
    A("<meta name='viewport' content='width=device-width, initial-scale=1'>")
    A("<title>AI CV Matching — Baseline Report</title>")
    A(f"<style>{CSS}</style></head><body>")

    A("<header><h1>AI CV Matching — Baseline Report</h1>")
    A(
        "<p>Second Talent · STAT6207 group assignment. Keyword- and representation-based baseline: "
        "local-LLM extraction → keyword clustering → autoencoder → cosine retrieval → Recall@10 → error analysis. "
        "110 candidates, 10 labelled queries, n = 10.</p></header>"
    )
    A(
        "<nav><a href='#headline'>Metrics</a><a href='#data'>Data</a><a href='#pipeline'>Pipeline</a>"
        "<a href='#keywords'>Keywords</a><a href='#ae'>Autoencoder</a><a href='#recall'>Recall</a>"
        "<a href='#errors'>Errors</a><a href='#recommendations'>Recommendations</a>"
        "<a href='#limitations'>Limitations</a></nav>"
    )
    A("<main>")

    # -------------------------------------------------------------- headline
    A("<h2 id='headline'>Headline metrics</h2>")
    A("<div class='cards'>")
    for label, value, sub in [
        ("Recall@10 (M3)", f"{primary['recall_at_10']:.2f}", f"{int(primary['hits'])}/10 hits"),
        ("Hit@1", f"{primary['hit_at_1']:.2f}", "hired CV first"),
        ("Hit@5", f"{primary['hit_at_5']:.2f}", "within top 5"),
        ("MRR@10", f"{primary['mrr_at_10']:.3f}", "mean reciprocal rank"),
        ("Random baseline", f"{m0['recall_at_10']:.2f}", "expected 10/110"),
    ]:
        A(f"<div class='card'><div class='label'>{label}</div><div class='value'>{value}</div><div class='sub'>{sub}</div></div>")
    A("</div>")
    A(
        f"<p>95% Wilson CI for the primary model's Recall@10: "
        f"[<b>{primary['wilson_ci_low']:.2f}</b>, <b>{primary['wilson_ci_high']:.2f}</b>]. "
        f"Bootstrap CI (10,000 resamples): [{primary['bootstrap_ci_low']:.2f}, {primary['bootstrap_ci_high']:.2f}]. "
        f"With 10 queries, one hit changes the mean by 0.10 and no difference between models is statistically "
        f"meaningful.</p>"
    )
    A(table_html(summary[["model", "model_name", "hits", "recall_at_10", "hit_at_1", "hit_at_5", "mrr_at_10", "wilson_ci_low", "wilson_ci_high"]]))
    A(
        "<div class='note'><b>Recall@10 vs Precision@10.</b> Recall@10 = (# relevant retrieved in the top 10) / "
        "(# relevant total). With exactly one relevant CV per JD it is 1 if the hired CV is in the top 10, else 0, so "
        "the mean is a hit rate. Precision@10 = (# relevant in the top 10) / 10 and its maximum here is 0.1; it is "
        "not recall.</div>"
    )

    # ------------------------------------------------------------------ data
    A("<h2 id='data'>Data</h2>")
    A(
        f"<p><b>{stage0['pool_cvs']}</b> pool CVs, <b>{stage0['gt_cvs']}</b> hired CVs (neutral IDs CAND-101…110), "
        f"<b>{stage0['gt_jds']}</b> labelled JDs, <b>{stage0['unlabelled_jds']}</b> unlabelled JDs — "
        f"<b>{stage0['unique_candidates']} unique candidates</b>. True duplicates found: {stage0['true_duplicates']}. "
        f"Unlabelled JDs excluded as near-duplicates of a labelled JD: {stage0['jd_near_duplicates_excluded']}.</p>"
    )
    A(table_html(gt[["jd_id", "jd_title", "role_family", "hired_cv_id", "hired_cv_title", "hired_cv_company"]]))

    # -------------------------------------------------------------- pipeline
    A("<h2 id='pipeline'>Pipeline and dataset overview</h2>")
    for name, cap in FIG_ORDER[:2]:
        p = figures / name
        if p.is_file():
            A(f"<figure>{img_tag(p)}<figcaption>{html.escape(cap)}</figcaption></figure>")

    # -------------------------------------------------------------- keywords
    A("<h2 id='keywords'>Keyword extraction and merging</h2>")
    A(
        f"<p>{extraction['documents_attempted']} documents attempted with a local Ollama model, "
        f"{extraction['success_rate']:.1%} success rate, {extraction['fallback_count']} rule-based fallbacks, "
        f"{extraction['unsupported_keywords']} unsupported keywords dropped. "
        f"{metrics['n_clusters']} canonical clusters from {metrics['n_keywords_train']:,} training keywords "
        f"(singleton rate {metrics['singleton_rate']:.2f}, mean coherence {metrics['mean_coherence']:.2f}, "
        f"embedding <code>{metrics['embedding_method']}</code>). "
        f"Manual merge review accuracy: {metrics['manual_merge_review']['accuracy']:.0%} "
        f"({metrics['manual_merge_review']['n_correct']}/{metrics['manual_merge_review']['n_reviewed']}).</p>"
    )
    guard_rows = pd.DataFrame(
        [{"pair": k, "status": "PASS" if not v["merged"] else "FAIL"} for k, v in metrics["guardrails"].items()]
    )
    A(table_html(guard_rows))
    for name, cap in FIG_ORDER[2:6]:
        p = figures / name
        if p.is_file():
            A(f"<figure>{img_tag(p)}<figcaption>{html.escape(cap)}</figcaption></figure>")

    # ------------------------------------------------------------------- AE
    A("<h2 id='ae'>Autoencoder</h2>")
    A(
        f"<p>Architecture <code>{ae['architecture']}</code>, latent dim {ae['latent_dim']}, dropout {ae['dropout']}, "
        f"denoising {ae['denoising']}. Selected on validation reconstruction MSE "
        f"(best epoch {ae['best_epoch']}, train MSE {ae['train_mse']:.3e}, validation MSE {ae['val_mse']:.3e}, "
        f"gap {ae['val_gap']:.3e}). Trained on {ae['n_train']} documents, validated on {ae['n_val']}. "
        f"NaNs: {ae['nan_seen']} — dead latent units: {ae['dead_units']}. "
        f"Training corpus: {html.escape(ae['training_corpus'])}.</p>"
    )
    p = tables / "ae_vs_svd.csv"
    if p.is_file():
        A("<h3>AE vs SVD / PCA</h3>")
        A(table_html(pd.read_csv(p)))
    for name, cap in FIG_ORDER[6:11]:
        p = figures / name
        if p.is_file():
            A(f"<figure>{img_tag(p)}<figcaption>{html.escape(cap)}</figcaption></figure>")

    # --------------------------------------------------------------- recall
    A("<h2 id='recall'>Recall@10 and per-query results</h2>")
    A(table_html(per_query_msg[per_query_msg["model"] == "M3"][["jd_id", "rank", "score", "hit_at_10", "must_have_coverage_hired", "top1_cv_id"]]))
    for name, cap in FIG_ORDER[11:15]:
        p = figures / name
        if p.is_file():
            A(f"<figure>{img_tag(p)}<figcaption>{html.escape(cap)}</figcaption></figure>")

    A("<h3>Top 10 for every labelled JD under M3</h3>")
    for jd_id in gt["jd_id"]:
        sub = top10[(top10["model"] == "M3") & (top10["jd_id"] == jd_id)].sort_values("rank")
        title = gt[gt["jd_id"] == jd_id]["jd_title"].iloc[0]
        A(f"<h4 style='color:#0B2545;font-size:0.95rem;margin-top:1.2rem'>{jd_id} — {html.escape(str(title))}</h4>")
        A(table_html(sub[["rank", "cv_id", "cv_title", "cv_company", "score", "is_relevant", "reason"]]))

    # --------------------------------------------------------------- errors
    A("<h2 id='errors'>Error analysis</h2>")
    A("<h3>Failure taxonomy (M3)</h3>")
    A(table_html(tax[["code", "category", "count", "definition"]]))
    A("<h3>AE vs TF-IDF</h3>")
    A(table_html(cmp_df[["jd_id", "tfidf_rank", "ae_rank", "delta", "winner"]]))
    for name, cap in FIG_ORDER[15:19]:
        p = figures / name
        if p.is_file():
            A(f"<figure>{img_tag(p)}<figcaption>{html.escape(cap)}</figcaption></figure>")

    md = (results / "error_analysis.md").read_text(encoding="utf-8")
    A("<h3>Full narrative</h3>")
    A("<div class='note'>The complete narrative, including a paragraph for each of the 10 queries and four "
      "case studies, is reproduced below verbatim from <code>results/error_analysis.md</code>.</div>")
    A(f"<pre style='white-space:pre-wrap;font-family:inherit;font-size:0.85rem'>{html.escape(md)}</pre>")

    # ------------------------------------------------------- recommendations
    A("<h2 id='recommendations'>Recommendations</h2>")
    A(table_html(recs[["priority", "issue", "evidence", "proposed_fix", "expected_impact", "effort"]]))
    p = figures / "19_recommendation_matrix.png"
    if p.is_file():
        A(f"<figure>{img_tag(p)}<figcaption>Expected impact against implementation effort (all estimates are hypotheses).</figcaption></figure>")

    # ----------------------------------------------------------- limitations
    A("<h2 id='limitations'>Limitations</h2>")
    A(
        "<ul>"
        "<li>n = 10 labelled queries with exactly one relevant CV each; Recall@10 is a hit rate and the confidence interval is wide.</li>"
        "<li>The hired candidate is not necessarily the best on paper — interviews, salary, availability and recruiter judgement are invisible here.</li>"
        "<li>Salary, notice period, location, citizenship, work authorisation and language filters are not modelled.</li>"
        "<li>LLM extraction is noisy and the source PDFs are partly truncated with “…” — a missing mention is not proof of a missing skill.</li>"
        "<li>Keyword clustering is heuristic; rare synonyms can stay split and held-out keywords can be unmatched.</li>"
        "<li>The autoencoder optimises reconstruction, not ranking.</li>"
        "<li>The 110-CV pool may not represent the real candidate population.</li>"
        "<li>The 50 unlabelled JDs are not ground truth; they are training context only.</li>"
        "<li>No statistical significance is claimed anywhere.</li>"
        "</ul>"
    )
    A("</main>")

    A(
        "<footer>Data: anonymised Second Talent sample. Extraction: local Ollama model only "
        f"(<code>{html.escape(str(extraction['model']))}</code>, prompt hash <code>{extraction['prompt_hash']}</code>). "
        "No external API calls, no scraping, no data uploads. "
        f"Figures rendered at {200} dpi. Generated by <code>scripts/07_build_report.py</code>.</footer>"
    )
    A("</body></html>")

    out = results / "report.html"
    out.write_text("".join(parts), encoding="utf-8")
    log.info("wrote %s (%.1f KB)", out, out.stat().st_size / 1024)
    print(f"\nStandalone report: {out}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
