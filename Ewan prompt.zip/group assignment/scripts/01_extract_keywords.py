"""Stage 1 - local-LLM keyword extraction for all 170 documents.

Outputs:
    data/processed/jd_extracted.jsonl
    data/processed/cv_extracted.jsonl
    data/processed/extraction_failures.csv
    data/processed/extraction_summary.json
    data/processed/unsupported_keywords.csv
    data/processed/extraction_quality.csv
    results/tables/extraction_quality_summary.csv
    data/cache/llm/<doc_id>.json
"""

from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

from src.config import add_common_args, config_from_args  # noqa: E402
from src.data import load_documents, load_excel_cvs, read_jsonl, write_jsonl  # noqa: E402
from src.extraction import Extractor  # noqa: E402
from src.keywords import ALIAS_GROUPS, normalise_keyword  # noqa: E402
from src.llm import LLMCache, OllamaClient  # noqa: E402
from src.logging_utils import banner, get_logger  # noqa: E402


# --------------------------------------------------------------------------- #
# Extraction-quality silver standard (Excel Skills column)
# --------------------------------------------------------------------------- #
def _silver_set(skills_cell: str, alias_map: dict[str, str]) -> set[str]:
    if not isinstance(skills_cell, str):
        return set()
    out: set[str] = set()
    for raw in skills_cell.split(","):
        norm = normalise_keyword(raw)
        if not norm:
            continue
        out.add(alias_map.get(norm, norm))
    return out


def _llm_set(payload: dict, alias_map: dict[str, str]) -> set[str]:
    out: set[str] = set()
    for field in ("skills", "tools_technologies"):
        for raw in payload.get(field, []) or []:
            norm = normalise_keyword(raw)
            if not norm:
                continue
            out.add(alias_map.get(norm, norm))
    return out


def _fuzzy_overlap(a: set[str], b: set[str]) -> tuple[int, int]:
    """Count exact-or-substring matches between two canonical sets."""
    matched_a: set[str] = set()
    matched_b: set[str] = set()
    for x in a:
        for y in b:
            if x == y or (len(x) > 3 and x in y) or (len(y) > 3 and y in x):
                matched_a.add(x)
                matched_b.add(y)
    return len(matched_a), len(matched_b)


def extraction_quality(cv_payloads: dict[str, dict], excel: pd.DataFrame, alias_map: dict[str, str]) -> pd.DataFrame:
    rows: list[dict] = []
    for _, row in excel.iterrows():
        ref = str(row["Ref"]).strip()
        payload = cv_payloads.get(ref)
        if payload is None:
            rows.append({"doc_id": ref, "status": "missing", "precision": None, "recall": None, "f1": None})
            continue
        silver = _silver_set(row.get("Skills"), alias_map)
        pred = _llm_set(payload, alias_map)
        if not silver or not pred:
            rows.append(
                {
                    "doc_id": ref,
                    "status": "no_data",
                    "n_silver": len(silver),
                    "n_pred": len(pred),
                    "precision": None,
                    "recall": None,
                    "f1": None,
                }
            )
            continue
        tp_pred, tp_silver = _fuzzy_overlap(pred, silver)
        precision = tp_pred / len(pred) if pred else 0.0
        recall = tp_silver / len(silver) if silver else 0.0
        f1 = 2 * precision * recall / (precision + recall) if (precision + recall) else 0.0
        rows.append(
            {
                "doc_id": ref,
                "status": "ok",
                "n_silver": len(silver),
                "n_pred": len(pred),
                "n_matched_pred": tp_pred,
                "n_matched_silver": tp_silver,
                "precision": round(precision, 4),
                "recall": round(recall, 4),
                "f1": round(f1, 4),
            }
        )
    return pd.DataFrame(rows)


def main() -> int:
    ap = argparse.ArgumentParser(description="Stage 1: LLM keyword extraction")
    add_common_args(ap)
    args = ap.parse_args()

    cfg = config_from_args(args)
    log = get_logger("01_extract_keywords", cfg.path("logs"), quiet=args.quiet)
    banner(log, "STAGE 1 - local LLM keyword extraction")

    processed = cfg.ensure_dir("processed")
    docs = load_documents(cfg)
    if args.limit:
        docs = docs[: args.limit]
        log.info("limit=%d -> %d documents", args.limit, len(docs))

    client = OllamaClient(
        base_url=cfg.get("llm.base_url"),
        model=cfg.get("llm.model"),
        temperature=float(cfg.get("llm.temperature", 0.0)),
        top_p=float(cfg.get("llm.top_p", 1.0)),
        num_ctx=int(cfg.get("llm.num_ctx", 8192)),
        num_predict=int(cfg.get("llm.num_predict", 1600)),
        seed=cfg.seed,
        timeout=int(cfg.get("llm.timeout_bulk", 300)),
        max_retries=int(cfg.get("llm.max_retries", 2)),
        log=log,
    )

    # ------------------------------------------------------------ health
    try:
        tags = client.ping()
        names = [m.get("name") for m in tags.get("models", [])]
        log.info("Ollama reachable; installed models: %s", names)
    except Exception as exc:  # noqa: BLE001
        log.error("Ollama is not reachable at %s: %s", cfg.get("llm.base_url"), exc)
        return 2
    if not client.has_model(cfg.get("llm.model")):
        log.error("configured model %s is not installed", cfg.get("llm.model"))
        return 2

    cache = LLMCache(cfg.path("cache_llm"), log=log)
    extractor = Extractor(cfg, client, cache, log)
    log.info("prompt hash: %s", extractor.phash)

    results: list[dict] = []
    failures: list[dict] = []
    unsupported: list[dict] = []
    t_start = time.time()

    for i, doc in enumerate(docs, start=1):
        doc_type = "jd" if doc.doc_type in {"gt_jd", "unlabelled_jd"} else "cv"
        cached = None if args.force else cache.load(doc.doc_id, extractor.phash)
        t0 = time.time()
        try:
            res = extractor.extract(doc.doc_id, doc_type, doc.raw_text, force=args.force)
        except Exception as exc:  # noqa: BLE001
            log.error("%s FAILED: %s", doc.doc_id, exc)
            failures.append(
                {
                    "doc_id": doc.doc_id,
                    "doc_type": doc_type,
                    "status": "failed",
                    "error": str(exc),
                    "raw_response_path": "",
                }
            )
            continue

        record = {
            "doc_id": doc.doc_id,
            "doc_type": doc.doc_type,
            "source_path": doc.source_path,
            "title": doc.title,
            "role_family": doc.role_family,
            "split": doc.split,
            "status": res.status,
            "model": res.model,
            "elapsed_sec": round(res.elapsed_sec, 2),
            "n_dropped_keywords": len(res.dropped),
            "payload": res.payload,
        }
        results.append(record)

        for item in res.dropped:
            unsupported.append(
                {
                    "doc_id": doc.doc_id,
                    "field": item.get("field", ""),
                    "keyword": item.get("keyword", ""),
                    "reason": item.get("reason", ""),
                }
            )

        if res.status in {"fallback", "failed"}:
            failures.append(
                {
                    "doc_id": doc.doc_id,
                    "doc_type": doc_type,
                    "status": res.status,
                    "error": "; ".join(res.errors)[:500],
                    "raw_response_path": res.raw_path,
                }
            )

        elapsed = time.time() - t0
        cache_flag = "cache" if cached else "new"
        log.info(
            "[%3d/%3d] %-8s %-6s %5.1fs (%s) %s",
            i,
            len(docs),
            doc.doc_id,
            res.status,
            elapsed,
            cache_flag,
            doc.title[:40],
        )

    # ------------------------------------------------------------- outputs
    jd_rows = [r for r in results if r["doc_type"] in {"gt_jd", "unlabelled_jd"}]
    cv_rows = [r for r in results if r["doc_type"] in {"pool_cv", "gt_cv"}]
    write_jsonl(processed / "jd_extracted.jsonl", jd_rows)
    write_jsonl(processed / "cv_extracted.jsonl", cv_rows)
    pd.DataFrame(failures).to_csv(processed / "extraction_failures.csv", index=False)
    pd.DataFrame(unsupported).to_csv(processed / "unsupported_keywords.csv", index=False)

    statuses = pd.Series([r["status"] for r in results]).value_counts().to_dict()
    n_ok = statuses.get("ok", 0) + statuses.get("repaired", 0)
    success_rate = n_ok / len(docs) if docs else 0.0
    elapsed_total = time.time() - t_start

    summary = {
        "documents_attempted": len(docs),
        "documents_succeeded": n_ok,
        "success_rate": round(success_rate, 4),
        "status_counts": statuses,
        "fallback_count": statuses.get("fallback", 0),
        "failed_count": statuses.get("failed", 0),
        "mean_elapsed_sec": round(statistics.mean([r["elapsed_sec"] for r in results]), 2) if results else 0.0,
        "total_wall_sec": round(elapsed_total, 1),
        "model": cfg.get("llm.model"),
        "prompt_hash": extractor.phash,
        "cache_files": len(cache),
        "unsupported_keywords": len(unsupported),
        "jd_documents": len(jd_rows),
        "cv_documents": len(cv_rows),
    }
    (processed / "extraction_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    # -------------------------------------------------- extraction quality
    alias_map = {}
    for canonical, variants in ALIAS_GROUPS:
        for v in variants:
            n = normalise_keyword(v)
            if n:
                alias_map[n] = canonical
        n = normalise_keyword(canonical)
        if n:
            alias_map[n] = canonical

    cv_payloads = {r["doc_id"]: r["payload"] for r in cv_rows}
    excel = load_excel_cvs(cfg)
    quality = extraction_quality(cv_payloads, excel, alias_map)
    quality.to_csv(processed / "extraction_quality.csv", index=False)

    ok_q = quality[quality["status"] == "ok"]
    q_summary = pd.DataFrame(
        [
            {
                "n_documents": int(len(ok_q)),
                "macro_precision": round(float(ok_q["precision"].mean()), 4) if len(ok_q) else None,
                "macro_recall": round(float(ok_q["recall"].mean()), 4) if len(ok_q) else None,
                "macro_f1": round(float(ok_q["f1"].mean()), 4) if len(ok_q) else None,
                "median_f1": round(float(ok_q["f1"].median()), 4) if len(ok_q) else None,
                "worst_5": ok_q.nsmallest(5, "f1")[["doc_id", "f1"]].to_dict(orient="records") if len(ok_q) else [],
                "model": cfg.get("llm.model"),
                "prompt_hash": extractor.phash,
            }
        ]
    )
    q_summary.to_csv(cfg.path("tables") / "extraction_quality_summary.csv", index=False)

    print("\n--- STAGE 1 SUMMARY ---")
    print(json.dumps(summary, indent=2))
    print("\n--- EXTRACTION QUALITY (vs Excel Skills) ---")
    print(q_summary.to_string(index=False))
    print("-----------------------\n")

    if success_rate < 0.95:
        log.error("success rate %.3f is below the 0.95 threshold", success_rate)
        return 1
    log.info("Stage 1 acceptance criteria met")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
