"""Stage 7 (part 1) - render every static PNG into results/figures/.

All figures are >=200 dpi and are regenerated from saved artifacts only, so the
report and the website always show the same numbers.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

from src import plots  # noqa: E402
from src.config import add_common_args, config_from_args, seed_everything  # noqa: E402
from src.data import read_jsonl  # noqa: E402
from src.keywords import normalise_keyword  # noqa: E402
from src.logging_utils import banner, get_logger  # noqa: E402

ROLE_FAMILIES = [
    "Finance & Legal",
    "Sales & BD",
    "Marketing",
    "Data & AI",
    "Product",
    "Engineering",
    "Design & Creative",
    "Operations & HR",
    "Leadership",
    "unknown",
]


def load_all(cfg):
    payloads: dict[str, dict] = {}
    meta: dict[str, dict] = {}
    for fname in ("jd_extracted.jsonl", "cv_extracted.jsonl"):
        for row in read_jsonl(cfg.path("processed") / fname):
            payloads[row["doc_id"]] = row["payload"]
            meta[row["doc_id"]] = {
                "doc_type": row["doc_type"],
                "split": row["split"],
                "title": row["title"],
                "role_family": row["role_family"],
                "status": row["status"],
            }
    return payloads, meta


def main() -> int:
    ap = argparse.ArgumentParser(description="Stage 7a: render all figures")
    add_common_args(ap)
    args = ap.parse_args()

    cfg = config_from_args(args)
    seed_everything(cfg.seed)
    log = get_logger("06_make_figures", cfg.path("logs"), quiet=args.quiet)
    banner(log, "STAGE 7a - static figures")

    processed = cfg.path("processed")
    tables = cfg.path("tables")
    figures = cfg.ensure_dir("figures")
    models_dir = cfg.path("models")
    results = cfg.ensure_dir("results")

    payloads, meta_by_doc = load_all(cfg)
    meta = pd.read_csv(processed / "documents_meta.csv")
    gt = pd.read_csv(processed / "ground_truth.csv", keep_default_na=False, na_values=[""])
    clusters = pd.read_csv(processed / "keyword_clusters.csv")
    aliases = pd.read_csv(processed / "keyword_aliases.csv")
    edges = pd.read_csv(processed / "keyword_edges.csv")
    emb = pd.read_csv(processed / "document_embeddings.csv")
    recon = pd.read_csv(processed / "ae_reconstruction.csv")
    history = pd.read_csv(models_dir / "ae_training_history.csv")
    ae_cfg = json.loads((models_dir / "autoencoder_config.json").read_text())
    per_query = pd.read_csv(processed / "metrics_per_query.csv")
    summary = pd.read_csv(processed / "metrics_summary.csv")
    stage0 = json.loads((processed / "stage0_summary.json").read_text())
    quality = pd.read_csv(processed / "extraction_quality.csv")
    err = pd.read_csv(processed / "error_analysis.csv")
    tax = pd.read_csv(processed / "failure_taxonomy.csv")
    cmp_df = pd.read_csv(tables / "ae_vs_tfidf.csv")
    recs = pd.read_csv(processed / "recommendations.csv")
    recon_examples = pd.read_csv(tables / "reconstruction_examples.csv")

    alias_map = dict(zip(aliases["normalised_term"], aliases["canonical_term"]))
    made: list[str] = []

    def track(p: Path) -> None:
        made.append(p.name)
        log.info("figure %s", p.name)

    track(plots.fig_pipeline(figures, stage0))
    track(plots.fig_dataset_overview(figures, meta, gt))
    track(plots.fig_cluster_network(figures, clusters, edges))
    track(plots.fig_cluster_sizes(figures, clusters))
    track(plots.fig_merge_examples(figures, aliases, clusters))
    import scipy.sparse as _sp

    _index = pd.read_csv(processed / "document_matrix_index.csv")
    _X = _sp.load_npz(processed / "document_keyword_matrix.npz")
    track(plots.fig_keyword_heatmap(figures, clusters, meta, payloads, alias_map, doc_index=_index, doc_matrix=_X))
    track(plots.fig_ae_architecture(figures, ae_cfg["input_dim"], ae_cfg["hidden_dims"], ae_cfg["latent_dim"]))
    track(plots.fig_loss_curves(figures, history, int(ae_cfg["best_epoch"])))
    track(plots.fig_reconstruction_error(figures, recon))
    track(plots.fig_reconstruction_examples(figures, recon_examples))
    track(plots.fig_latent_pca(figures, emb, gt))

    try:
        track(plots.fig_latent_umap(figures, emb, gt))
    except Exception as exc:  # noqa: BLE001
        log.warning("UMAP/t-SNE figure failed: %s", exc)

    track(plots.fig_recall_by_jd(figures, per_query))
    track(plots.fig_metric_comparison(figures, summary))
    track(plots.fig_rank_distribution(figures, per_query))
    track(plots.fig_score_margin(figures, per_query))
    track(plots.fig_ae_vs_tfidf(figures, cmp_df))
    track(plots.fig_error_taxonomy(figures, tax))
    track(plots.fig_recommendations(figures, recs))
    track(plots.fig_extraction_quality(figures, quality))

    # ---------------- case-study coverage heatmaps -----------------------
    import numpy as np
    import scipy.sparse as sp

    index = pd.read_csv(processed / "document_matrix_index.csv")
    doc_ids = index["doc_id"].tolist()
    X_dense = sp.load_npz(processed / "document_keyword_matrix.npz").toarray().astype(np.float32)
    keyword_to_cluster = {k: int(v) for k, v in json.loads((processed / "keyword_to_cluster.json").read_text()).items()}
    rankings = pd.read_csv(processed / "rankings.csv")

    from src.analysis import case_study_matrix

    case_jds = cfg.get("analysis.case_study_jds", ["P01", "P04", "P08", "P10"])
    mats: dict[str, pd.DataFrame] = {}
    for jd_id in case_jds:
        mat, _ = case_study_matrix(rankings, jd_id, "M3", payloads, meta_by_doc, keyword_to_cluster, doc_ids, X_dense)
        mats[jd_id] = mat
        mat.to_csv(tables / f"case_study_{jd_id}_coverage.csv")

    # one combined figure + one figure per case study
    track(plots.fig_case_study_heatmap(figures, mats, "15_case_study_keyword_coverage.png", "Case studies: JD must-have cluster coverage of the top-10 candidates (M3)"))
    for jd_id, mat in mats.items():
        track(plots.fig_case_study_heatmap(figures, {jd_id: mat}, f"18_case_study_{jd_id}.png", f"Case study {jd_id}: must-have coverage, top 10 candidates"))

    made = [f.name for f in sorted(figures.glob("*.png"))]
    inventory = {
        "figures": made,
        "n_figures": len(made),
        "dpi": plots.DPI,
        "missing_required": [
            f
            for f in [
                "01_pipeline_diagram.png",
                "02_dataset_overview.png",
                "03_keyword_cluster_network.png",
                "04_keyword_cluster_sizes.png",
                "05_keyword_merge_examples.png",
                "05b_keyword_coverage_heatmap.png",
                "06_ae_architecture.png",
                "07_ae_loss_curves.png",
                "08_ae_reconstruction_error.png",
                "08b_ae_reconstruction_examples.png",
                "09_latent_space_pca.png",
                "11_recall_by_jd.png",
                "12_metric_comparison.png",
                "13_rank_distribution.png",
                "14_score_margin.png",
                "15_case_study_keyword_coverage.png",
                "16_ae_vs_tfidf_ranks.png",
                "17_error_taxonomy.png",
                "19_recommendation_matrix.png",
                "20_extraction_quality.png",
            ]
            if not (figures / f).is_file()
        ],
    }
    (results / "figure_inventory.json").write_text(json.dumps(inventory, indent=2), encoding="utf-8")

    print("\n--- FIGURE INVENTORY ---")
    print(json.dumps(inventory, indent=2))
    print("------------------------\n")
    return 1 if inventory["missing_required"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
