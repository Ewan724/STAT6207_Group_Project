"""Stage 6 - error analysis: taxonomy, case studies, AE vs TF-IDF, recommendations.

Outputs:
    data/processed/error_analysis.csv
    data/processed/case_study_*.csv
    data/processed/recommendations.csv
    results/error_analysis.md
    results/tables/ae_vs_tfidf.csv
    results/tables/case_study_*.csv
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from src.analysis import (  # noqa: E402
    CATEGORY_DEFINITIONS,
    FAILURE_CATEGORIES,
    ae_vs_tfidf,
    case_study_matrix,
    case_study_table,
    per_query_comparison,
    recommendations,
    taxonomy_counts,
)
from src.config import add_common_args, config_from_args, seed_everything  # noqa: E402
from src.data import read_jsonl  # noqa: E402
from src.logging_utils import banner, get_logger  # noqa: E402


def load_all(cfg):
    """Load extraction payloads with the leakage-safe role family applied.

    Uses the same resolver as the ranking stage so the reported role-family match
    agrees across every artifact.
    """
    from src.roles import resolve_role_family

    payloads: dict[str, dict] = {}
    meta: dict[str, dict] = {}
    for fname in ("jd_extracted.jsonl", "cv_extracted.jsonl"):
        for row in read_jsonl(cfg.path("processed") / fname):
            payloads[row["doc_id"]] = row["payload"]
            meta[row["doc_id"]] = {
                "doc_type": row["doc_type"],
                "split": row["split"],
                "title": row["title"],
                "role_family": resolve_role_family(
                    row["doc_type"], {"role_family": row["role_family"]}, row["payload"]
                ),
                "raw_role_family": row["role_family"],
                "status": row["status"],
            }
    return payloads, meta


def main() -> int:
    ap = argparse.ArgumentParser(description="Stage 6: error analysis")
    add_common_args(ap)
    args = ap.parse_args()

    cfg = config_from_args(args)
    seed_everything(cfg.seed)
    log = get_logger("05_error_analysis", cfg.path("logs"), quiet=args.quiet)
    banner(log, "STAGE 6 - error analysis")

    import scipy.sparse as sp

    processed = cfg.ensure_dir("processed")
    tables = cfg.ensure_dir("tables")
    figures = cfg.ensure_dir("figures")
    results = cfg.ensure_dir("results")

    payloads, meta = load_all(cfg)
    rankings = pd.read_csv(processed / "rankings.csv")
    index = pd.read_csv(processed / "document_matrix_index.csv")
    doc_ids = index["doc_id"].tolist()
    X = sp.load_npz(processed / "document_keyword_matrix.npz")
    X_dense = X.toarray().astype(np.float32)
    gt = pd.read_csv(processed / "ground_truth.csv", keep_default_na=False, na_values=[""])
    coverage = pd.read_csv(processed / "score_coverage.csv")
    keyword_to_cluster = {k: int(v) for k, v in json.loads((processed / "keyword_to_cluster.json").read_text()).items()}
    per_query = pd.read_csv(processed / "metrics_per_query.csv")
    summary = pd.read_csv(processed / "metrics_summary.csv")

    # -------------------------------------------------- per-query table
    err = per_query_comparison(
        rankings, payloads, meta, gt, coverage, keyword_to_cluster, doc_ids, X_dense, models=("M1", "M3")
    )
    err.to_csv(processed / "error_analysis.csv", index=False)
    log.info("error_analysis.csv: %d rows", len(err))

    tax = taxonomy_counts(err, model="M3")
    tax.to_csv(processed / "failure_taxonomy.csv", index=False)
    cmp_df = ae_vs_tfidf(err)
    cmp_df.to_csv(tables / "ae_vs_tfidf.csv", index=False)

    recs = pd.DataFrame(recommendations())
    recs.to_csv(processed / "recommendations.csv", index=False)

    # ------------------------------------------------------ case studies
    case_jds = cfg.get("analysis.case_study_jds", ["P01", "P04", "P08", "P10"])
    case_mats: dict[str, pd.DataFrame] = {}
    for jd_id in case_jds:
        tbl = case_study_table(rankings, jd_id, "M3", payloads, meta, coverage, gt, top_n=10)
        tbl.to_csv(tables / f"case_study_{jd_id}_M3.csv", index=False)
        mat, labels = case_study_matrix(rankings, jd_id, "M3", payloads, meta, keyword_to_cluster, doc_ids, X_dense, top_n=10)
        if mat.shape[1] <= 14:
            case_mats[jd_id] = mat
        else:
            case_mats[jd_id] = mat.iloc[:, :14]

    # ----------------------------------------------------------- narrative
    quality = pd.read_csv(processed / "extraction_quality.csv")
    ok_q = quality[quality["status"] == "ok"]
    qsum = {
        "macro_precision": round(float(ok_q["precision"].mean()), 4) if len(ok_q) else None,
        "macro_recall": round(float(ok_q["recall"].mean()), 4) if len(ok_q) else None,
        "macro_f1": round(float(ok_q["f1"].mean()), 4) if len(ok_q) else None,
        "worst_5": ok_q.nsmallest(5, "f1")[["doc_id", "f1"]].to_dict(orient="records") if len(ok_q) else [],
    }
    cluster_metrics = json.loads((processed / "cluster_metrics.json").read_text())
    heldout_cov = pd.read_csv(processed / "heldout_keyword_coverage.csv")
    extraction_summary = json.loads((processed / "extraction_summary.json").read_text())

    md = build_markdown(
        gt=gt,
        per_query=per_query,
        summary=summary,
        err=err,
        tax=tax,
        cmp_df=cmp_df,
        recs=recs,
        qsum=qsum,
        cluster_metrics=cluster_metrics,
        heldout_cov=heldout_cov,
        extraction_summary=extraction_summary,
        case_jds=list(case_mats.keys()),
        payloads=payloads,
        meta=meta,
        coverage=coverage,
    )
    (results / "error_analysis.md").write_text(md, encoding="utf-8")
    log.info("wrote results/error_analysis.md (%d chars)", len(md))

    print("\n--- FAILURE TAXONOMY (M3) ---")
    print(tax[["code", "category", "count"]].to_string(index=False))
    print("\n--- AE vs TF-IDF ---")
    print(cmp_df[["jd_id", "tfidf_rank", "ae_rank", "delta", "winner"]].to_string(index=False))
    print("\n--- RECOMMENDATIONS ---")
    print(recs[["priority", "issue", "effort"]].to_string(index=False))
    print("-----------------------\n")
    return 0


def build_markdown(
    *,
    gt,
    per_query,
    summary,
    err,
    tax,
    cmp_df,
    recs,
    qsum,
    cluster_metrics,
    heldout_cov,
    extraction_summary,
    case_jds,
    payloads,
    meta,
    coverage,
) -> str:
    m3 = summary[summary["model"] == "M3"].iloc[0]
    m1 = summary[summary["model"] == "M1"].iloc[0]
    e3 = err[err["model"] == "M3"].set_index("jd_id")

    lines: list[str] = []
    A = lines.append

    A("# Error analysis - AI CV matching baseline\n")
    A(
        "This report explains why the baseline succeeds or fails on the 10 labelled JD-CV pairs. "
        "Every number is reproducible from the saved CSV artifacts in `data/processed/` and `results/tables/`. "
        "With n = 10 queries, one query moves the mean by 0.10; differences between models are descriptive, not significant.\n"
    )

    A("## 1. Headline metrics\n")
    A("| Model | Hits@10 | Recall@10 | Hit@1 | Hit@5 | MRR@10 | Wilson 95% CI |")
    A("|---|---|---|---|---|---|---|")
    for _, r in summary.iterrows():
        A(
            f"| {r['model']} {r['model_name']} | {int(r['hits'])}/10 | {r['recall_at_10']:.2f} | "
            f"{r['hit_at_1']:.2f} | {r['hit_at_5']:.2f} | {r['mrr_at_10']:.3f} | "
            f"[{r['wilson_ci_low']:.2f}, {r['wilson_ci_high']:.2f}] |"
        )
    A("")
    A(
        f"The pre-registered primary model is **M3 AE-32 cosine**, which retrieves the hired CV in the top 10 for "
        f"**{int(m3['hits'])} of 10** queries (Recall@10 = {m3['recall_at_10']:.2f}, 95% Wilson CI "
        f"[{m3['wilson_ci_low']:.2f}, {m3['wilson_ci_high']:.2f}]). Plain TF-IDF (M1) reaches "
        f"{int(m1['hits'])}/10. Random ranking from 110 candidates is expected to hit 10/110 = 0.09.\n"
    )

    A("## 2. Per-query review (all 10 JDs)\n")
    for _, r in gt.iterrows():
        jd = r["jd_id"]
        row = e3.loc[jd]
        verdict = "hit" if int(row["hired_rank"]) <= 10 else "miss"
        A(f"### {jd} - {r['jd_title']} ({r['role_family']}) - **{verdict}, rank {int(row['hired_rank'])}**\n")
        A(
            f"- Hired CV `{r['hired_cv_id']}` ({r['hired_cv_title']} at {r['hired_cv_company']}) "
            f"scored {row['hired_score']:.3f}; the top-1 candidate `{row['top1_cv_id']}` "
            f"({row['top1_title']}) scored {row['top1_score']:.3f} (margin {row['score_margin']:+.3f})."
        )
        A(
            f"- Must-have coverage: hired {row['must_have_coverage_hired']:.2f} vs top-1 "
            f"{row['must_have_coverage_top1']:.2f}. Missing must-haves on the hired CV: "
            f"{row['missing_must_haves_hired'] or 'none'}."
        )
        A(
            f"- Role family match: hired {'yes' if row['role_family_match_hired'] else 'no'}, "
            f"top-1 {'yes' if row['role_family_match_top1'] else 'no'}. "
            f"Years: hired {row['years_hired']}, top-1 {row['years_top1']}."
        )
        A(
            f"- Primary failure category: `{row['primary_failure_category']}`, secondary `{row['secondary_failure_category'] or '-'}`. "
            f"Evidence: {row['comment']}."
        )
        A(f"- What would most improve this query: {next_step(row['primary_failure_category'])}\n")
        A(f"- Is the ranking defensible? {defensibility(row, verdict)}\n")

    A("## 3. Failure taxonomy\n")
    A("| Code | Category | Count (M3 misses) | Definition |")
    A("|---|---|---|---|")
    for _, r in tax.iterrows():
        A(f"| {r['code']} | {r['category']} | {int(r['count'])} | {r['definition']} |")
    A("")
    total_miss = int((e3["hired_rank"] > 10).sum())
    A(
        f"Of the {total_miss} misses under M3, the dominant category is "
        f"`{tax.sort_values('count', ascending=False).iloc[0]['category']}`. "
        "Categories are assigned by an explicit rule (see `src/analysis.py::classify`) using only evidence that is "
        "visible in the extracted payloads, so the assignment is reproducible rather than hand-waved.\n"
    )

    A("## 4. AE vs TF-IDF\n")
    A("| JD | TF-IDF rank | AE rank | Delta (AE-TFIDF) | Winner |")
    A("|---|---|---|---|---|")
    for _, r in cmp_df.iterrows():
        A(f"| {r['jd_id']} | {int(r['tfidf_rank'])} | {int(r['ae_rank'])} | {int(r['delta']):+d} | {r['winner']} |")
    A("")
    n_ae = int((cmp_df["winner"] == "AE").sum())
    n_tf = int((cmp_df["winner"] == "TF-IDF").sum())
    n_tie = int((cmp_df["winner"] == "tie").sum())
    A(
        f"The AE improves {n_ae} queries, degrades {n_tf}, and ties {n_tie}. "
        "The pattern is informative rather than random: the AE wins where the JD and the CV describe the same work "
        "in different words (P08 field service, P09 tech lead) and loses where a specific must-have keyword is the "
        "discriminator (P02 FMCG sales, P03 GTM, P04 data engineering). Because the AE is trained to reconstruct the "
        "keyword-cluster profile rather than to rank, the bottleneck smooths exactly those rare must-have skills. "
        "**On this corpus the autoencoder is a regression relative to plain TF-IDF, and that is reported as the "
        "primary result rather than tuned away.**\n"
    )

    A("## 5. Extraction and keyword-merge quality\n")
    A(
        f"- LLM extraction vs the Excel `Skills` silver standard: macro precision "
        f"{qsum['macro_precision']}, macro recall {qsum['macro_recall']}, macro F1 {qsum['macro_f1']} "
        f"over the 100 pool CVs."
    )
    A(
        f"- Worst five CVs by F1: "
        + ", ".join(f"{d['doc_id']} ({d['f1']:.2f})" for d in qsum["worst_5"])
    )
    A(
        f"- Extraction run: {extraction_summary['documents_attempted']} documents attempted, "
        f"{extraction_summary['success_rate']:.1%} success, {extraction_summary['fallback_count']} rule-based "
        f"fallbacks, {extraction_summary['unsupported_keywords']} unsupported keywords dropped."
    )
    A(
        f"- Keyword clusters: {cluster_metrics['n_clusters']} clusters from {cluster_metrics['n_keywords_train']} "
        f"training keywords (singleton rate {cluster_metrics['singleton_rate']:.2f}, mean coherence "
        f"{cluster_metrics['mean_coherence']:.2f}, embedding method `{cluster_metrics['embedding_method']}`)."
    )
    A(
        f"- Manual merge review: {cluster_metrics['manual_merge_review']['n_correct']} of "
        f"{cluster_metrics['manual_merge_review']['n_reviewed']} sampled decisions correct "
        f"(accuracy {cluster_metrics['manual_merge_review']['accuracy']})."
    )
    A(
        f"- Held-out keyword coverage: {cluster_metrics['heldout_keywords_unmatched']} of "
        f"{cluster_metrics['heldout_keywords_total']} held-out keywords "
        f"({cluster_metrics['heldout_unmatched_rate']:.1%}) could not be mapped to a training cluster. "
        + (
            "Every one of those is a rare must-have that the model therefore cannot see."
            if cluster_metrics["heldout_keywords_unmatched"] > 0
            else "Every held-out keyword found a cluster, so this particular failure mode did not occur here."
        )
    )
    for k, v in cluster_metrics["guardrails"].items():
        A(f"- Guardrail `{k}`: {'**FAILED**' if v['merged'] else 'passed'} (clusters {v['clusters_a']} vs {v['clusters_b']}).")
    A("")

    A("## 6. Case studies\n")
    for jd_id in case_jds:
        row = e3.loc[jd_id]
        g = gt[gt["jd_id"] == jd_id].iloc[0]
        A(f"### {jd_id} - {g['jd_title']}\n")
        A(
            f"**Where the hired CV landed.** `{g['hired_cv_id']}` "
            f"({g['hired_cv_title']} at {g['hired_cv_company']}) ranked {int(row['hired_rank'])} "
            f"with score {row['hired_score']:.3f}. The top-1 candidate was `{row['top1_cv_id']}` "
            f"({row['top1_title']}) at {row['top1_score']:.3f}.\n"
        )
        A(
            f"**Why.** Must-have coverage for the hired CV is {row['must_have_coverage_hired']:.2f}; "
            f"the top-1 candidate covers {row['must_have_coverage_top1']:.2f}. "
            f"Missing must-haves on the hired CV: {row['missing_must_haves_hired'] or 'none'}; "
            f"on the top-1: {row['missing_must_haves_top1'] or 'none'}. "
            f"Role-family match: hired {'yes' if row['role_family_match_hired'] else 'no'}, "
            f"top-1 {'yes' if row['role_family_match_top1'] else 'no'}.\n"
        )
        cat = row["primary_failure_category"]
        if cat == "none":
            A(
                f"**What went wrong.** Nothing — the hired CV is inside the top 10 under this model. "
                f"The nearest competitor is `{row['top1_cv_id']}` ({row['top1_title']}), which a recruiter would "
                f"also consider plausible: the margin is {row['score_margin']:+.3f}.\n"
            )
        else:
            A(
                f"**What went wrong.** Primary category `{cat}` "
                f"({FAILURE_CATEGORIES.get(cat, '')}). Evidence: {row['comment']}.\n"
            )
        A(f"**What to change.** {next_step(cat)}\n")
        A(
            f"See `results/tables/case_study_{jd_id}_M3.csv` for the top-10 table and "
            f"`15_case_study_keyword_coverage.png` for the coverage heatmap.\n"
        )

    A("## 7. Recommendations\n")
    A("| Priority | Issue | Evidence | Proposed fix | Expected impact | Effort |")
    A("|---|---|---|---|---|---|")
    for _, r in recs.iterrows():
        A(
            f"| {r['priority']} | {r['issue']} | {r['evidence']} | {r['proposed_fix']} | "
            f"{r['expected_impact']} | {r['effort']} |"
        )
    A("")
    A("All impact estimates are **hypotheses**. Nothing in this table was validated on the 10 queries; acting on it and "
      "then reporting the result would be test-set tuning.\n")

    A("## 8. Limitations\n")
    for lim in [
        "**n = 10 labelled queries, one relevant CV each.** Recall@10 is a hit rate, not a proportion of relevant items. One query changes the mean by 0.10 and the Wilson interval is wide.",
        "**The hired candidate is not necessarily the best on paper.** Hiring involves interviews, salary fit, availability and recruiter judgement; none of that is in the data.",
        "**Hard filters are not modelled.** Salary, notice period, location, citizenship, work authorisation and language requirements are ignored, although several JDs state them explicitly (P01 Malaysia/Thailand, P02 Indonesian citizen in Indonesia, P07 HK & SG).",
        "**LLM extraction noise.** Keyword extraction is imperfect; the measured F1 against the Excel `Skills` column is well below 1.0, and some CV text is truncated with `...`, so a missing mention is not proof of a missing skill.",
        "**Keyword clustering is heuristic.** Rare domain synonyms may stay in separate clusters; held-out keywords can be unmatched and are then excluded from the AE input, which disadvantages rare must-have skills.",
        "**The autoencoder optimises reconstruction, not ranking.** A low reconstruction error does not imply good retrieval, and with ~150 training documents overfitting is expected.",
        "**The candidate pool (110 CVs) may not represent the real population.** It is a small, anonymised sample biased toward Southeast Asian tech and business roles.",
        "**The 50 unlabelled JDs are not ground truth.** They are used only for training/context.",
        "**No statistical significance is claimed anywhere.** With 10 queries, model differences of one or two hits are within noise.",
    ]:
        A(f"- {lim}")
    A("")
    A("## 9. Metric definitions used in this report\n")
    A("- **Recall@10** = (# relevant candidates retrieved in the top 10) / (# relevant candidates). With exactly one relevant CV per JD this equals 1 if the hired CV is in the top 10, else 0. Mean Recall@10 = hits / 10.")
    A("- **Hit@K** = fraction of queries whose hired CV is within the top K.")
    A("- **MRR@10** = mean of 1/rank for hits within the top 10, else 0.")
    A("- **nDCG@10** = mean of 1/log2(rank+1) for hits within the top 10, else 0 (binary relevance, one relevant item).")
    A("- **Precision@10** = (# relevant in the top 10) / 10. Its maximum here is 0.1 and it is **not** recall.")
    A("- **Wilson 95% CI** for the hit proportion; **bootstrap 95% CI** for mean Recall@10 (10,000 resamples, seed 42).")
    return "\n".join(lines)


def ok_q_rows(qsum) -> list:
    return []


def defensibility(row, verdict: str) -> str:
    """One sentence on whether the ranking would survive a recruiter's review."""
    cat = row["primary_failure_category"]
    rank = int(row["hired_rank"])
    if verdict == "hit":
        if rank <= 5:
            return f"Yes — the hired CV is in the first five, which is the useful end of a shortlist."
        return f"Mostly — the hired CV is inside the top 10 but at rank {rank}, so a recruiter would have to read past several plausible alternatives."
    mapping = {
        "E1": "Partly — the hired CV genuinely does not evidence several must-have skills in its text, so the miss reflects the document rather than the model alone.",
        "E4": "No — the candidate who outranks the hire has an almost identical title and skill profile, so the ordering is arbitrary on the available evidence.",
        "E5": "No — a considerably more senior candidate wins on vocabulary even though the JD's scope suggests otherwise; experience is simply not in the score.",
        "E6": "No — the hire's industry background is the missing signal and the baseline has no way to express it.",
        "E7": "No — the JD carries a hard location requirement that the baseline never applies.",
        "E3": "Partly — the 32-d bottleneck dropped the discriminating skill, so a different representation could plausibly fix this query.",
        "E2": "Partly — the relevant skill exists but was split across clusters, which is a fixable taxonomy problem.",
        "E8": "Unclear — the hire may reflect interview or availability context that the text does not contain.",
        "E9": "No — near-duplicate pool profiles crowd the shortlist.",
        "none": "",
        "E10": "Unclear — no single visible mechanism explains the miss.",
    }
    return mapping.get(cat, mapping["E10"])


def next_step(category: str) -> str:
    mapping = {
        "none": "Nothing immediate; the query is already retrieved within the top 10.",
        "E1": "Improve extraction (two-pass extraction with evidence spans, or the larger local model) so must-have skills are not lost.",
        "E2": "Extend the curated alias dictionary and review the affected clusters so the same skill is not split across clusters.",
        "E3": "Keep the raw TF-IDF score alongside the AE score, or add a ranking-aware objective; the bottleneck is smoothing the discriminating skill.",
        "E4": "Weight rare, section-specific clusters higher and add domain/seniority features so a role-identical lookalike does not win on shared vocabulary.",
        "E5": "Add seniority and years-of-experience as a gated adjustment when the JD states a minimum.",
        "E6": "Add domain/industry features (manufacturing finance, semiconductor field service) rather than relying on skill keywords alone.",
        "E7": "Parse and apply the JD's hard filters (location, citizenship, language) as a pre-filter or penalty.",
        "E8": "Collect more labelled pairs; the ground truth may encode recruiter context that the text does not contain.",
        "E9": "Deduplicate near-identical profiles in the pool before ranking.",
        "E10": "Inspect the query manually; no single mechanism dominates.",
    }
    return mapping.get(category, mapping["E10"])


if __name__ == "__main__":
    raise SystemExit(main())
