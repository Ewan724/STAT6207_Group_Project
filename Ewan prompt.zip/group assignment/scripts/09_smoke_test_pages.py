"""Headless smoke test for the Streamlit pages.

Run from the project root:

    py "scripts/09_smoke_test_pages.py" --config "config.yaml"

This executes every page module through Streamlit's own test runtime, so a
syntax error, a missing file or a bad column reference fails loudly here instead
of in the browser. It also asserts that no page produced a visible exception.
"""

from __future__ import annotations

import argparse
import sys
import traceback
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

PAGES = [
    ("Overview", "pages/1_Overview.py"),
    ("Keyword merging", "pages/2_Keyword_Merging.py"),
    ("Autoencoder", "pages/3_Autoencoder.py"),
    ("Search results", "pages/4_Search_Results.py"),
    ("Recall and errors", "pages/5_Error_Analysis.py"),
]


def main() -> int:
    ap = argparse.ArgumentParser(description="Smoke-test every Streamlit page")
    ap.add_argument("--config", default=None)
    args = ap.parse_args()

    try:
        from streamlit.testing.v1 import AppTest
    except Exception as exc:  # noqa: BLE001
        print(f"streamlit.testing is unavailable: {exc}")
        return 2

    failures: list[str] = []
    print(f"{'page':22s} {'status':10s} {'elements':>9s}  notes")
    print("-" * 78)

    for name, rel in PAGES:
        path = ROOT / rel
        if not path.is_file():
            failures.append(f"{name}: missing file {rel}")
            print(f"{name:22s} {'MISSING':10s} {0:9d}  {rel}")
            continue
        try:
            at = AppTest.from_file(str(path), default_timeout=180)
            at.run()
            if at.exception:
                msgs = "; ".join(str(e.value)[:220] for e in at.exception)
                failures.append(f"{name}: {msgs}")
                print(f"{name:22s} {'EXCEPTION':10s} {len(at.get('dataframe')):9d}  {msgs}")
                continue
            n_elements = (
                len(at.get("dataframe"))
                + len(at.get("metric") if "metric" in dir(at) else [])
                + len(at.markdown)
            )
            print(f"{name:22s} {'OK':10s} {n_elements:9d}  {rel}")
        except Exception as exc:  # noqa: BLE001
            failures.append(f"{name}: {exc}")
            print(f"{name:22s} {'ERROR':10s} {0:9d}  {exc}")
            traceback.print_exc()

    print("-" * 78)
    if failures:
        print(f"FAILED: {len(failures)} page(s)")
        for f in failures:
            print(f"  - {f}")
        return 1
    print("All 5 pages loaded without exceptions.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
