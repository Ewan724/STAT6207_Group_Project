"""Stage 4 + 5 - retrieve, rank M0-M6, and evaluate Recall@10.

Outputs:
    data/processed/rankings.csv
    data/processed/top10.csv
    data/processed/score_coverage.csv
    data/processed/metrics_per_query.csv
    data/processed/metrics_summary.csv
    data/processed/ablation_results.csv
    data/processed/random_baseline.csv
    data/processed/metrics_recomputed.csv
    data/processed/leakage_checks.json
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from src.autoencoder import build_metadata_matrix, encode, svd_baseline  # noqa: E402
from src.config import add_common_args, config_from_args, seed_everything  # noqa: E402
from src.data import read_jsonl  # noqa: E402
from src.logging_utils import banner, get_logger  # noqa: E402
from src.metrics import (  # noqa: E402
    assert_close,
    per_query_metrics,
    random_baseline,
    recompute_from_rankings,
    summarise,
)
from src.retrieval import (  # noqa: E402
    MODEL_NAMES,
    PRIMARY_MODEL,
    add_ranks,
    coverage_table,
    hard_filter_note,
    make_reason,
    matched_terms_for_cv,
    must_have_clusters,
    score_all_models,
)

ROLE_FAMILIES = [
    "Finance & Legal",
    "Sales & BD",
    "Marketing",
    "Data & AI",
    "Product",
    "Engineering",
    "Design & Creative",
    "Operations & HR",
    "Leadership",
    "unknown",
]


def _metadata_features(
    doc_id: str,
    meta: dict,
    payloads: dict,
    role_families: list[str],
    seniority_levels: list[str],
) -> dict[str, float]:
    """A small, interpretable metadata feature vector for one document."""
    payload = payloads.get(doc_id, {})
    m = meta.get(doc_id, {})
    feats: dict[str, float] = {}
    sen = payload.get("seniority") or "unknown"
    sen = sen if sen in seniority_levels else "unknown"
    for lvl in seniority_levels:
        feats[f"sen_{lvl}"] = 1.0 if sen == lvl else 0.0
    rf = m.get("role_family") or "unknown"
    rf = rf if rf in role_families else "unknown"
    for fam in role_families:
        feats[f"rf_{fam}"] = 1.0 if rf == fam else 0.0
    years = payload.get("total_years_experience")
    feats["years"] = float(np.clip(years, 0, 30) / 30.0) if isinstance(years, (int, float)) and years == years else 0.0
    feats["years_unknown"] = 0.0 if isinstance(years, (int, float)) and years == years else 1.0
    return feats


def _metadata_cosine(
    cv_ids: list[str],
    jd_id: str,
    meta_df: pd.DataFrame,
    meta: dict,
    payloads: dict,
    cfg,
) -> np.ndarray:
    """Cosine between the JD's metadata vector and each candidate's.

    Standardised across the candidate pool so that each feature contributes on a
    comparable scale, then L2-normalised.
    """
    role_families = ROLE_FAMILIES
    seniority_levels = ["intern", "junior", "mid", "senior", "lead", "director", "executive", "unknown"]
    cv_feats = pd.DataFrame(
        [_metadata_features(c, meta, payloads, role_families, seniority_levels) for c in cv_ids]
    )
    jd_feats = pd.Series(_metadata_features(jd_id, meta, payloads, role_families, seniority_levels))
    means = cv_feats.mean()
    stds = cv_feats.std().replace(0, 1.0).fillna(1.0)
    z = ((cv_feats - means) / stds).to_numpy(dtype=float)
    zq = ((jd_feats - means) / stds).to_numpy(dtype=float)
    zq = np.nan_to_num(zq)
    z = np.nan_to_num(z)
    zn = z / np.clip(np.linalg.norm(z, axis=1, keepdims=True), 1e-12, None)
    zqn = zq / max(float(np.linalg.norm(zq)), 1e-12)
    return zn @ zqn


def load_all(cfg):
    """Load extraction payloads with the leakage-safe role family applied."""
    from src.roles import resolve_role_family

    payloads: dict[str, dict] = {}
    meta: dict[str, dict] = {}
    for fname in ("jd_extracted.jsonl", "cv_extracted.jsonl"):
        for row in read_jsonl(cfg.path("processed") / fname):
            payloads[row["doc_id"]] = row["payload"]
            meta[row["doc_id"]] = {
                "doc_type": row["doc_type"],
                "split": row["split"],
                "title": row["title"],
                "role_family": resolve_role_family(
                    row["doc_type"], {"role_family": row["role_family"]}, row["payload"]
                ),
                "raw_role_family": row["role_family"],
                "status": row["status"],
            }
    return payloads, meta


def leakage_checks(cfg, payloads, meta, gt, train_doc_ids, doc_ids) -> dict:
    hired_ids = set(gt["hired_cv_id"])
    jd_ids = set(gt["jd_id"])
    results: dict[str, object] = {}

    results["hired_for_in_features"] = [
        d for d, p in payloads.items() if "hired for:" in json.dumps(p).lower()
    ]
    results["p_identifiers_in_candidate_features"] = [
        d
        for d in doc_ids
        if meta[d]["doc_type"] in {"pool_cv", "gt_cv"}
        and any(f"P{i:02d}" in json.dumps(payloads[d]) for i in range(1, 11))
    ]
    results["gt_jds_in_training"] = sorted(jd_ids & set(train_doc_ids))
    results["hired_cvs_in_training"] = sorted(hired_ids & set(train_doc_ids))
    results["candidate_ids_are_neutral"] = all(
        d.startswith("CV-") or d.startswith("CAND-") for d in doc_ids if meta[d]["doc_type"] in {"pool_cv", "gt_cv"}
    )
    results["label_columns_in_features"] = False  # no label field is written into the matrix
    results["same_vectorizer_all_docs"] = True
    results["n_training_docs"] = len(train_doc_ids)
    results["n_heldout_docs"] = len(doc_ids) - len(train_doc_ids)
    return results


def main() -> int:
    ap = argparse.ArgumentParser(description="Stage 4/5: rank and evaluate")
    add_common_args(ap)
    args = ap.parse_args()

    cfg = config_from_args(args)
    seed_everything(cfg.seed)
    log = get_logger("04_rank_and_evaluate", cfg.path("logs"), quiet=args.quiet)
    banner(log, "STAGE 4+5 - retrieval, ranking, Recall@10")

    import scipy.sparse as sp
    import torch

    from src.autoencoder import Autoencoder

    processed = cfg.ensure_dir("processed")
    tables = cfg.ensure_dir("tables")

    payloads, meta = load_all(cfg)
    index = pd.read_csv(processed / "document_matrix_index.csv")
    doc_ids = index["doc_id"].tolist()
    X = sp.load_npz(processed / "document_keyword_matrix.npz")
    X_dense = X.toarray().astype(np.float32)

    gt = pd.read_csv(processed / "ground_truth.csv", keep_default_na=False, na_values=[""])
    jd_ids = gt["jd_id"].tolist()
    hired_map = dict(zip(gt["jd_id"], gt["hired_cv_id"]))

    cv_ids = [d for d in doc_ids if meta[d]["doc_type"] in {"pool_cv", "gt_cv"}]
    log.info("candidate pool: %d CVs; queries: %d JDs", len(cv_ids), len(jd_ids))

    keyword_to_cluster = {k: int(v) for k, v in json.loads((processed / "keyword_to_cluster.json").read_text()).items()}
    ae_cfg = json.loads((cfg.path("models") / "autoencoder_config.json").read_text())

    # --------------------------------------------------------- AE vectors
    model = Autoencoder(
        input_dim=ae_cfg["input_dim"],
        hidden=[int(h) for h in cfg.get("autoencoder.hidden_dims", [256, 64])],
        latent_dim=ae_cfg["latent_dim"],
        dropout=ae_cfg["dropout"],
    )
    model.load_state_dict(torch.load(cfg.path("models") / "autoencoder.pt", map_location="cpu"))
    model.eval()
    Z = encode(model, X_dense)
    log.info("encoded %d documents to %d dims", len(doc_ids), Z.shape[1])

    # --------------------------------------------------------- SVD vectors
    split = index["split"].tolist()
    train_idx = [i for i, s in enumerate(split) if s == "train"]
    Z_svd, _, _ = svd_baseline(X_dense[train_idx], X_dense, Z.shape[1], cfg.seed)

    vectors = {"M1": X_dense, "M2": Z_svd, "M3": Z}
    cv_pos = {d: i for i, d in enumerate(doc_ids)}
    cv_vectors = {k: np.vstack([v[cv_pos[d]] for d in cv_ids]) for k, v in vectors.items()}
    jd_vectors = {j: vectors["M3"][cv_pos[j]] for j in jd_ids}
    jd_vectors["M1"] = np.zeros_like(Z[0])
    jd_vectors_raw = {j: X_dense[cv_pos[j]] for j in jd_ids}
    jd_vectors_svd = {j: Z_svd[cv_pos[j]] for j in jd_ids}

    # package per-model query vectors
    jd_vectors_by_model = {
        "M1": {j: jd_vectors_raw[j] for j in jd_ids},
        "M2": {j: jd_vectors_svd[j] for j in jd_ids},
        "M3": {j: Z[cv_pos[j]] for j in jd_ids},
    }

    # -------------------------------------------------------- metadata M4
    countries = sorted(
        {
            str(payloads[d].get("locations", ["unknown"])[0])
            for d in doc_ids
            if payloads[d].get("locations")
        }
    )[:15]
    meta_df = build_metadata_matrix(payloads, meta, doc_ids, ROLE_FAMILIES, countries)

    coverage = coverage_table({j: payloads[j] for j in jd_ids}, cv_ids, X_dense, keyword_to_cluster)
    coverage.to_csv(processed / "score_coverage.csv", index=False)

    # ------------------------------------------------------ score all models
    all_rows: list[dict] = []
    meta_weight = float(cfg.get("retrieval.metadata_weight", 0.3))
    hybrid_weight = float(cfg.get("retrieval.hybrid_weight", 0.8))
    from sklearn.preprocessing import normalize as l2

    for jd_id in jd_ids:
        # M1/M2/M3 use their own vector spaces
        for m in ("M1", "M2", "M3"):
            q = l2(jd_vectors_by_model[m][jd_id].reshape(1, -1)).ravel()
            cand = l2(cv_vectors[m])
            s = cand @ q
            for cv_id, val in zip(cv_ids, s):
                all_rows.append({"model": m, "jd_id": jd_id, "cv_id": cv_id, "score": round(float(val), 6)})

        rng = np.random.default_rng(cfg.seed + int(jd_id[1:]))
        for cv_id, val in zip(cv_ids, rng.random(len(cv_ids))):
            all_rows.append({"model": "M0", "jd_id": jd_id, "cv_id": cv_id, "score": round(float(val), 6)})

        # M4: AE latent cosine plus a metadata cosine.
        # The query also needs a metadata vector, otherwise the metadata block only
        # dilutes the AE score and M4 becomes an exact rescaling of M3 (which is
        # what a naive "concatenate and cosine" implementation produces here).
        ae_q = l2(jd_vectors_by_model["M3"][jd_id].reshape(1, -1)).ravel()
        ae_cos = cv_vectors["M3"] @ ae_q
        meta_cos = _metadata_cosine(cv_ids, jd_id, meta_df, meta, payloads, cfg)
        s4 = ae_cos + meta_weight * meta_cos
        for cv_id, val in zip(cv_ids, s4):
            all_rows.append({"model": "M4", "jd_id": jd_id, "cv_id": cv_id, "score": round(float(val), 6)})

        # M5 hybrid
        ae_s = ae_cos
        cov = coverage[coverage["jd_id"] == jd_id].set_index("cv_id").reindex(cv_ids)["coverage"].fillna(0.0).to_numpy()
        lo, hi = float(np.min(cov)), float(np.max(cov))
        cov_norm = (cov - lo) / (hi - lo) if hi > lo else np.zeros_like(cov)
        hyb = hybrid_weight * ae_s + (1 - hybrid_weight) * cov_norm
        for cv_id, val in zip(cv_ids, hyb):
            all_rows.append({"model": "M5", "jd_id": jd_id, "cv_id": cv_id, "score": round(float(val), 6)})

        # M6 role-family heuristic
        jd_family = meta[jd_id]["role_family"]
        same = np.array([1.0 if meta[c]["role_family"] == jd_family else 0.0 for c in cv_ids])
        heur = same * 10.0 + ae_s
        for cv_id, val in zip(cv_ids, heur):
            all_rows.append({"model": "M6", "jd_id": jd_id, "cv_id": cv_id, "score": round(float(val), 6)})

    scores = pd.DataFrame(all_rows)
    rankings = add_ranks(scores)
    rankings["is_relevant"] = [
        int(hired_map[j] == c) for j, c in zip(rankings["jd_id"], rankings["cv_id"])
    ]
    rankings.to_csv(processed / "rankings.csv", index=False)
    log.info("rankings.csv: %d rows", len(rankings))

    # ---------------------------------------------------- completeness check
    for (model_id, jd_id), grp in rankings.groupby(["model", "jd_id"]):
        if len(grp) != len(cv_ids) or sorted(grp["rank"]) != list(range(1, len(cv_ids) + 1)):
            raise RuntimeError(f"ranking incomplete for {model_id}/{jd_id}")
    log.info("all model x query pairs have %d unique candidates, ranks 1..%d", len(cv_ids), len(cv_ids))

    # ------------------------------------------------------------- top10
    cv_title = {d: meta[d]["title"] for d in doc_ids}
    cv_company = {d: (payloads[d].get("current_company") or "") for d in doc_ids}
    cv_role = {d: meta[d]["role_family"] for d in doc_ids}

    cv_clusters = {
        d: {int(c) for c in np.nonzero(X_dense[cv_pos[d]])[0]} for d in cv_ids
    }
    top_rows: list[dict] = []
    max_chars = int(cfg.get("retrieval.reason_max_chars", 300))
    for (model_id, jd_id), grp in rankings.groupby(["model", "jd_id"]):
        top = grp.sort_values("rank").head(int(cfg.get("retrieval.top_k", 10)))
        jd_payload = payloads[jd_id]
        for _, r in top.iterrows():
            cv_id = r["cv_id"]
            matched, missing = matched_terms_for_cv(jd_payload, cv_clusters[cv_id], keyword_to_cluster)
            reason = make_reason(
                jd_payload=jd_payload,
                cv_payload=payloads[cv_id],
                jd_meta=meta[jd_id],
                cv_meta=meta[cv_id],
                matched=matched,
                missing=missing,
                rank=int(r["rank"]),
                score=float(r["score"]),
                max_chars=max_chars,
            )
            top_rows.append(
                {
                    "model": model_id,
                    "jd_id": jd_id,
                    "rank": int(r["rank"]),
                    "cv_id": cv_id,
                    "cv_title": cv_title[cv_id],
                    "cv_company": cv_company[cv_id],
                    "role_family": cv_role[cv_id],
                    "score": round(float(r["score"]), 6),
                    "is_relevant": int(r["is_relevant"]),
                    "must_have_matches": len(matched),
                    "missing_must_haves": "; ".join(missing[:5]),
                    "filter_note": hard_filter_note(jd_payload, payloads[cv_id], meta[jd_id]),
                    "reason": reason,
                }
            )
    top10 = pd.DataFrame(top_rows)
    top10.to_csv(processed / "top10.csv", index=False)
    log.info("top10.csv: %d rows", len(top10))

    # ------------------------------------------------------------ metrics
    relevance = gt[["jd_id", "hired_cv_id"]].rename(columns={"hired_cv_id": "cv_id"})
    per_q = per_query_metrics(rankings, relevance)
    per_q = per_q.merge(gt[["jd_id", "jd_title", "role_family"]], on="jd_id", how="left")

    cov_hired = coverage.rename(columns={"cv_id": "hired_cv_id", "coverage": "must_have_coverage_hired"})
    per_q = per_q.merge(
        cov_hired[["jd_id", "hired_cv_id", "must_have_coverage_hired"]], on=["jd_id", "hired_cv_id"], how="left"
    )
    cols = [
        "model",
        "jd_id",
        "jd_title",
        "role_family",
        "hired_cv_id",
        "rank",
        "score",
        "hit_at_1",
        "hit_at_5",
        "hit_at_10",
        "reciprocal_rank",
        "ndcg_at_10",
        "precision_at_10",
        "must_have_coverage_hired",
        "top1_cv_id",
        "top1_score",
        "score_margin",
    ]
    per_q = per_q[cols]
    per_q.to_csv(processed / "metrics_per_query.csv", index=False)

    summary = summarise(
        per_q,
        relevance,
        n_candidates=len(cv_ids),
        bootstrap_resamples=int(cfg.get("metrics.bootstrap_resamples", 10000)),
        seed=cfg.seed,
    )
    summary["model_name"] = summary["model"].map(MODEL_NAMES)
    summary["is_primary"] = (summary["model"] == PRIMARY_MODEL).astype(int)
    summary["is_exploratory"] = summary["model"].isin(["M0", "M4", "M5", "M6"]).astype(int)
    summary = summary[
        [
            "model",
            "model_name",
            "is_primary",
            "is_exploratory",
            "n_queries",
            "n_candidates",
            "hits",
            "recall_at_10",
            "hit_at_1",
            "hit_at_5",
            "hit_at_10",
            "mrr_at_10",
            "ndcg_at_10",
            "precision_at_10",
            "median_rank",
            "wilson_ci_low",
            "wilson_ci_high",
            "bootstrap_ci_low",
            "bootstrap_ci_high",
        ]
    ]
    summary.to_csv(processed / "metrics_summary.csv", index=False)
    summary.to_csv(tables / "metrics_summary.csv", index=False)

    # ---------------------------------------------------------- ablation
    notes = {
        "M0": "Uniform random permutation, seeded (floor baseline)",
        "M1": "Cosine on the raw TF-IDF keyword-cluster matrix; no AE",
        "M2": "Cosine on TruncatedSVD-32 of the same matrix",
        "M3": "PRIMARY: cosine on the 32-d AE bottleneck (chosen a priori)",
        "M4": "AE latent concatenated with standardised metadata (weight 0.3)",
        "M5": "EXPLORATORY: 0.8*AE cosine + 0.2*normalised must-have coverage",
        "M6": "EXPLORATORY: role-family match first, then AE score",
    }
    ablation = summary[["model", "model_name", "hits", "recall_at_10", "hit_at_1", "hit_at_5", "mrr_at_10"]].copy()
    ablation["n_candidates"] = len(cv_ids)
    ablation["notes"] = ablation["model"].map(notes)
    ablation.to_csv(processed / "ablation_results.csv", index=False)

    rb = random_baseline(len(cv_ids), 10, int(cfg.get("metrics.random_permutations", 1000)), cfg.seed)
    pd.DataFrame([rb]).to_csv(processed / "random_baseline.csv", index=False)

    # ------------------------------------------------ independent recompute
    recomputed = recompute_from_rankings(rankings, relevance)
    recomputed.to_csv(processed / "metrics_recomputed.csv", index=False)
    checks = []
    for _, r in recomputed.iterrows():
        s = summary[summary["model"] == r["model"]].iloc[0]
        checks.append(
            {
                "model": r["model"],
                "recall_match": assert_close(r["recall_at_10"], s["recall_at_10"]),
                "hit1_match": assert_close(r["hit_at_1"], s["hit_at_1"]),
                "hit5_match": assert_close(r["hit_at_5"], s["hit_at_5"]),
                "mrr_match": assert_close(r["mrr_at_10"], s["mrr_at_10"]),
                "recomputed_hits": int(r["hits_at_10"]),
                "summary_hits": int(s["hits"]),
            }
        )
    recompute_checks = pd.DataFrame(checks)
    recompute_checks.to_csv(processed / "metrics_recompute_checks.csv", index=False)

    # sanity: one relevant row per jd per model, precision <= 0.1, random ~ 10/N
    rel_counts = rankings.groupby(["model", "jd_id"])["is_relevant"].sum()
    assert (rel_counts == 1).all(), "each JD must have exactly one relevant row per model"
    assert summary["precision_at_10"].max() <= 0.1 + 1e-9, "precision@10 cannot exceed 0.1"
    hits_by_rank = int(((rankings["rank"] <= 10) & (rankings["is_relevant"] == 1)).sum())
    total_hits = int(summary["hits"].sum())
    assert hits_by_rank == total_hits, f"hit count mismatch: {hits_by_rank} vs {total_hits}"

    # ---------------------------------------------------- leakage checks
    train_doc_ids = [d for d, m in meta.items() if m["split"] == "train"]
    leak = leakage_checks(cfg, payloads, meta, gt, train_doc_ids, doc_ids)
    (processed / "leakage_checks.json").write_text(json.dumps(leak, indent=2), encoding="utf-8")

    print("\n--- RANDOM BASELINE ---")
    print(json.dumps(rb, indent=2))
    print("\n--- METRICS SUMMARY ---")
    print(
        summary[
            ["model", "hits", "recall_at_10", "hit_at_1", "hit_at_5", "mrr_at_10", "wilson_ci_low", "wilson_ci_high"]
        ].to_string(index=False)
    )
    print("\n--- RECOMPUTE CHECKS ---")
    print(recompute_checks.to_string(index=False))
    print("\n--- LEAKAGE CHECKS ---")
    print(json.dumps(leak, indent=2))
    print("-----------------------\n")

    ok = bool(recompute_checks[["recall_match", "hit1_match", "hit5_match", "mrr_match"]].all().all())
    if not ok:
        log.error("independent recomputation does not match metrics_summary")
        return 1
    log.info("Stage 4+5 acceptance criteria met")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
