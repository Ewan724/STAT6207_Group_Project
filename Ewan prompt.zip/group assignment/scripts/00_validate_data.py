"""Stage 0 - validate the raw data, build manifests and ground truth.

Outputs (under data/):
    raw_manifest.csv
    processed/documents.jsonl
    processed/ground_truth.csv
    processed/dedupe_report.csv
    processed/jd_dedupe_report.csv
    processed/cv_alignment_report.csv
    processed/documents_meta.csv
    processed/stage0_summary.json
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# make `src` importable when the script is run directly
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import pandas as pd  # noqa: E402

from src.config import add_common_args, config_from_args  # noqa: E402
from src.data import (  # noqa: E402
    cv_alignment_report,
    dedupe_report,
    jd_dedupe_report,
    load_documents,
    load_excel_cvs,
    load_pool_cvs,
    load_unlabelled_jds,
    pdf_pages,
    sha256_file,
    split_p_pdfs,
    write_jsonl,
)
from src.logging_utils import banner, get_logger  # noqa: E402


def main() -> int:
    ap = argparse.ArgumentParser(description="Stage 0: validate data and build manifests")
    add_common_args(ap)
    args = ap.parse_args()

    cfg = config_from_args(args)
    log = get_logger("00_validate_data", cfg.path("logs"), quiet=args.quiet)
    banner(log, "STAGE 0 - data validation, splitting, manifests")

    processed = cfg.ensure_dir("processed")
    docs_path = processed / "documents.jsonl"

    # ---------------------------------------------------------------- load
    pool_cvs = load_pool_cvs(cfg, log)
    gt_jds, hired_cvs, gt_rows = split_p_pdfs(cfg, log)
    unlabelled = load_unlabelled_jds(cfg, log)

    docs = [*pool_cvs, *gt_jds, *hired_cvs, *unlabelled]
    write_jsonl(docs_path, [d.to_json() for d in docs])
    log.info("wrote %s (%d documents)", docs_path.name, len(docs))

    # ------------------------------------------------------- ground truth
    gt = pd.DataFrame(gt_rows)
    gt_out = gt[
        [
            "jd_id",
            "jd_title",
            "role_family",
            "jd_location",
            "jd_salary",
            "hired_cv_id",
            "hired_cv_title",
            "hired_cv_company",
            "source_pdf",
            "notes",
        ]
    ].copy()
    gt_out["jd_location"] = gt_out["jd_location"].where(gt_out["jd_location"].notna(), None)
    gt_out["jd_salary"] = gt_out["jd_salary"].where(gt_out["jd_salary"].notna(), None)
    gt_out.to_csv(processed / "ground_truth.csv", index=False)
    log.info("ground_truth.csv: %d rows", len(gt_out))
    if len(gt_out) != 10:
        log.error("ground truth must have exactly 10 rows, found %d", len(gt_out))

    # ----------------------------------------------------------- dedupe
    dedupe = dedupe_report(hired_cvs, pool_cvs, top_n=3)
    dedupe.to_csv(processed / "dedupe_report.csv", index=False)
    n_dup = int((dedupe["decision"] == "map_to_existing").sum())
    log.info("dedupe: %d true duplicates found", n_dup)

    jd_dedupe = jd_dedupe_report(gt_jds, unlabelled, threshold=0.90)
    jd_dedupe.to_csv(processed / "jd_dedupe_report.csv", index=False)
    n_near = int(jd_dedupe["near_duplicate"].sum())
    log.info("jd dedupe: %d near-duplicate unlabelled JDs excluded from training", n_near)

    # -------------------------------------------------------- alignment
    excel_cvs = load_excel_cvs(cfg)
    align_df, align_summary = cv_alignment_report(pool_cvs, excel_cvs)
    align_df.to_csv(processed / "cv_alignment_report.csv", index=False)
    log.info("alignment: %s", align_summary)

    # --------------------------------------------------------- manifest
    rows = []
    for d in docs:
        p = cfg.root / d.source_path.split("#")[0]
        rows.append(
            {
                "doc_id": d.doc_id,
                "doc_type": d.doc_type,
                "path": d.source_path,
                "exists": p.exists(),
                "size_bytes": p.stat().st_size if p.exists() else None,
                "sha256": sha256_file(p) if p.exists() else None,
                "pages": d.pages,
                "char_count": d.char_count,
                "title": d.title,
                "role_family": d.role_family,
                "split": d.split,
            }
        )
    manifest = pd.DataFrame(rows)
    manifest.to_csv(cfg.path("data") / "raw_manifest.csv", index=False)

    # ----------------------------------------------------------- checks
    n_candidates = len(pool_cvs) + len(hired_cvs) - n_dup
    meta = pd.DataFrame(
        [
            {
                "doc_id": d.doc_id,
                "doc_type": d.doc_type,
                "split": d.split,
                "title": d.title,
                "role_family": d.role_family,
                "pages": d.pages,
                "char_count": d.char_count,
                "country": d.meta.get("country"),
            }
            for d in docs
        ]
    )
    meta.to_csv(processed / "documents_meta.csv", index=False)

    # leakage checks on the source text
    leak_hired_for = [d.doc_id for d in docs if "hired for:" in d.raw_text.lower()]
    leak_pid = [
        d.doc_id
        for d in docs
        if d.doc_type in {"pool_cv", "gt_cv"} and any(f"P{i:02d}" in d.raw_text for i in range(1, 11))
    ]

    summary = {
        "pool_cvs": len(pool_cvs),
        "gt_cvs": len(hired_cvs),
        "gt_jds": len(gt_jds),
        "unlabelled_jds": len(unlabelled),
        "unique_candidates": n_candidates,
        "ground_truth_rows": int(len(gt_out)),
        "true_duplicates": n_dup,
        "jd_near_duplicates_excluded": n_near,
        "documents_jsonl_rows": len(docs),
        "leak_hired_for": leak_hired_for,
        "leak_p_identifiers": leak_pid,
        "pool_cv_chars": {
            "min": int(meta[meta.doc_type == "pool_cv"].char_count.min()),
            "median": int(meta[meta.doc_type == "pool_cv"].char_count.median()),
            "max": int(meta[meta.doc_type == "pool_cv"].char_count.max()),
        },
        "gt_jd_chars": {
            "min": int(meta[meta.doc_type == "gt_jd"].char_count.min()),
            "median": int(meta[meta.doc_type == "gt_jd"].char_count.median()),
            "max": int(meta[meta.doc_type == "gt_jd"].char_count.max()),
        },
        "gt_cv_chars": {
            "min": int(meta[meta.doc_type == "gt_cv"].char_count.min()),
            "median": int(meta[meta.doc_type == "gt_cv"].char_count.median()),
            "max": int(meta[meta.doc_type == "gt_cv"].char_count.max()),
        },
        "alignment": align_summary,
        "dedupe_top_lookalikes": dedupe[dedupe.lookalike_rank == 1][
            ["hired_cv_id", "pool_cv_id", "cosine", "decision"]
        ].to_dict(orient="records"),
    }
    (processed / "stage0_summary.json").write_text(json.dumps(summary, indent=2, default=str), encoding="utf-8")

    print("\n--- STAGE 0 SUMMARY ---")
    print(f"pool CVs:          {len(pool_cvs)}")
    print(f"GT CVs (hired):    {len(hired_cvs)}")
    print(f"GT JDs:            {len(gt_jds)}")
    print(f"unlabelled JDs:    {len(unlabelled)}")
    print(f"unique candidates: {n_candidates}")
    print(f"ground_truth rows: {len(gt_out)}")
    print(f"true duplicates:   {n_dup}")
    print(f"JD near-dupes:     {n_near}")
    print(f"leak 'Hired for:': {leak_hired_for or 'none'}")
    print(f"leak Pxx in CVs:   {leak_pid or 'none'}")
    print("-----------------------\n")

    ok = (
        len(pool_cvs) == 100
        and len(hired_cvs) == 10
        and len(gt_jds) == 10
        and len(unlabelled) == 50
        and len(gt_out) == 10
        and not leak_hired_for
        and not leak_pid
    )
    if not ok:
        log.error("Stage 0 acceptance criteria not met")
        return 1
    log.info("Stage 0 acceptance criteria met")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
