"""Data ingestion: PDF text, Excel sheets, cleaning, splitting, manifests.

Everything here is read-only with respect to ``data/Anonymised CVs``,
``data/JD + Hired CV examples`` and the Excel workbook. Processed copies are
written under ``data/processed``.

Design notes
------------
* The 10 labelled PDFs each contain a JD and the CV of the person hired for it,
  separated by the marker ``CV OF THE HIRED CANDIDATE``.
* The 10 hired CVs are added to the candidate pool with neutral IDs
  ``CAND-101`` ... ``CAND-110`` so that candidate identity cannot leak a label.
* The ``Hired for: ...`` line, the ``Pxx`` page headers and every ``Pxx``
  identifier are stripped from feature text.
"""

from __future__ import annotations

import hashlib
import json
import re
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

try:  # PyMuPDF >= 1.24 exposes the canonical name
    import pymupdf
except ImportError:  # pragma: no cover
    import fitz as pymupdf  # type: ignore

MARKER = "CV OF THE HIRED CANDIDATE"

HEADER_PATTERNS = [
    r"Anonymised candidate profile\s*·\s*personal information removed\s*·\s*Second Talent",
    r"Anonymised example\s*·\s*client and personal information removed\s*·\s*Second Talent",
    r"^CV-\d{3}\s*·\s*page\s*\d+$",
    r"^P\d{2}\s*·\s*page\s*\d+$",
    r"^P\d{2}\s*·\s*JOB DESCRIPTION\s*·.*$",
    r"^P\d{2}\s*·\s*CV OF THE HIRED CANDIDATE$",
    r"^CV OF THE HIRED CANDIDATE$",
    r"^Hired for:.*$",
    r"^CV-\d{3}$",
]
_HEADER_RE = [re.compile(p, re.IGNORECASE) for p in HEADER_PATTERNS]
_BULLET_RE = re.compile(r"^[\s]*[●•\u25cf\u2022\u00b7\ufffd\u25aa\u25e6\-\u2013\u2014]\s+")
_MULTI_BLANK_RE = re.compile(r"\n{3,}")
_P_ID_RE = re.compile(r"\bP\d{2}\b")

ROLE_FAMILIES = [
    "Finance & Legal",
    "Sales & BD",
    "Marketing",
    "Data & AI",
    "Product",
    "Engineering",
    "Design & Creative",
    "Operations & HR",
    "Leadership",
    "unknown",
]


# --------------------------------------------------------------------------- #
# Low-level text utilities
# --------------------------------------------------------------------------- #
def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def pdf_pages(path: Path) -> list[str]:
    doc = pymupdf.open(path)
    try:
        return [page.get_text() for page in doc]
    finally:
        doc.close()


def clean_text(text: str, *, drop_p_ids: bool = True) -> str:
    """Remove repeated headers/footers, normalise bullets, collapse blank lines."""
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = text.replace("\u00a0", " ")
    text = text.replace("\ufffd", "-")

    out_lines: list[str] = []
    for raw_line in text.split("\n"):
        line = raw_line.rstrip()
        stripped = line.strip()
        if not stripped:
            out_lines.append("")
            continue
        if any(rx.match(stripped) for rx in _HEADER_RE):
            continue
        if drop_p_ids and re.fullmatch(r"P\d{2}", stripped):
            continue
        # bullet glyphs -> "- "
        if _BULLET_RE.match(line):
            line = _BULLET_RE.sub("- ", line, count=1)
        out_lines.append(line)

    cleaned = "\n".join(out_lines)
    cleaned = _MULTI_BLANK_RE.sub("\n\n", cleaned)
    cleaned = "\n".join(ln.rstrip() for ln in cleaned.split("\n"))
    return cleaned.strip()


def scrub_identifiers(text: str) -> tuple[str, int]:
    """Remove any remaining ``Pxx`` token from feature text. Returns (text, n)."""
    new, n = _P_ID_RE.subn("", text)
    return re.sub(r"[ \t]{2,}", " ", new), n


# --------------------------------------------------------------------------- #
# Document record
# --------------------------------------------------------------------------- #
@dataclass
class Document:
    doc_id: str
    doc_type: str  # pool_cv | gt_cv | gt_jd | unlabelled_jd
    source_path: str
    title: str = ""
    role_family: str = "unknown"
    raw_text: str = ""
    pages: int = 0
    char_count: int = 0
    split: str = "train"
    notes: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    def to_json(self) -> dict[str, Any]:
        return asdict(self)


def make_document(**kwargs: Any) -> Document:
    doc = Document(**kwargs)
    doc.char_count = len(doc.raw_text)
    return doc


# --------------------------------------------------------------------------- #
# Raw corpus loading
# --------------------------------------------------------------------------- #
def _jd_header_info(lines: list[str]) -> dict[str, Any]:
    """Pull title / location / salary / remote out of the JD header block."""
    title = ""
    location: str | None = None
    salary: str | None = None
    remote = "unknown"
    role_family = "unknown"

    for line in lines[:8]:
        m = re.match(r"^P\d{2}\s*·\s*JOB DESCRIPTION\s*·\s*(.+)$", line.strip())
        if m:
            role_family = m.group(1).strip()
            break

    # title is the first non-header line after the JOB DESCRIPTION header
    start = 0
    for i, line in enumerate(lines[:8]):
        if "JOB DESCRIPTION" in line:
            start = i + 1
            break
    for line in lines[start : start + 3]:
        s = line.strip()
        if not s:
            continue
        if "·" in s or "full time" in s.lower() or "part time" in s.lower():
            continue
        title = s
        break

    # the meta line contains "·" separators
    for line in lines[start : start + 4]:
        s = line.strip()
        if "·" not in s:
            continue
        parts = [p.strip() for p in s.split("·")]
        for part in parts:
            low = part.lower()
            if low.startswith("remote"):
                remote = "yes"
            elif "hybrid" in low:
                remote = "hybrid"
            elif re.search(r"myr|sgd|idr|usd|hkd|php|thb|vnd|eur|gbp|¥|rm", low) or "salary" in low:
                salary = part
            elif re.search(r"full time|part time|contract|intern", low):
                continue
            elif part and location is None:
                location = part
    if remote == "unknown" and location:
        remote = "no"
    return {
        "title": title,
        "role_family": role_family,
        "location": location,
        "salary": salary,
        "remote": remote,
    }


def _cv_header_info(lines: list[str]) -> dict[str, Any]:
    """Current title + company from the top of a hired-CV block."""
    title = ""
    company = ""
    location = ""
    for line in lines[:6]:
        s = line.strip()
        if not s or s == MARKER:
            continue
        if "·" in s and not title:
            continue
        if not title:
            title = s
            continue
        if "·" in s:
            parts = [p.strip() for p in s.split("·")]
            company = parts[0]
            if len(parts) > 1:
                location = parts[1]
            break
        if not company:
            company = s
            break
    return {"title": title, "company": company, "location": location}


def load_pool_cvs(cfg, log) -> list[Document]:
    cv_dir = cfg.path("raw_cv_dir")
    docs: list[Document] = []
    files = sorted(cv_dir.glob("CV-*.pdf"))
    for path in files:
        pages = pdf_pages(path)
        raw = "\n".join(pages)
        text = clean_text(raw)
        doc_id = path.stem  # CV-001
        # title = first non-header line
        lines = [ln.strip() for ln in text.split("\n") if ln.strip()]
        title = lines[0] if lines else ""
        role = ""
        for ln in lines[:3]:
            if "·" in ln:
                role = ln.split("·")[-1].strip()
                break
        docs.append(
            make_document(
                doc_id=doc_id,
                doc_type="pool_cv",
                source_path=str(path.relative_to(cfg.root)),
                title=title,
                role_family=role or "unknown",
                raw_text=text,
                pages=len(pages),
                split="train",
                meta={"role_family_raw": role},
            )
        )
    log.info("pool CVs parsed: %d (from %s)", len(docs), cv_dir)
    return docs


def split_p_pdfs(cfg, log) -> tuple[list[Document], list[Document], list[dict[str, Any]]]:
    """Split each Pxx PDF into a GT JD and a hired CV."""
    pdir = cfg.path("raw_p_dir")
    jd_docs: list[Document] = []
    cv_docs: list[Document] = []
    rows: list[dict[str, Any]] = []
    problems: list[dict[str, Any]] = []

    files = sorted(pdir.glob("P*.pdf"))
    for idx, path in enumerate(files):
        pid = path.name[:3]  # P01
        pages = pdf_pages(path)
        full = "\n".join(pages)
        pos = full.find(MARKER)
        if pos < 0:
            problems.append({"file": path.name, "issue": "marker not found"})
            log.error("marker not found in %s", path.name)
            continue

        jd_raw = full[:pos]
        cv_raw = full[pos + len(MARKER) :]
        jd_text = clean_text(jd_raw)
        cv_text = clean_text(cv_raw)
        # the trailing "Pxx" token of a page header survives occasionally
        jd_text, _ = scrub_identifiers(jd_text)
        cv_text, _ = scrub_identifiers(cv_text)

        jd_lines = [ln for ln in jd_raw.split("\n") if ln.strip()]
        cv_lines = [ln for ln in cv_raw.split("\n") if ln.strip()]
        jd_info = _jd_header_info(jd_lines)
        cv_info = _cv_header_info(cv_lines)

        cand_id = f"CAND-{101 + idx:03d}"

        jd_docs.append(
            make_document(
                doc_id=pid,
                doc_type="gt_jd",
                source_path=str(path.relative_to(cfg.root)),
                title=jd_info["title"],
                role_family=jd_info["role_family"],
                raw_text=jd_text,
                pages=len(pages),
                split="heldout",
                meta={
                    "location": jd_info["location"],
                    "salary": jd_info["salary"],
                    "remote": jd_info["remote"],
                },
            )
        )
        # IMPORTANT: the hired-CV role family must NOT be copied from the JD header.
        # That would leak the label into a candidate feature. The CV block does not
        # state a role family, so it starts as "unknown" and is later replaced by the
        # LLM's own inference from the CV text only.
        cv_docs.append(
            make_document(
                doc_id=cand_id,
                doc_type="gt_cv",
                source_path=str(path.relative_to(cfg.root)),
                title=cv_info["title"],
                role_family="unknown",
                raw_text=cv_text,
                pages=len(pages),
                split="heldout",
                meta={
                    "company": cv_info["company"],
                    "location": cv_info["location"],
                    "source_jd": pid,
                    "role_family_source": "cv_text_only",
                },
            )
        )
        rows.append(
            {
                "jd_id": pid,
                "jd_title": jd_info["title"],
                "role_family": jd_info["role_family"],
                "jd_location": jd_info["location"],
                "jd_salary": jd_info["salary"],
                "hired_cv_id": cand_id,
                "hired_cv_title": cv_info["title"],
                "hired_cv_company": cv_info["company"],
                "source_pdf": path.name,
                "notes": "",
                "_jd_chars": len(jd_text),
                "_cv_chars": len(cv_text),
                "_cv_location": cv_info["location"],
            }
        )
        if len(jd_text) < 500:
            problems.append({"file": path.name, "issue": f"jd_text too short ({len(jd_text)})"})
        if len(cv_text) < 400:
            problems.append({"file": path.name, "issue": f"cv_text too short ({len(cv_text)})"})

    log.info("GT JDs parsed: %d, hired CVs: %d", len(jd_docs), len(cv_docs))
    for p in problems:
        log.warning("split problem: %s", p)
    return jd_docs, cv_docs, rows


def load_unlabelled_jds(cfg, log) -> list[Document]:
    xlsx = next(cfg.path("data").glob(cfg.raw["paths"]["xlsx_glob"]))
    df = pd.read_excel(xlsx, sheet_name="JD Examples")
    df = df.dropna(how="all")
    df = df[df["#"].notna()].reset_index(drop=True)

    docs: list[Document] = []
    for i, row in df.iterrows():
        doc_id = f"JD-{i + 1:03d}"
        parts = [
            f"Position: {row['Position']}",
            f"Role family: {row['Role family']}",
            f"Country: {row['Country']}",
            f"City: {row['City']}",
            f"Remote: {row['Remote']}",
            f"Contract type: {row['Contract type']}",
            f"Salary: {row['Salary min']} - {row['Salary max']} {row['Currency']} per {row['Salary frequency']}",
            "",
            str(row["Job description"] or ""),
        ]
        text = clean_text("\n".join(parts), drop_p_ids=False)
        docs.append(
            make_document(
                doc_id=doc_id,
                doc_type="unlabelled_jd",
                source_path=str(xlsx.relative_to(cfg.root)) + "#JD Examples",
                title=str(row["Position"] or ""),
                role_family=str(row["Role family"] or "unknown"),
                raw_text=text,
                pages=0,
                split="train",
                meta={
                    "country": row["Country"],
                    "city": row["City"],
                    "remote": row["Remote"],
                    "contract_type": row["Contract type"],
                    "salary_min": None if pd.isna(row["Salary min"]) else float(row["Salary min"]),
                    "salary_max": None if pd.isna(row["Salary max"]) else float(row["Salary max"]),
                    "currency": row["Currency"],
                    "salary_frequency": row["Salary frequency"],
                },
            )
        )
    log.info("unlabelled JDs parsed: %d", len(docs))
    return docs


def load_excel_cvs(cfg) -> pd.DataFrame:
    xlsx = next(cfg.path("data").glob(cfg.raw["paths"]["xlsx_glob"]))
    df = pd.read_excel(xlsx, sheet_name="CV Examples")
    df = df.dropna(how="all")
    df = df[df["Ref"].notna()].reset_index(drop=True)
    df["Ref"] = df["Ref"].astype(str).str.strip()
    return df


# --------------------------------------------------------------------------- #
# Persistence helpers
# --------------------------------------------------------------------------- #
def write_jsonl(path: Path, rows: Iterable[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as fh:
        for row in rows:
            fh.write(json.dumps(row, ensure_ascii=False) + "\n")


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with open(path, "r", encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def load_documents(cfg) -> list[Document]:
    rows = read_jsonl(cfg.path("processed") / "documents.jsonl")
    return [Document(**r) for r in rows]


# --------------------------------------------------------------------------- #
# Deduplication
# --------------------------------------------------------------------------- #
def _normalise_company(s: str) -> str:
    s = re.sub(r"[^a-z0-9 ]", " ", (s or "").lower())
    s = re.sub(r"\b(sdn|bhd|pte|ltd|inc|corp|co|llc|group|holdings|berhad)\b", " ", s)
    return re.sub(r"\s+", " ", s).strip()


def dedupe_report(hired_cvs: list[Document], pool_cvs: list[Document], top_n: int = 3) -> pd.DataFrame:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity

    corpus = [d.raw_text for d in hired_cvs] + [d.raw_text for d in pool_cvs]
    vec = TfidfVectorizer(stop_words="english", sublinear_tf=True, min_df=1)
    X = vec.fit_transform(corpus)
    H = X[: len(hired_cvs)]
    P = X[len(hired_cvs) :]
    sim = cosine_similarity(H, P)

    rows: list[dict[str, Any]] = []
    for i, hcv in enumerate(hired_cvs):
        order = np.argsort(-sim[i])[:top_n]
        best = order[0]
        pcv = pool_cvs[best]
        same_title = hcv.title.strip().lower() == pcv.title.strip().lower()
        same_company = _normalise_company(hcv.meta.get("company", "")) == _normalise_company(
            pcv.raw_text.split("\n")[1] if "\n" in pcv.raw_text else ""
        )
        cos = float(sim[i][best])
        decision = "map_to_existing" if (cos >= 0.95 and same_title and same_company) else "keep_new"
        for rank, j in enumerate(order, start=1):
            rows.append(
                {
                    "hired_cv_id": hcv.doc_id,
                    "pool_cv_id": pool_cvs[j].doc_id,
                    "cosine": round(float(sim[i][j]), 6),
                    "lookalike_rank": rank,
                    "hired_title": hcv.title,
                    "pool_title": pool_cvs[j].title,
                    "title_match": int(hcv.title.strip().lower() == pool_cvs[j].title.strip().lower()),
                    "decision": decision,
                    "notes": "true duplicate" if decision == "map_to_existing" else "lookalike only",
                }
            )
    return pd.DataFrame(rows)


def jd_dedupe_report(gt_jds: list[Document], unlabelled: list[Document], threshold: float = 0.90) -> pd.DataFrame:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity

    corpus = [d.raw_text for d in gt_jds] + [d.raw_text for d in unlabelled]
    vec = TfidfVectorizer(stop_words="english", sublinear_tf=True)
    X = vec.fit_transform(corpus)
    G = X[: len(gt_jds)]
    U = X[len(gt_jds) :]
    sim = cosine_similarity(G, U)
    rows: list[dict[str, Any]] = []
    for i, g in enumerate(gt_jds):
        best = int(np.argmax(sim[i]))
        rows.append(
            {
                "gt_jd_id": g.doc_id,
                "closest_unlabelled_jd": unlabelled[best].doc_id,
                "closest_title": unlabelled[best].title,
                "cosine": round(float(sim[i][best]), 6),
                "near_duplicate": int(sim[i][best] >= threshold),
                "decision": "exclude_from_training" if sim[i][best] >= threshold else "keep",
            }
        )
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- #
# Alignment of pool CV PDFs vs Excel rows
# --------------------------------------------------------------------------- #
def cv_alignment_report(pool_cvs: list[Document], excel_cvs: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any]]:
    pdf_ids = [d.doc_id for d in pool_cvs]
    xl_ids = list(excel_cvs["Ref"])
    rows: list[dict[str, Any]] = []
    by_id = {d.doc_id: d for d in pool_cvs}
    for _, row in excel_cvs.iterrows():
        ref = row["Ref"]
        doc = by_id.get(ref)
        if doc is None:
            rows.append({"ref": ref, "issue": "missing_pdf", "title_pdf": "", "title_xlsx": row["Current title"]})
            continue
        pdf_title = doc.title.strip().lower()
        xl_title = str(row["Current title"] or "").strip().lower()
        title_ok = int(bool(pdf_title) and (pdf_title in doc.raw_text.lower()) and (xl_title == pdf_title))
        company = str(row["Current company"] or "").strip()
        company_ok = int(bool(company) and company.lower() in doc.raw_text.lower())
        rows.append(
            {
                "ref": ref,
                "issue": "" if (title_ok and company_ok) else "metadata_mismatch",
                "title_pdf": doc.title,
                "title_xlsx": row["Current title"],
                "company_xlsx": company,
                "title_ok": title_ok,
                "company_ok": company_ok,
            }
        )
    df = pd.DataFrame(rows)
    summary = {
        "n_pdfs": len(pdf_ids),
        "n_excel": len(xl_ids),
        "missing_pdf": sorted(set(xl_ids) - set(pdf_ids)),
        "extra_pdf": sorted(set(pdf_ids) - set(xl_ids)),
        "n_title_mismatch": int((df.get("title_ok", pd.Series(dtype=int)) == 0).sum()),
        "n_company_mismatch": int((df.get("company_ok", pd.Series(dtype=int)) == 0).sum()),
        "role_family_counts": excel_cvs["Role family"].value_counts().to_dict(),
        "country_counts": excel_cvs["Country"].fillna("unknown").value_counts().to_dict(),
    }
    return df, summary
