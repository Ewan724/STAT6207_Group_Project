"""All static figures (matplotlib, >=200 dpi, PNG) for the report and website."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Iterable

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch  # noqa: E402

# Okabe-Ito colourblind-friendly palette
OKABE = {
    "orange": "#E69F00",
    "sky": "#56B4E9",
    "green": "#009E73",
    "yellow": "#F0E442",
    "blue": "#0072B2",
    "vermillion": "#D55E00",
    "purple": "#CC79A7",
    "grey": "#999999",
    "black": "#000000",
}
HIT = OKABE["green"]
MISS = OKABE["vermillion"]
NEUTRAL = OKABE["grey"]
NAVY = "#0B2545"
TEAL = "#0F7B6C"
CORAL = "#C1292E"

DPI = 200
STYLE = {
    "figure.facecolor": "white",
    "axes.facecolor": "white",
    "axes.edgecolor": "#444444",
    "axes.labelcolor": NAVY,
    "axes.titlecolor": NAVY,
    "axes.titlesize": 11,
    "axes.labelsize": 9,
    "xtick.color": "#333333",
    "ytick.color": "#333333",
    "xtick.labelsize": 8,
    "ytick.labelsize": 8,
    "legend.fontsize": 8,
    "font.size": 9,
    "axes.grid": True,
    "grid.color": "#E5E5E5",
    "grid.linewidth": 0.6,
    "savefig.dpi": DPI,
    "figure.autolayout": False,
}


def _setup() -> None:
    plt.rcParams.update(STYLE)


def _save(fig, path: Path, caption: str = "") -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    if caption:
        fig.text(0.005, 0.005, caption, fontsize=6.5, color="#666666", ha="left", va="bottom")
    fig.savefig(path, dpi=DPI, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    return path


# --------------------------------------------------------------------------- #
# 01 pipeline diagram
# --------------------------------------------------------------------------- #
def fig_pipeline(out: Path, stage_counts: dict[str, Any]) -> Path:
    _setup()
    fig, ax = plt.subplots(figsize=(13, 3.4))
    ax.axis("off")
    stages = [
        ("0", "Data\nvalidation", "170 docs\n110 candidates"),
        ("1", "Local LLM\nextraction", "Ollama\nqwen3:8b"),
        ("2", "Keyword\nmerging", "aliases +\nclusters"),
        ("3", "Autoencoder", "TF-IDF ->\n32-d latent"),
        ("4", "Retrieval", "M0-M6\ncosine"),
        ("5", "Recall@10", "hits / 10\n+ CIs"),
        ("6", "Error\nanalysis", "taxonomy +\ncase studies"),
        ("7", "Streamlit\nwebsite", "5 pages"),
    ]
    n = len(stages)
    w, h = 1.0, 0.62
    for i, (num, title, detail) in enumerate(stages):
        x = i * 1.22
        box = FancyBboxPatch(
            (x, 0.2),
            w,
            h,
            boxstyle="round,pad=0.02,rounding_size=0.06",
            linewidth=1.1,
            edgecolor=NAVY,
            facecolor="#EAF1F8" if i < 7 else "#DFF3EE",
        )
        ax.add_patch(box)
        ax.text(x + w / 2, 0.2 + h - 0.13, f"Stage {num}", ha="center", va="center", fontsize=7.5, color=TEAL, weight="bold")
        ax.text(x + w / 2, 0.2 + h / 2 - 0.02, title, ha="center", va="center", fontsize=8.3, color=NAVY, weight="bold")
        ax.text(x + w / 2, 0.31, detail, ha="center", va="center", fontsize=6.8, color="#444444")
        if i < n - 1:
            ax.add_patch(
                FancyArrowPatch((x + w + 0.02, 0.51), (x + 1.20, 0.51), arrowstyle="-|>", mutation_scale=11, color=NEUTRAL, lw=1.0)
            )
    ax.set_xlim(-0.08, n * 1.22)
    ax.set_ylim(0.05, 1.0)
    ax.set_title("AI CV matching baseline - seven-stage pipeline", fontsize=12, color=NAVY, pad=10)
    ax.text(
        0.0,
        0.02,
        f"corpus: {stage_counts.get('pool_cvs', 0)} pool CVs + {stage_counts.get('gt_cvs', 0)} hired CVs "
        f"+ {stage_counts.get('gt_jds', 0)} GT JDs + {stage_counts.get('unlabelled_jds', 0)} unlabelled JDs",
        fontsize=7.2,
        color="#555555",
    )
    return _save(fig, out / "01_pipeline_diagram.png")


# --------------------------------------------------------------------------- #
# 02 dataset overview
# --------------------------------------------------------------------------- #
def fig_dataset_overview(out: Path, meta: pd.DataFrame, gt: pd.DataFrame) -> Path:
    _setup()
    fig, axes = plt.subplots(2, 2, figsize=(12, 7.2))

    ax = axes[0, 0]
    counts = meta["doc_type"].value_counts()
    order = ["pool_cv", "gt_cv", "gt_jd", "unlabelled_jd"]
    labels = ["pool CV", "hired CV", "GT JD", "unlabelled JD"]
    vals = [int(counts.get(o, 0)) for o in order]
    colors = [OKABE["blue"], OKABE["orange"], OKABE["green"], OKABE["sky"]]
    bars = ax.bar(labels, vals, color=colors, edgecolor="white")
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v + 2, str(v), ha="center", fontsize=9, color=NAVY, weight="bold")
    ax.set_title("Document counts by type")
    ax.set_ylabel("documents")
    ax.set_ylim(0, max(vals) * 1.18)

    ax = axes[0, 1]
    fam = meta[meta["doc_type"].isin(["pool_cv", "gt_cv"])]["role_family"].value_counts().head(10)
    ax.barh(fam.index[::-1], fam.values[::-1], color=OKABE["blue"], edgecolor="white")
    for i, v in enumerate(fam.values[::-1]):
        ax.text(v + 0.3, i, str(v), va="center", fontsize=8, color=NAVY)
    ax.set_title("Candidate pool by role family")
    ax.set_xlabel("CVs")

    ax = axes[1, 0]
    for dtype, color in (("pool_cv", OKABE["blue"]), ("gt_cv", OKABE["orange"]), ("gt_jd", OKABE["green"]), ("unlabelled_jd", OKABE["sky"])):
        vals = meta[meta["doc_type"] == dtype]["char_count"]
        if len(vals):
            ax.hist(vals, bins=18, alpha=0.62, label=dtype, color=color, edgecolor="white")
    ax.set_title("Character length distribution")
    ax.set_xlabel("characters")
    ax.set_ylabel("documents")
    ax.legend(fontsize=7)

    ax = axes[1, 1]
    ax.axis("off")
    text_lines = [
        "Ground-truth pairs (10)",
        "",
        f"{'JD':6s}{'title':34s}{'hired candidate':18s}",
        "-" * 62,
    ]
    for _, r in gt.iterrows():
        text_lines.append(f"{r['jd_id']:6s}{str(r['jd_title'])[:32]:34s}{r['hired_cv_id']:18s}")
    ax.text(
        0.0,
        1.0,
        "\n".join(text_lines),
        family="monospace",
        fontsize=7.2,
        va="top",
        color=NAVY,
    )
    ax.set_title("Labelled pairs (only ground truth)", loc="left")

    fig.suptitle("Dataset overview", fontsize=13, color=NAVY)
    fig.tight_layout(rect=[0, 0.02, 1, 0.95])
    return _save(fig, out / "02_dataset_overview.png", "Source: DATA/ (100 pool CVs, 10 P-pair PDFs, 50 unlabelled JDs)")


# --------------------------------------------------------------------------- #
# 03 cluster network
# --------------------------------------------------------------------------- #
def fig_cluster_network(out: Path, clusters: pd.DataFrame, edges: pd.DataFrame, top_labels: int = 20) -> Path:
    _setup()
    import networkx as nx

    G = nx.Graph()
    for _, r in clusters.iterrows():
        G.add_node(r["canonical_label"], size=int(r["doc_frequency"]), cl=float(r["coherence"]))
    for _, e in edges.iterrows():
        if G.has_node(e["source"]) and G.has_node(e["target"]):
            G.add_edge(e["source"], e["target"], weight=int(e["weight"]))
    if G.number_of_nodes() == 0:
        fig, ax = plt.subplots(figsize=(6, 3))
        ax.axis("off")
        ax.text(0.5, 0.5, "no cluster edges", ha="center")
        return _save(fig, out / "03_keyword_cluster_network.png")

    pos = nx.spring_layout(G, seed=42, k=0.55, iterations=90)
    fig, ax = plt.subplots(figsize=(13, 9.5))
    sizes = np.array([G.nodes[n]["size"] for n in G.nodes()], dtype=float)
    smax = sizes.max() if sizes.size else 1.0
    node_sizes = 40 + 900 * (sizes / smax)

    for u, v, d in G.edges(data=True):
        ax.plot(
            [pos[u][0], pos[v][0]],
            [pos[u][1], pos[v][1]],
            color="#CBD5E1",
            linewidth=min(2.4, 0.28 + 0.22 * d["weight"]),
            zorder=1,
        )
    ax.scatter(
        [pos[n][0] for n in G.nodes()],
        [pos[n][1] for n in G.nodes()],
        s=node_sizes,
        c=[G.nodes[n]["cl"] for n in G.nodes()],
        cmap="viridis",
        alpha=0.86,
        edgecolors="white",
        linewidths=0.6,
        zorder=2,
    )
    top = clusters.nlargest(top_labels, "doc_frequency")["canonical_label"].tolist()
    for n in top:
        if n in pos:
            ax.text(pos[n][0], pos[n][1] + 0.018, n[:24], fontsize=6.6, ha="center", color=NAVY, zorder=3)
    ax.set_title(f"Keyword-cluster co-occurrence network ({G.number_of_nodes()} clusters, {G.number_of_edges()} edges)", fontsize=12)
    ax.axis("off")
    sm = plt.cm.ScalarMappable(cmap="viridis", norm=plt.Normalize(min(0, min(G.nodes[n]["cl"] for n in G.nodes())), 1.0))
    cb = fig.colorbar(sm, ax=ax, fraction=0.025, pad=0.01)
    cb.set_label("cluster coherence", fontsize=8)
    return _save(
        fig,
        out / "03_keyword_cluster_network.png",
        "Nodes = canonical clusters, size = document frequency, colour = coherence, edges = co-occurrence in >=2 documents",
    )


# --------------------------------------------------------------------------- #
# 04 cluster sizes
# --------------------------------------------------------------------------- #
def fig_cluster_sizes(out: Path, clusters: pd.DataFrame, n: int = 30) -> Path:
    _setup()
    top = clusters.nlargest(n, "size").sort_values("size")
    fig, ax = plt.subplots(figsize=(10, 8))
    y = np.arange(len(top))
    ax.barh(y, top["size"], color=OKABE["blue"], label="members", height=0.62)
    ax.barh(y, top["doc_frequency"], color=OKABE["orange"], alpha=0.55, label="document frequency", height=0.62)
    ax.set_yticks(y)
    ax.set_yticklabels([f"{lbl[:30]}" for lbl in top["canonical_label"]], fontsize=7)
    for i, (s, d) in enumerate(zip(top["size"], top["doc_frequency"])):
        ax.text(max(s, d) + 0.4, i, f"{int(s)} / {int(d)}", va="center", fontsize=6.8, color="#444444")
    ax.set_xlabel("count")
    ax.set_title(f"30 largest keyword clusters (members / document frequency)")
    ax.legend(loc="lower right")
    fig.tight_layout()
    return _save(fig, out / "04_keyword_cluster_sizes.png")


# --------------------------------------------------------------------------- #
# 05 merge examples
# --------------------------------------------------------------------------- #
def fig_merge_examples(out: Path, aliases: pd.DataFrame, clusters: pd.DataFrame, n: int = 16) -> Path:
    _setup()
    multi = clusters[clusters["size"] > 1].nlargest(n, "size")
    rows = []
    for _, r in multi.iterrows():
        members = str(r["members"]).split("|")
        variants = [m for m in members if m != r["canonical_label"].lower()]
        rows.append((r["canonical_label"], ", ".join(variants[:4]) or "-", int(r["size"])))
    if not rows:
        rows = [("(no multi-member clusters)", "-", 0)]

    n_rows = len(rows)
    fig_h = 0.52 * n_rows + 1.9
    fig, ax = plt.subplots(figsize=(13.5, fig_h))
    ax.axis("off")
    ax.set_title("Keyword merge examples: raw variants → canonical label", fontsize=12.5, pad=16, loc="left")

    ax.text(0.015, 0.975, "raw variants (as extracted by the LLM)", fontsize=8.6, weight="bold", color=NAVY, va="top")
    ax.text(0.60, 0.975, "canonical label", fontsize=8.6, weight="bold", color=NAVY, va="top")
    ax.text(0.965, 0.975, "members", fontsize=8.6, weight="bold", color=NAVY, va="top", ha="right")

    top = 0.925
    step = 0.86 / max(1, n_rows)
    for i, (label, variants, size) in enumerate(rows):
        y = top - i * step
        ax.text(0.015, y, variants[:62], fontsize=7.6, color="#334155", va="center")
        ax.annotate(
            "",
            xy=(0.592, y),
            xytext=(0.545, y),
            xycoords="axes fraction",
            textcoords="axes fraction",
            arrowprops=dict(arrowstyle="-|>", color=NEUTRAL, lw=1.0),
        )
        ax.text(0.605, y, label[:30], fontsize=8.2, color=TEAL, weight="bold", va="center")
        ax.text(0.965, y, str(size), fontsize=7.6, color="#64748B", va="center", ha="right")
        if i < n_rows - 1:
            ax.axhline(y - step / 2, color="#EEF2F6", lw=0.8, xmin=0.015, xmax=0.965)

    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    return _save(
        fig,
        out / "05_keyword_merge_examples.png",
        f"The {n_rows} largest multi-member clusters. Full mapping: data/processed/keyword_aliases.csv and keyword_clusters.csv",
    )


# --------------------------------------------------------------------------- #
# 05b coverage heatmap
# --------------------------------------------------------------------------- #
def fig_keyword_heatmap(
    out: Path,
    clusters: pd.DataFrame,
    meta: pd.DataFrame,
    payloads: dict,
    alias_map: dict,
    doc_index: pd.DataFrame | None = None,
    doc_matrix=None,
    n: int = 25,
) -> Path:
    """Top clusters x role family, aggregated from the real document x cluster matrix."""
    _setup()
    if doc_index is None or doc_matrix is None:
        fig, ax = plt.subplots(figsize=(6, 3))
        ax.axis("off")
        ax.text(0.5, 0.5, "document x cluster matrix unavailable", ha="center")
        return _save(fig, out / "05b_keyword_coverage_heatmap.png")

    fams = ["Engineering", "Data & AI", "Sales & BD", "Marketing", "Finance & Legal", "Product", "Design & Creative", "Operations & HR"]

    import numpy as np

    X = doc_matrix.toarray() if hasattr(doc_matrix, "toarray") else np.asarray(doc_matrix)
    index = doc_index.set_index("doc_id")
    cl = clusters.set_index("cluster_id")

    # pick the top-N clusters by total weight across documents
    totals = np.asarray(X.sum(axis=0)).ravel()
    keep = np.argsort(-totals)[:n]
    labels = [str(cl.loc[int(c), "canonical_label"]) if int(c) in cl.index else f"cluster {c}" for c in keep]

    mat = np.zeros((len(keep), len(fams)))
    for r, doc_id in enumerate(index.index):
        if doc_id not in index.index:
            continue
        row = index.loc[doc_id]
        fam = row.get("role_family") if hasattr(row, "get") else row["role_family"]
        if fam not in fams:
            continue
        j = fams.index(fam)
        vec = X[r]
        mat[:, j] += vec[keep]

    fig, ax = plt.subplots(figsize=(8.8, 9.4))
    im = ax.imshow(mat, aspect="auto", cmap="YlGnBu")
    ax.set_xticks(range(len(fams)))
    ax.set_xticklabels(fams, rotation=38, ha="right", fontsize=7.6)
    ax.set_yticks(range(len(labels)))
    ax.set_yticklabels([l[:32] for l in labels], fontsize=7.2)
    vmax = mat.max() if mat.max() > 0 else 1.0
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            v = mat[i, j]
            if v > 0:
                ax.text(j, i, f"{v:.0f}" if v >= 1 else f"{v:.1f}", ha="center", va="center",
                        fontsize=6, color="white" if v > vmax * 0.62 else "#222222")
    ax.set_title("Top 25 keyword clusters × role family\n(aggregated TF-IDF weight in each family's documents)", fontsize=10.5)
    ax.grid(False)
    cb = fig.colorbar(im, ax=ax, fraction=0.03, pad=0.02)
    cb.set_label("summed document weight", fontsize=7.5)
    fig.tight_layout()
    return _save(
        fig,
        out / "05b_keyword_coverage_heatmap.png",
        "Built from data/processed/document_keyword_matrix.npz; rows are the 25 clusters with the largest total weight.",
    )


# --------------------------------------------------------------------------- #
# 06 AE architecture
# --------------------------------------------------------------------------- #
def fig_ae_architecture(out: Path, input_dim: int, hidden: list[int], latent: int) -> Path:
    _setup()
    dims = [input_dim, *hidden, latent, *reversed(hidden), input_dim]
    labels = ["input\n(TF-IDF clusters)", *[f"Linear {h}" for h in hidden], f"bottleneck\n{latent}-d", *[f"Linear {h}" for h in reversed(hidden)], "reconstruction"]
    fig, ax = plt.subplots(figsize=(12.4, 3.2))
    ax.axis("off")
    n = len(dims)
    for i, (d, lbl) in enumerate(zip(dims, labels)):
        x = i * 1.35
        h = 0.32 + 0.5 * (d / max(dims))
        color = "#DFF3EE" if i == 3 else ("#EAF1F8" if i < 3 else "#F5F5F5")
        ax.add_patch(FancyBboxPatch((x, 0.55 - h / 2), 1.03, h, boxstyle="round,pad=0.02,rounding_size=0.05", facecolor=color, edgecolor=NAVY, lw=1.0))
        ax.text(x + 0.515, 0.55, f"{d}", ha="center", va="center", fontsize=9, weight="bold", color=NAVY)
        ax.text(x + 0.515, 0.16, lbl.replace("\n", " "), ha="center", va="center", fontsize=6.6, color="#333333", wrap=True)
        if i < n - 1:
            ax.add_patch(FancyArrowPatch((x + 1.05, 0.55), (x + 1.32, 0.55), arrowstyle="-|>", mutation_scale=10, color=NEUTRAL, lw=0.9))
    ax.text(n * 1.35 / 2, 0.93, "encoder  ->  bottleneck (document embedding)  ->  decoder", ha="center", fontsize=9.5, color=TEAL, weight="bold")
    ax.set_xlim(-0.1, n * 1.35)
    ax.set_ylim(0.02, 1.05)
    ax.set_title("Autoencoder architecture: GELU + dropout(0.2) after each hidden layer, MSE reconstruction loss")
    return _save(fig, out / "06_ae_architecture.png")


# --------------------------------------------------------------------------- #
# 07 loss curves
# --------------------------------------------------------------------------- #
def fig_loss_curves(out: Path, history: pd.DataFrame, best_epoch: int) -> Path:
    _setup()
    fig, ax = plt.subplots(figsize=(9, 4.6))
    ax.plot(history["epoch"], history["train_mse"], label="train MSE", color=OKABE["blue"], lw=1.6)
    ax.plot(history["epoch"], history["val_mse"], label="validation MSE", color=OKABE["vermillion"], lw=1.6)
    best_row = history[history["epoch"] == best_epoch]
    if len(best_row):
        ax.scatter(best_row["epoch"], best_row["val_mse"], s=70, color=OKABE["green"], zorder=5, label=f"best epoch {best_epoch}")
        ax.axvline(best_epoch, color=OKABE["green"], ls="--", lw=0.9, alpha=0.7)
    ax.set_xlabel("epoch")
    ax.set_ylabel("MSE")
    ax.set_yscale("log")
    ax.set_title("Autoencoder training history (log scale)")
    ax.legend()
    fig.tight_layout()
    return _save(fig, out / "07_ae_loss_curves.png")


# --------------------------------------------------------------------------- #
# 08 reconstruction error
# --------------------------------------------------------------------------- #
def fig_reconstruction_error(out: Path, recon: pd.DataFrame) -> Path:
    _setup()
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.4))
    ax = axes[0]
    for dtype, color in (("pool_cv", OKABE["blue"]), ("gt_cv", OKABE["orange"]), ("gt_jd", OKABE["green"]), ("unlabelled_jd", OKABE["sky"])):
        vals = recon[recon["doc_type"] == dtype]["reconstruction_mse"]
        if len(vals):
            ax.hist(vals, bins=16, alpha=0.66, label=dtype, color=color, edgecolor="white")
    ax.set_xlabel("per-document reconstruction MSE")
    ax.set_ylabel("documents")
    ax.set_title("Reconstruction error by document type")
    ax.legend(fontsize=7)

    ax = axes[1]
    order = ["pool_cv", "gt_cv", "gt_jd", "unlabelled_jd"]
    data = [recon[recon["doc_type"] == o]["reconstruction_mse"].dropna().values for o in order if o in set(recon["doc_type"])]
    labels = [o for o in order if o in set(recon["doc_type"])]
    bp = ax.boxplot(data, tick_labels=labels, patch_artist=True, widths=0.55)
    for patch in bp["boxes"]:
        patch.set_facecolor("#DCE8F4")
    ax.set_ylabel("reconstruction MSE")
    ax.set_title("Distribution by document type")
    fig.tight_layout()
    return _save(fig, out / "08_ae_reconstruction_error.png")


# --------------------------------------------------------------------------- #
# 08b reconstruction examples
# --------------------------------------------------------------------------- #
def fig_reconstruction_examples(out: Path, examples: pd.DataFrame) -> Path:
    _setup()
    docs = examples["doc_id"].unique()[:5]
    fig, axes = plt.subplots(1, len(docs), figsize=(3.1 * len(docs), 3.5))
    if len(docs) == 1:
        axes = [axes]
    for ax, doc in zip(axes, docs):
        sub = examples[examples["doc_id"] == doc].sort_values("rank")
        y = np.arange(len(sub))
        ax.barh(y - 0.19, sub["input_value"], height=0.36, color=OKABE["blue"], label="input")
        ax.barh(y + 0.19, sub["reconstructed_value"], height=0.36, color=OKABE["orange"], label="reconstructed")
        ax.set_yticks(y)
        ax.set_yticklabels([f"{i + 1}. {l[:14]}" for i, l in enumerate(sub["input_cluster"])], fontsize=6.4)
        ax.invert_yaxis()
        ax.set_title(doc, fontsize=8.5)
        ax.set_xlabel("weight", fontsize=7)
    axes[0].legend(fontsize=6.5, loc="lower right")
    fig.suptitle("Top-10 clusters: input vs AE reconstruction", fontsize=11, color=NAVY)
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    return _save(fig, out / "08b_ae_reconstruction_examples.png")


# --------------------------------------------------------------------------- #
# 09/10 latent space
# --------------------------------------------------------------------------- #
def _latent_panels(out: Path, emb: pd.DataFrame, gt: pd.DataFrame, coords: np.ndarray, title: str, fname: str) -> Path:
    from sklearn.decomposition import PCA

    _setup()
    fig, axes = plt.subplots(1, 2, figsize=(14, 6.4))
    styles = {
        "pool_cv": ("o", OKABE["blue"], 34, "pool CV"),
        "gt_cv": ("*", OKABE["orange"], 170, "hired CV"),
        "gt_jd": ("s", OKABE["green"], 95, "GT JD"),
        "unlabelled_jd": ("^", OKABE["sky"], 45, "unlabelled JD"),
    }
    for ax, colour_by in zip(axes, ("doc_type", "role_family")):
        if colour_by == "doc_type":
            for dtype, (marker, color, size, label) in styles.items():
                m = emb["doc_type"] == dtype
                if m.any():
                    ax.scatter(coords[m, 0], coords[m, 1], c=color, marker=marker, s=size, alpha=0.85, edgecolors="white", linewidths=0.4, label=label)
            # draw GT pair links
            pos = {d: i for i, d in enumerate(emb["doc_id"])}
            for _, r in gt.iterrows():
                a, b = pos.get(r["jd_id"]), pos.get(r["hired_cv_id"])
                if a is None or b is None:
                    continue
                ax.plot(
                    [coords[a, 0], coords[b, 0]],
                    [coords[a, 1], coords[b, 1]],
                    color=OKABE["vermillion"],
                    lw=1.1,
                    alpha=0.75,
                    zorder=1,
                )
                ax.annotate(r["jd_id"], (coords[a, 0], coords[a, 1]), fontsize=6.6, color=OKABE["vermillion"], xytext=(3, 3), textcoords="offset points")
            ax.legend(fontsize=7, loc="best")
            ax.set_title(f"{title} - coloured by document type (lines = GT pairs)")
        else:
            fams = sorted(emb["role_family"].fillna("unknown").unique())
            cmap = plt.get_cmap("tab10")
            for i, fam in enumerate(fams):
                m = emb["role_family"].fillna("unknown") == fam
                ax.scatter(coords[m, 0], coords[m, 1], c=[cmap(i % 10)], s=36, alpha=0.86, edgecolors="white", linewidths=0.4, label=fam)
            ax.legend(fontsize=6.4, loc="best", ncol=2)
            ax.set_title(f"{title} - coloured by role family")
        ax.set_xlabel("component 1")
        ax.set_ylabel("component 2")
    fig.suptitle(f"Latent space of {len(emb)} documents", fontsize=12, color=NAVY)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    return _save(fig, out / fname)


def fig_latent_pca(out: Path, emb: pd.DataFrame, gt: pd.DataFrame) -> Path:
    from sklearn.decomposition import PCA

    dims = [c for c in emb.columns if c.startswith("dim_")]
    coords = PCA(n_components=2, random_state=42).fit_transform(emb[dims].to_numpy())
    return _latent_panels(out, emb, gt, coords, "PCA projection", "09_latent_space_pca.png")


def fig_latent_umap(out: Path, emb: pd.DataFrame, gt: pd.DataFrame) -> Path:
    dims = [c for c in emb.columns if c.startswith("dim_")]
    text = emb[dims].to_numpy()
    name = "10_latent_space_umap.png"
    try:
        import umap  # type: ignore

        coords = umap.UMAP(n_neighbors=12, min_dist=0.15, random_state=42).fit_transform(text)
        title = "UMAP projection"
    except Exception:
        from sklearn.manifold import TSNE

        perplexity = min(20, max(5, len(text) // 8))
        coords = TSNE(n_components=2, perplexity=perplexity, random_state=42, init="pca").fit_transform(text)
        title = f"t-SNE projection (perplexity={perplexity})"
        name = "10_latent_space_tsne.png"
    return _latent_panels(out, emb, gt, coords, title, name)


# --------------------------------------------------------------------------- #
# 11 recall by JD
# --------------------------------------------------------------------------- #
def fig_recall_by_jd(out: Path, per_query: pd.DataFrame, model: str = "M3") -> Path:
    _setup()
    sub = per_query[per_query["model"] == model].sort_values("jd_id")
    fig, ax = plt.subplots(figsize=(10.6, 5.6))
    ranks = sub["rank"].astype(int).to_numpy()
    y = np.arange(len(sub))

    for i, r in enumerate(ranks):
        colour = HIT if r <= 10 else MISS
        ax.plot([0, r], [i, i], color=colour, lw=2.4, alpha=0.55, zorder=1)
        ax.scatter(r, i, s=120, color=colour, zorder=3, edgecolors="white", linewidths=1.0)
        verdict = "hit" if r <= 10 else "miss"
        ax.text(r + (ranks.max() * 0.022), i, f"#{r} ({verdict})", va="center", fontsize=8.6,
                color=NAVY, weight="bold")

    ax.axvline(10, color=NAVY, ls="--", lw=1.1, zorder=0)
    ax.annotate(
        "top-10 cut-off",
        xy=(10, 1.0),
        xycoords=("data", "axes fraction"),
        xytext=(4, -12),
        textcoords="offset points",
        fontsize=7.8,
        color=NAVY,
        ha="left",
        va="top",
    )
    ax.set_yticks(y)
    ax.set_yticklabels(sub["jd_id"])
    ax.invert_yaxis()  # P01 at the top
    ax.set_xlim(0, ranks.max() * 1.20)
    ax.set_xlabel("rank of the hired CV (1 = best)")
    ax.set_ylabel("query (labelled JD)")
    ax.set_title(f"Rank of the hired CV per JD — primary model {model} (green = hit@10, red = miss)")
    ax.grid(axis="y", visible=False)
    fig.tight_layout()
    return _save(fig, out / "11_recall_by_jd.png", f"Model {model}; one relevant CV per query, n = 10.")


# --------------------------------------------------------------------------- #
# 12 metric comparison
# --------------------------------------------------------------------------- #
def fig_metric_comparison(out: Path, summary: pd.DataFrame) -> Path:
    _setup()
    metrics = ["recall_at_10", "hit_at_1", "hit_at_5", "mrr_at_10"]
    labels = ["Recall@10", "Hit@1", "Hit@5", "MRR@10"]
    fig, ax = plt.subplots(figsize=(11.4, 5.0))
    x = np.arange(len(summary))
    width = 0.2
    for i, (m, lab) in enumerate(zip(metrics, labels)):
        ax.bar(x + (i - 1.5) * width, summary[m], width=width, label=lab)
    ax.set_xticks(x)
    ax.set_xticklabels([f"{r['model']}\n{r['model_name']}" for _, r in summary.iterrows()], fontsize=7)
    ax.set_ylabel("score")
    ax.set_ylim(0, 1.05)
    ax.legend(ncol=4, fontsize=8)
    prim = summary[summary.get("is_primary", 0) == 1]
    if len(prim):
        idx = list(summary["model"]).index(prim.iloc[0]["model"])
        ax.axvspan(idx - 0.5, idx + 0.5, color="#DFF3EE", alpha=0.55, zorder=0)
        ax.text(idx, 1.01, "primary", ha="center", fontsize=8, color=TEAL, weight="bold")
    ax.set_title("Model comparison on the 10 labelled queries (n=10)")
    fig.tight_layout()
    return _save(fig, out / "12_metric_comparison.png")


# --------------------------------------------------------------------------- #
# 13 rank distribution
# --------------------------------------------------------------------------- #
def fig_rank_distribution(out: Path, per_query: pd.DataFrame) -> Path:
    _setup()
    buckets = [("1", 1, 1), ("2-5", 2, 5), ("6-10", 6, 10), ("11-20", 11, 20), ("21-50", 21, 50), ("51-110", 51, 110)]
    models = sorted(per_query["model"].unique())
    fig, ax = plt.subplots(figsize=(10, 4.6))
    width = 0.8 / len(models)
    for i, m in enumerate(models):
        ranks = per_query[per_query["model"] == m]["rank"]
        counts = [int(((ranks >= lo) & (ranks <= hi)).sum()) for _, lo, hi in buckets]
        ax.bar(np.arange(len(buckets)) + (i - len(models) / 2 + 0.5) * width, counts, width=width, label=m)
    ax.set_xticks(range(len(buckets)))
    ax.set_xticklabels([b[0] for b in buckets])
    ax.set_xlabel("rank bucket of the hired CV")
    ax.set_ylabel("number of queries")
    ax.set_title("Distribution of hired-CV ranks per model (10 queries)")
    ax.legend(ncol=7, fontsize=7, loc="upper right")
    fig.tight_layout()
    return _save(fig, out / "13_rank_distribution.png")


# --------------------------------------------------------------------------- #
# 14 score margin
# --------------------------------------------------------------------------- #
def fig_score_margin(out: Path, per_query: pd.DataFrame, model: str = "M3") -> Path:
    _setup()
    sub = per_query[per_query["model"] == model].sort_values("jd_id")
    fig, ax = plt.subplots(figsize=(10.6, 4.8))
    colors = [HIT if r <= 10 else MISS for r in sub["rank"]]
    ax.bar(sub["jd_id"], sub["score_margin"], color=colors, edgecolor="white")
    ax.axhline(0, color=NAVY, lw=1.0)
    for i, (_, r) in enumerate(sub.iterrows()):
        y = r["score_margin"]
        ax.text(i, y + (0.006 if y >= 0 else -0.006), f"{y:+.3f}", ha="center", va="bottom" if y >= 0 else "top", fontsize=7.2)
        if r["rank"] > 10:
            ax.text(i, y - 0.028, f"miss #{int(r['rank'])}", ha="center", va="top", fontsize=6.8, color=CORAL)
    ax.set_xlabel("query")
    ax.set_ylabel("hired score - top-1 score")
    ax.set_title(f"Score margin per query - {model} (positive = hired CV ranked first)")
    fig.tight_layout()
    return _save(fig, out / "14_score_margin.png")


# --------------------------------------------------------------------------- #
# 15 / 18 case study coverage heatmaps
# --------------------------------------------------------------------------- #
def fig_case_study_heatmap(out: Path, matrices: dict[str, pd.DataFrame], fname: str, title: str) -> Path:
    """Per-case-study diagnostics: must-have coverage per top-10 candidate.

    A binary presence matrix is mostly empty here (the candidate pool genuinely
    lacks most of a given JD's must-have clusters), so the figure reports the
    coverage fraction plus the number of matched clusters per candidate, which is
    the quantity that actually drives the ranking.
    """
    _setup()
    n = max(1, len(matrices))
    fig, axes = plt.subplots(1, n, figsize=(4.5 * n, 4.5), squeeze=False)
    for ax, (jd_id, mat) in zip(axes[0], matrices.items()):
        if mat is None or mat.empty:
            ax.axis("off")
            ax.text(0.5, 0.5, f"{jd_id}\nno must-have clusters", ha="center", va="center")
            continue
        data = mat.to_numpy(dtype=float)
        present = (data > 0).sum(axis=1)
        n_cols = int(data.shape[1])
        coverage = present / max(1, n_cols)
        labels = list(mat.index)
        colours = [HIT if str(l).startswith("HIRED") else OKABE["blue"] for l in labels]
        y = np.arange(len(labels))
        ax.barh(y, coverage, color=colours, height=0.66, edgecolor="white")
        for i, (c, p) in enumerate(zip(coverage, present)):
            ax.text(min(float(c) + 0.02, 1.02), i, f"{int(p)}/{n_cols}", va="center", fontsize=7.6, color=NAVY)
        ax.set_yticks(y)
        ax.set_yticklabels(labels, fontsize=7)
        ax.invert_yaxis()
        ax.set_xlim(0, 1.10)
        ax.set_xlabel("must-have coverage", fontsize=8)
        ax.set_title(jd_id, fontsize=9.5)
        ax.grid(axis="y", visible=False)
    fig.suptitle(title, fontsize=11.5, color=NAVY)
    fig.tight_layout(rect=[0, 0, 1, 0.92])
    return _save(
        fig,
        out / fname,
        "Bars = fraction of the JD's must-have clusters present in each top-10 candidate; labels show matched/total. "
        "The hired CV is green.",
    )


# --------------------------------------------------------------------------- #
# 16 AE vs TFIDF
# --------------------------------------------------------------------------- #
def fig_ae_vs_tfidf(out: Path, cmp_df: pd.DataFrame) -> Path:
    _setup()
    fig, ax = plt.subplots(figsize=(10.4, 5.0))
    cmp_df = cmp_df.sort_values("jd_id")
    x = np.arange(len(cmp_df))
    for i, (_, r) in enumerate(cmp_df.iterrows()):
        color = HIT if r["delta"] < 0 else (MISS if r["delta"] > 0 else NEUTRAL)
        ax.plot([i, i], [r["tfidf_rank"], r["ae_rank"]], color=color, lw=2.2, zorder=1, alpha=0.85)
        ax.scatter(i, r["tfidf_rank"], color=OKABE["blue"], s=48, zorder=3, label="M1 TF-IDF" if i == 0 else None)
        ax.scatter(i, r["ae_rank"], color=OKABE["orange"], marker="s", s=44, zorder=3, label="M3 AE" if i == 0 else None)
    ax.axhline(10, color=NAVY, ls="--", lw=1.0)
    ax.text(len(cmp_df) - 0.5, 11.4, "top-10 cut-off", ha="right", fontsize=7.4, color=NAVY)
    ax.set_xticks(x)
    ax.set_xticklabels(cmp_df["jd_id"])
    ax.set_yscale("log")
    ax.set_ylabel("rank of the hired CV (log scale, lower is better)")
    ax.set_title("AE vs TF-IDF: hired-CV rank per query")
    ax.legend()
    fig.tight_layout()
    return _save(fig, out / "16_ae_vs_tfidf_ranks.png")


# --------------------------------------------------------------------------- #
# 17 error taxonomy
# --------------------------------------------------------------------------- #
def fig_error_taxonomy(out: Path, tax: pd.DataFrame) -> Path:
    _setup()
    sub = tax[tax["count"] > 0].sort_values("count")
    fig, ax = plt.subplots(figsize=(9.4, 4.8))
    if len(sub):
        ax.barh([f"{r['code']} {r['category']}" for _, r in sub.iterrows()], sub["count"], color=OKABE["vermillion"], edgecolor="white")
        for i, v in enumerate(sub["count"]):
            ax.text(v + 0.05, i, str(int(v)), va="center", fontsize=8.5, color=NAVY)
    else:
        ax.text(0.5, 0.5, "no misses for this model", ha="center", transform=ax.transAxes)
    ax.set_xlabel("primary failure category count (misses only)")
    ax.set_title("Failure taxonomy for the primary model (M3 AE-32)")
    fig.tight_layout()
    return _save(fig, out / "17_error_taxonomy.png")


# --------------------------------------------------------------------------- #
# 19 recommendation matrix
# --------------------------------------------------------------------------- #
def fig_recommendations(out: Path, recs: pd.DataFrame) -> Path:
    _setup()
    effort_map = {"low": 1, "medium": 2, "high": 3}
    impact_map = {"low": 1, "low-medium": 1.5, "medium": 2, "medium-high": 2.5, "high": 3}
    fig, ax = plt.subplots(figsize=(11.0, 6.6))
    colors = {"P0": CORAL, "P1": OKABE["orange"], "P2": OKABE["sky"]}

    # small deterministic jitter so identical (effort, impact) pairs do not overplot
    seen: dict[tuple[int, float], int] = {}
    points = []
    for _, r in recs.iterrows():
        ex = effort_map.get(r["effort"], 2)
        iy = impact_map.get(r["expected_impact"], 2)
        key = (ex, iy)
        n = seen.get(key, 0)
        seen[key] = n + 1
        jx = ex + (0.13 if n % 2 else -0.13) * (n // 2 + 1) / 2
        jy = iy + (0.09 * ((n + 1) // 2)) * (1 if n % 2 else -1)
        points.append((jx, jy, r))

    points.sort(key=lambda p: p[1])
    for jx, jy, r in points:
        ax.scatter(jx, jy, s=190, color=colors.get(r["priority"], NEUTRAL), alpha=0.88,
                   edgecolors="white", linewidths=1.2, zorder=3)
        ax.annotate(
            f"{r['priority']} · {r['issue'][:46]}",
            (jx, jy),
            fontsize=6.6,
            xytext=(8, 0),
            textcoords="offset points",
            va="center",
            color=NAVY,
        )

    ax.set_xticks([1, 2, 3])
    ax.set_xticklabels(["low", "medium", "high"])
    ax.set_yticks([1, 1.5, 2, 2.5, 3])
    ax.set_yticklabels(["low", "low-med", "medium", "med-high", "high"])
    ax.set_xlim(0.55, 3.95)
    ax.set_ylim(0.65, 3.45)
    ax.set_xlabel("implementation effort")
    ax.set_ylabel("expected impact (hypothesis)")
    handles = [plt.Line2D([], [], marker="o", ls="", color=c, label=p) for p, c in colors.items()]
    ax.legend(handles=handles, title="priority", fontsize=7.8, loc="lower right")
    ax.set_title("Recommendations: expected impact vs implementation effort")
    fig.tight_layout()
    return _save(
        fig,
        out / "19_recommendation_matrix.png",
        "Every impact value is a hypothesis stated in results/error_analysis.md; none was validated on the 10 queries.",
    )


# --------------------------------------------------------------------------- #
# 20 extraction quality
# --------------------------------------------------------------------------- #
def fig_extraction_quality(out: Path, quality: pd.DataFrame) -> Path:
    _setup()
    ok = quality[quality["status"] == "ok"].copy()
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.4))
    ax = axes[0]
    for col, color in (("precision", OKABE["blue"]), ("recall", OKABE["orange"]), ("f1", OKABE["green"])):
        if col in ok:
            ax.hist(ok[col].dropna(), bins=16, alpha=0.6, label=col, color=color, edgecolor="white")
    ax.set_xlabel("score")
    ax.set_ylabel("CVs")
    ax.set_title("Extraction vs Excel Skills (silver standard)")
    ax.legend(fontsize=7.5)

    ax = axes[1]
    worst = ok.nsmallest(8, "f1").sort_values("f1")
    ax.barh(worst["doc_id"], worst["f1"], color=OKABE["vermillion"], edgecolor="white")
    for i, v in enumerate(worst["f1"]):
        ax.text(v + 0.01, i, f"{v:.2f}", va="center", fontsize=7.5)
    ax.set_xlim(0, 1.05)
    ax.set_xlabel("F1")
    ax.set_title("Worst 8 pool CVs by F1")
    fig.suptitle(f"Extraction quality on {len(ok)} pool CVs", fontsize=12, color=NAVY)
    fig.tight_layout(rect=[0, 0, 1, 0.93])
    return _save(fig, out / "20_extraction_quality.png")
