"""Overview content shared by the landing page and pages/1_Overview.py."""

from __future__ import annotations

import streamlit as st

from .web import (
    FIGURES,
    PROCESSED,
    caption,
    load_csv,
    load_json,
    metric_card,
    note,
    require,
)


def render() -> None:
    st.title("AI CV Matching — Baseline Results")
    st.markdown(
        "Given a job description, rank the 110 candidate CVs and show the top 10 with a short, reproducible reason. "
        "The pipeline is keyword- and representation-based: local-LLM extraction → keyword clustering → autoencoder "
        "→ cosine retrieval → Recall@10 → error analysis."
    )

    ok = require(
        [PROCESSED / "metrics_summary.csv", PROCESSED / "ground_truth.csv", PROCESSED / "stage0_summary.json"],
        'py "scripts/04_rank_and_evaluate.py" --config "config.yaml"',
    )
    if not ok:
        return

    stage0 = load_json("stage0_summary.json")
    summary = load_csv("metrics_summary.csv")
    gt = load_csv("ground_truth.csv", keep_default_na=False, na_values=[""])

    st.markdown("### Dataset")
    c1, c2, c3, c4, c5 = st.columns(5)
    metric_card(c1, "Pool CVs", f"{stage0['pool_cvs']}", "parsed from data/Anonymised CVs")
    metric_card(c2, "Hired CVs", f"{stage0['gt_cvs']}", "neutral IDs CAND-101…110")
    metric_card(c3, "Labelled JDs", f"{stage0['gt_jds']}", "the only ground truth")
    metric_card(c4, "Unlabelled JDs", f"{stage0['unlabelled_jds']}", "training context only")
    metric_card(c5, "Unique candidates", f"{stage0['unique_candidates']}", f"{stage0['true_duplicates']} true duplicates")

    st.markdown("### Pipeline")
    pipe = FIGURES / "01_pipeline_diagram.png"
    if pipe.is_file():
        st.image(str(pipe), width='stretch')
        caption("Seven stages, each cached and resumable. GT JDs and hired CVs never enter autoencoder training.")
    else:
        st.info('Pipeline diagram not rendered yet — run `py "scripts/06_make_figures.py" --config "config.yaml"`.')

    st.markdown("### Headline metrics — primary model M3 (AE-32 cosine)")
    primary = summary[summary["model"] == "M3"].iloc[0]
    m0 = summary[summary["model"] == "M0"].iloc[0]
    c1, c2, c3, c4, c5 = st.columns(5)
    metric_card(c1, "Recall@10", f"{primary['recall_at_10']:.2f}", f"{int(primary['hits'])}/10 hits")
    metric_card(c2, "Hit@1", f"{primary['hit_at_1']:.2f}", "hired CV ranked first")
    metric_card(c3, "Hit@5", f"{primary['hit_at_5']:.2f}", "within the top 5")
    metric_card(c4, "MRR@10", f"{primary['mrr_at_10']:.3f}", "mean reciprocal rank")
    metric_card(c5, "Random baseline", f"{m0['recall_at_10']:.2f}", "expected 10/110 = 0.09")

    st.markdown("---")
    c1, c2 = st.columns([1.1, 1.0])
    with c1:
        st.markdown("### All models (M0–M6)")
        show = summary[
            ["model", "model_name", "hits", "recall_at_10", "hit_at_1", "hit_at_5", "mrr_at_10", "wilson_ci_low", "wilson_ci_high"]
        ].rename(
            columns={
                "model": "Model",
                "model_name": "Definition",
                "hits": "Hits",
                "recall_at_10": "Recall@10",
                "hit_at_1": "Hit@1",
                "hit_at_5": "Hit@5",
                "mrr_at_10": "MRR@10",
                "wilson_ci_low": "CI low",
                "wilson_ci_high": "CI high",
            }
        )
        st.dataframe(show, hide_index=True, width='stretch')
        caption(
            f"Primary model Recall@10 Wilson 95% CI: [{primary['wilson_ci_low']:.2f}, {primary['wilson_ci_high']:.2f}]. "
            "With 10 queries one hit moves the mean by 0.10."
        )

    with c2:
        st.markdown("### Key findings")
        top = summary.sort_values("recall_at_10", ascending=False)
        best = top.iloc[0]
        st.markdown(
            f"""
- **Best model on these 10 queries:** `{best['model']} {best['model_name']}` at {int(best['hits'])}/10
  (Recall@10 = {best['recall_at_10']:.2f}). The pre-registered primary `M3` reaches {int(primary['hits'])}/10.
- **Must-have coverage is doing real work.** The hybrid M5 combines the AE score with keyword coverage and is
  reported as exploratory — it would need validation on more labelled pairs before adoption.
- **Hard filters are ignored.** Several JDs state location, citizenship or language requirements that the
  baseline never applies, so some top-10 entries are indefensible to a recruiter.
- **Hard lookalikes crowd the top 10.** Role-identical pool CVs win on shared vocabulary even when the hired
  candidate is a better fit on must-have skills.
- **n = 10.** A difference of one or two hits sits inside the confidence interval; no claim of significance is made.
            """
        )

    st.markdown("---")
    st.markdown("### How to use this app")
    st.markdown(
        """
| Page | What it shows |
|---|---|
| **1 · Overview** | Dataset, pipeline, headline metrics (this page) |
| **2 · Keyword merging** | What the LLM extracted, and how raw variants were merged into canonical clusters |
| **3 · Autoencoder** | Architecture, training curves, latent space, and whether the AE separates role families |
| **4 · Search results** | The recruiter view: pick a JD and a model, see the top 10 with the hired CV highlighted |
| **5 · Recall & errors** | Metric cards, per-JD ranks, failure taxonomy, case studies and recommendations |
        """
    )
    note(
        "This is a baseline, not a production system. It deliberately leaves out salary, notice period and hard "
        "location/language filters; those omissions are documented as limitations rather than hidden."
    )

    with st.expander("The 10 labelled JD → hired-CV pairs"):
        st.dataframe(
            gt[["jd_id", "jd_title", "role_family", "hired_cv_id", "hired_cv_title", "hired_cv_company"]].rename(
                columns={
                    "jd_id": "JD",
                    "jd_title": "JD title",
                    "role_family": "Role family",
                    "hired_cv_id": "Hired CV",
                    "hired_cv_title": "CV title",
                    "hired_cv_company": "CV company",
                }
            ),
            hide_index=True,
            width='stretch',
        )
        caption("The hired CVs are not in the 100-CV pool, so they were added as candidates CAND-101…CAND-110.")
