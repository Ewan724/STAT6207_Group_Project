"""Configuration loading and path resolution.

All paths in ``config.yaml`` are relative to the project root (the directory
that contains ``config.yaml``). Nothing in the codebase may hardcode an
absolute path; this module is the only place that turns a relative path into an
absolute one.
"""

from __future__ import annotations

import copy
import hashlib
import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

DEFAULT_CONFIG_NAME = "config.yaml"


def find_project_root(start: Path | None = None) -> Path:
    """Walk upwards from ``start`` until a ``config.yaml`` is found."""
    if start is None:
        start = Path(__file__).resolve().parent
    start = Path(start).resolve()
    for candidate in [start, *start.parents]:
        if (candidate / DEFAULT_CONFIG_NAME).is_file():
            return candidate
    # Fallback: the directory that holds src/
    return Path(__file__).resolve().parent.parent


@dataclass
class Config:
    """Thin wrapper around the parsed YAML with path helpers."""

    raw: dict[str, Any]
    root: Path
    source_path: Path
    overrides: dict[str, Any] = field(default_factory=dict)

    # ------------------------------------------------------------------ paths
    def path(self, key: str) -> Path:
        """Resolve a key under ``paths`` to an absolute Path."""
        rel = self.raw["paths"][key]
        p = Path(rel)
        return p if p.is_absolute() else (self.root / p)

    def ensure_dir(self, key: str) -> Path:
        p = self.path(key)
        p.mkdir(parents=True, exist_ok=True)
        return p

    def ensure_all_dirs(self) -> None:
        for key in (
            "data",
            "processed",
            "cache_llm",
            "models",
            "logs",
            "figures",
            "tables",
            "results",
            "prompts",
        ):
            self.ensure_dir(key)

    # ----------------------------------------------------------------- values
    def get(self, dotted: str, default: Any = None) -> Any:
        node: Any = self.raw
        for part in dotted.split("."):
            if not isinstance(node, dict) or part not in node:
                return default
            node = node[part]
        return node

    @property
    def seed(self) -> int:
        return int(self.raw.get("seed", 42))

    # ------------------------------------------------------------------ files
    def prompt(self, name: str) -> str:
        return (self.path("prompts") / name).read_text(encoding="utf-8")

    def prompt_hash(self) -> str:
        """Stable hash of every prompt template (used to key the LLM cache)."""
        h = hashlib.sha256()
        pdir = self.path("prompts")
        for f in sorted(pdir.glob("*.txt")):
            h.update(f.name.encode())
            h.update(f.read_bytes())
        return h.hexdigest()[:16]

    def config_hash(self) -> str:
        payload = json.dumps(self.raw, sort_keys=True, default=str).encode()
        return hashlib.sha256(payload).hexdigest()[:16]

    def describe(self) -> dict[str, Any]:
        return {
            "root": str(self.root),
            "config": str(self.source_path),
            "config_hash": self.config_hash(),
            "seed": self.seed,
            "llm_model": self.get("llm.model"),
            "overrides": self.overrides,
        }


def _deep_merge(base: dict[str, Any], extra: dict[str, Any]) -> dict[str, Any]:
    out = copy.deepcopy(base)
    for k, v in extra.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def load_config(path: str | os.PathLike[str] | None = None, **overrides: Any) -> Config:
    """Load ``config.yaml`` and apply dotted-path overrides (``llm.model=...``)."""
    if path is None:
        cfg_path = find_project_root() / DEFAULT_CONFIG_NAME
    else:
        cfg_path = Path(path)
        if not cfg_path.is_absolute():
            cfg_path = (Path.cwd() / cfg_path).resolve()
    if not cfg_path.is_file():
        raise FileNotFoundError(f"config file not found: {cfg_path}")

    raw = yaml.safe_load(cfg_path.read_text(encoding="utf-8")) or {}
    applied: dict[str, Any] = {}
    for dotted, value in overrides.items():
        if value is None:
            continue
        parts = dotted.split(".")
        node = raw
        for part in parts[:-1]:
            node = node.setdefault(part, {})
        node[parts[-1]] = value
        applied[dotted] = value

    root = cfg_path.resolve().parent
    cfg = Config(raw=raw, root=root, source_path=cfg_path.resolve(), overrides=applied)
    cfg.ensure_all_dirs()
    return cfg


def add_common_args(parser) -> None:
    """Attach the standard CLI flags every stage script accepts."""
    parser.add_argument("--config", default=None, help="path to config.yaml")
    parser.add_argument("--force", action="store_true", help="ignore caches / overwrite outputs")
    parser.add_argument("--limit", type=int, default=None, help="process only the first N documents")
    parser.add_argument("--model", default=None, help="override the Ollama model name")
    parser.add_argument("--seed", type=int, default=None, help="override the random seed")
    parser.add_argument("--quiet", action="store_true", help="reduce log output")


def config_from_args(args) -> Config:
    overrides: dict[str, Any] = {}
    if getattr(args, "model", None):
        overrides["llm.model"] = args.model
    if getattr(args, "seed", None) is not None:
        overrides["seed"] = args.seed
    return load_config(getattr(args, "config", None), **overrides)


def seed_everything(seed: int) -> None:
    import random

    import numpy as np

    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    try:
        import torch

        torch.manual_seed(seed)
        torch.use_deterministic_algorithms(False)
    except Exception:  # pragma: no cover - torch optional at import time
        pass
