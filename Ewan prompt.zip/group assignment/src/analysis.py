"""Error-analysis helpers: per-query comparison table, failure taxonomy, case studies."""

from __future__ import annotations

import json
from typing import Any

import numpy as np
import pandas as pd

FAILURE_CATEGORIES = {
    "E1": "extraction_missing_skill",
    "E2": "keyword_merge_error",
    "E3": "representation_loss",
    "E4": "hard_negative_lookalike",
    "E5": "seniority_years_mismatch",
    "E6": "domain_industry_mismatch",
    "E7": "location_language_constraint",
    "E8": "label_noise_or_recruiter_context",
    "E9": "duplicate_or_pool_artifact",
    "E10": "other",
}

CATEGORY_DEFINITIONS = {
    "E1": "A must-have skill present in the raw document is missing from the LLM extraction.",
    "E2": "Synonyms were not merged, or distinct skills were incorrectly merged.",
    "E3": "The AE bottleneck loses a discriminative skill; reconstruction is poor.",
    "E4": "A role-similar CV outranks the hired CV; the false positive is a genuine lookalike.",
    "E5": "Years of experience or seniority is the main discriminator and the model ignores it.",
    "E6": "Industry/domain background is the key missing signal.",
    "E7": "A hard location/citizenship/language filter in the JD is not modelled.",
    "E8": "The hired person is not the strongest on paper; hiring used extra context.",
    "E9": "Near-duplicate profiles crowd the top 10, or the candidate pool has an artefact.",
    "E10": "Anything else; explained in the comment.",
}


def per_query_comparison(
    rankings: pd.DataFrame,
    payloads: dict[str, dict],
    meta: dict[str, dict],
    gt: pd.DataFrame,
    coverage: pd.DataFrame,
    keyword_to_cluster: dict[str, int],
    doc_ids: list[str],
    X_dense: np.ndarray,
    models: tuple[str, ...] = ("M1", "M3"),
) -> pd.DataFrame:
    """The per-query error-analysis table for the requested models."""
    pos = {d: i for i, d in enumerate(doc_ids)}
    rows: list[dict[str, Any]] = []
    cov_pivot = coverage.pivot(index="jd_id", columns="cv_id", values="coverage")

    for model in models:
        sub = rankings[rankings["model"] == model]
        for _, g in gt.iterrows():
            jd_id = g["jd_id"]
            hired = g["hired_cv_id"]
            grp = sub[sub["jd_id"] == jd_id].sort_values("rank")
            hired_row = grp[grp["cv_id"] == hired].iloc[0]
            top1 = grp.iloc[0]

            def _cov(cv: str) -> float:
                try:
                    return float(cov_pivot.loc[jd_id, cv])
                except Exception:
                    return float("nan")

            hired_payload = payloads.get(hired, {})
            top1_payload = payloads.get(top1["cv_id"], {})
            jd_payload = payloads.get(jd_id, {})

            from .retrieval import matched_terms_for_cv

            hired_clusters = {int(c) for c in np.nonzero(X_dense[pos[hired]])[0]}
            top1_clusters = {int(c) for c in np.nonzero(X_dense[pos[top1["cv_id"]]])[0]}
            _, missing_hired = matched_terms_for_cv(jd_payload, hired_clusters, keyword_to_cluster)
            _, missing_top1 = matched_terms_for_cv(jd_payload, top1_clusters, keyword_to_cluster)

            years_hired = hired_payload.get("total_years_experience")
            years_top1 = top1_payload.get("total_years_experience")
            years_gap = None
            if isinstance(years_hired, (int, float)) and isinstance(years_top1, (int, float)):
                years_gap = round(float(years_hired) - float(years_top1), 2)

            rank = int(hired_row["rank"])
            category, secondary, comment = classify(
                rank=rank,
                jd_id=jd_id,
                hired=hired,
                jd_payload=jd_payload,
                hired_payload=hired_payload,
                top1_payload=top1_payload,
                top1_id=top1["cv_id"],
                meta=meta,
                missing_hired=missing_hired,
                missing_top1=missing_top1,
                model=model,
            )

            rows.append(
                {
                    "model": model,
                    "jd_id": jd_id,
                    "jd_title": g["jd_title"],
                    "role_family": g["role_family"],
                    "hired_cv_id": hired,
                    "hired_rank": rank,
                    "hired_score": round(float(hired_row["score"]), 6),
                    "top1_cv_id": top1["cv_id"],
                    "top1_title": meta.get(top1["cv_id"], {}).get("title", ""),
                    "top1_score": round(float(top1["score"]), 6),
                    "score_margin": round(float(hired_row["score"]) - float(top1["score"]), 6),
                    "must_have_coverage_hired": round(_cov(hired), 4),
                    "must_have_coverage_top1": round(_cov(top1["cv_id"]), 4),
                    "missing_must_haves_hired": "; ".join(missing_hired[:6]),
                    "missing_must_haves_top1": "; ".join(missing_top1[:6]),
                    "role_family_match_hired": int(meta.get(hired, {}).get("role_family") == g["role_family"]),
                    "role_family_match_top1": int(meta.get(top1["cv_id"], {}).get("role_family") == g["role_family"]),
                    "seniority_match_hired": int(
                        hired_payload.get("seniority") == jd_payload.get("seniority")
                        and jd_payload.get("seniority") not in (None, "unknown")
                    ),
                    "seniority_match_top1": int(
                        top1_payload.get("seniority") == jd_payload.get("seniority")
                        and jd_payload.get("seniority") not in (None, "unknown")
                    ),
                    "years_hired": years_hired,
                    "years_top1": years_top1,
                    "years_gap": years_gap,
                    "primary_failure_category": category,
                    "secondary_failure_category": secondary,
                    "comment": comment,
                }
            )
    return pd.DataFrame(rows)


def classify(
    *,
    rank: int,
    jd_id: str,
    hired: str,
    jd_payload: dict,
    hired_payload: dict,
    top1_payload: dict,
    top1_id: str,
    meta: dict,
    missing_hired: list[str],
    missing_top1: list[str],
    model: str,
) -> tuple[str, str, str]:
    """Assign a primary failure category to a miss, with the evidence that decided it.

    The rules are ordered by how directly the evidence supports the label, and each
    branch records the concrete fact that triggered it so the report is auditable
    rather than hand-waved. A *hit* returns ``("none", "", "hit at rank N")``.
    """
    if rank <= 10:
        return "none", "", f"hit at rank {rank}"

    jd_years = jd_payload.get("min_years_experience")
    years_hired = hired_payload.get("total_years_experience")
    years_top1 = top1_payload.get("total_years_experience")
    jd_sen = jd_payload.get("seniority")
    hired_sen = hired_payload.get("seniority")

    top1_title = str(meta.get(top1_id, {}).get("title", "") or "")
    hired_title = str(hired_payload.get("current_title") or "")
    title_overlap = bool(top1_title) and bool(hired_title) and (
        top1_title.lower() in hired_title.lower() or hired_title.lower() in top1_title.lower()
    )

    jd_domains = {str(d).lower().strip() for d in (jd_payload.get("domain_knowledge") or [])}
    hired_domains = {str(d).lower().strip() for d in (hired_payload.get("domains") or [])}
    domain_disjoint = bool(jd_domains) and bool(hired_domains) and not (jd_domains & hired_domains)

    # --- E7: an explicit hard filter in the JD that the hired CV contradicts -----------
    jd_loc = str(jd_payload.get("location") or "").strip()
    hired_locs = " ".join(str(x) for x in (hired_payload.get("locations") or [])).strip()
    if jd_loc and hired_locs:
        jd_jurisdictions = {c for c in _JURISDICTIONS if c in jd_loc.lower()}
        cv_lower = hired_locs.lower()
        if jd_jurisdictions and not any(c in cv_lower for c in jd_jurisdictions):
            return (
                "E7",
                "E4" if title_overlap else "",
                f"JD is scoped to {sorted(jd_jurisdictions)} but the hired CV lists '{hired_locs}'; "
                "the baseline does not apply location filters",
            )

    # --- E4: a near-identical, role-similar profile outranks the hire -----------------
    if title_overlap and int(rank) > 10:
        return (
            "E4",
            "E5" if isinstance(years_top1, (int, float)) and isinstance(years_hired, (int, float)) and years_top1 > (years_hired or 0) * 1.3 else "E3",
            f"top-1 '{top1_title}' mirrors the hired title '{hired_title}' and shares most of its vocabulary",
        )

    # --- E5: years / seniority is the discriminator the model ignores -----------------
    reasons: list[str] = []
    if isinstance(jd_years, (int, float)) and isinstance(years_hired, (int, float)) and years_hired < float(jd_years):
        reasons.append(f"JD asks {jd_years}y, hired CV has {years_hired}y")
    if (
        isinstance(years_top1, (int, float))
        and isinstance(years_hired, (int, float))
        and years_hired
        and years_top1 >= years_hired * 2.0
    ):
        reasons.append(f"top-1 has {years_top1}y vs hired {years_hired}y")
    if jd_sen and hired_sen and jd_sen != hired_sen and jd_sen != "unknown" and hired_sen != "unknown":
        reasons.append(f"seniority {hired_sen} vs JD {jd_sen}")
    if reasons:
        return "E5", "E1" if len(missing_hired) >= 3 else "", "; ".join(reasons)

    # --- E1: the hired CV simply does not evidence the JD's must-have skills ----------
    if len(missing_hired) >= 4:
        return (
            "E1",
            "E2" if missing_top1 else "",
            f"hired CV is short {len(missing_hired)} must-have clusters: " + ", ".join(missing_hired[:4]),
        )

    # --- E6: domain / industry mismatch ----------------------------------------------
    if domain_disjoint:
        return (
            "E6",
            "",
            f"JD domains {sorted(jd_domains)[:3]} vs hired domains {sorted(hired_domains)[:3]}",
        )

    # --- E3: representation loss (only claimed for the AE) ----------------------------
    if model == "M3":
        return "E3", "", f"ranked {rank}; the 32-d bottleneck does not preserve this JD's discriminative skills"

    return "E10", "", f"ranked {rank}; no single dominant signal in the visible fields"


_JURISDICTIONS = (
    "indonesia",
    "malaysia",
    "singapore",
    "hong kong",
    "thailand",
    "philippines",
    "vietnam",
    "taiwan",
    "china",
    "india",
    "japan",
    "korea",
    "australia",
    "united states",
    "united kingdom",
)


def re_split_tokens(text: str) -> list[str]:
    import re

    return [t.lower() for t in re.split(r"[^A-Za-z]+", text) if t]


def taxonomy_counts(error_df: pd.DataFrame, model: str = "M3") -> pd.DataFrame:
    sub = error_df[(error_df["model"] == model) & (error_df["primary_failure_category"] != "none")]
    counts = sub["primary_failure_category"].value_counts()
    rows = []
    for code, name in FAILURE_CATEGORIES.items():
        rows.append(
            {
                "code": code,
                "category": name,
                "count": int(counts.get(code, 0)),
                "definition": CATEGORY_DEFINITIONS[code],
            }
        )
    return pd.DataFrame(rows)


def ae_vs_tfidf(error_df: pd.DataFrame) -> pd.DataFrame:
    """Compare the hired CV's rank under M1 and M3 for every query."""
    m1 = error_df[error_df["model"] == "M1"].set_index("jd_id")
    m3 = error_df[error_df["model"] == "M3"].set_index("jd_id")
    rows = []
    for jd_id in m1.index:
        r1 = int(m1.loc[jd_id, "hired_rank"])
        r3 = int(m3.loc[jd_id, "hired_rank"])
        delta = r3 - r1
        if delta < 0:
            winner = "AE"
            explanation = f"AE improves the hired CV from rank {r1} to {r3}"
        elif delta > 0:
            winner = "TF-IDF"
            explanation = f"AE degrades the hired CV from rank {r1} to {r3}"
        else:
            winner = "tie"
            explanation = f"Both place the hired CV at rank {r1}"
        rows.append(
            {
                "jd_id": jd_id,
                "jd_title": m1.loc[jd_id, "jd_title"],
                "tfidf_rank": r1,
                "ae_rank": r3,
                "delta": delta,
                "winner": winner,
                "hit_tfidf": int(r1 <= 10),
                "hit_ae": int(r3 <= 10),
                "explanation": explanation,
            }
        )
    return pd.DataFrame(rows)


def case_study_table(rankings: pd.DataFrame, jd_id: str, model: str, payloads, meta, coverage, gt, top_n: int = 10) -> pd.DataFrame:
    grp = rankings[(rankings["model"] == model) & (rankings["jd_id"] == jd_id)].sort_values("rank").head(top_n)
    hired = gt[gt["jd_id"] == jd_id]["hired_cv_id"].iloc[0]
    cov = coverage[coverage["jd_id"] == jd_id].set_index("cv_id")["coverage"]
    rows = []
    for _, r in grp.iterrows():
        cv = r["cv_id"]
        rows.append(
            {
                "rank": int(r["rank"]),
                "cv_id": cv,
                "title": meta.get(cv, {}).get("title", ""),
                "company": payloads.get(cv, {}).get("current_company", ""),
                "role_family": meta.get(cv, {}).get("role_family", ""),
                "score": round(float(r["score"]), 4),
                "must_have_coverage": round(float(cov.get(cv, float("nan"))), 4),
                "is_hired": int(cv == hired),
            }
        )
    return pd.DataFrame(rows)


def case_study_matrix(
    rankings: pd.DataFrame,
    jd_id: str,
    model: str,
    payloads,
    meta,
    keyword_to_cluster: dict[str, int],
    doc_ids: list[str],
    X_dense: np.ndarray,
    top_n: int = 10,
    max_cols: int = 10,
) -> tuple[pd.DataFrame, list[str]]:
    """Rows = top-N CVs, columns = the JD's most discriminating must-have clusters.

    Columns are ordered by how much they separate the top-10 candidates (most
    variable first), so the heatmap shows the skills that actually decide the
    ranking rather than a wall of empty cells.
    """
    from .retrieval import must_have_clusters

    jd_payload = payloads[jd_id]
    clusters = must_have_clusters(jd_payload, keyword_to_cluster)
    inv: dict[int, str] = {}
    for kw, cid in keyword_to_cluster.items():
        inv.setdefault(int(cid), kw)

    if not clusters:
        return pd.DataFrame(), []

    grp = rankings[(rankings["model"] == model) & (rankings["jd_id"] == jd_id)].sort_values("rank").head(top_n)
    pos = {d: i for i, d in enumerate(doc_ids)}
    cv_rows = [r["cv_id"] for _, r in grp.iterrows()]
    data = np.zeros((len(cv_rows), len(clusters)))
    for r_i, cv in enumerate(cv_rows):
        for c_i, c in enumerate(clusters):
            data[r_i, c_i] = float(X_dense[pos[cv], c])

    # rank columns by how discriminating they are in this shortlist
    spread = data.max(axis=0) - data.min(axis=0)
    presence = (data > 0).sum(axis=0)
    order = np.lexsort((presence, spread))[::-1][:max_cols]
    cols = [c for c in order]

    labels = [inv.get(clusters[c], str(clusters[c])) for c in cols]
    row_labels = []
    for _, r in grp.iterrows():
        cv = r["cv_id"]
        prefix = f"HIRED {cv}" if int(r["is_relevant"]) == 1 else f"#{int(r['rank'])} {cv}"
        row_labels.append(prefix)
    return pd.DataFrame(data[:, cols], index=row_labels, columns=labels), labels


def recommendations() -> list[dict[str, str]]:
    return [
        {
            "priority": "P0",
            "issue": "Must-have coverage is not used as the primary scoring signal",
            "evidence": "The hybrid M5 (0.8*AE + 0.2*coverage) is the strongest non-heuristic variant on the 10 queries",
            "proposed_fix": "Use must-have cluster coverage as a hard filter or as the dominant weight in the score",
            "expected_impact": "high for keyword-heavy roles (data, engineering, finance)",
            "effort": "low",
            "owner": "modelling",
        },
        {
            "priority": "P0",
            "issue": "Hard filters (location, citizenship, language) are ignored",
            "evidence": "P02 requires an Indonesian citizen based in Indonesia; P01 covers Malaysia & Thailand only; P07 covers HK & SG",
            "proposed_fix": "Parse location/authorisation/language from the JD and apply as a pre-filter or a penalty",
            "expected_impact": "high; removes candidates a recruiter would never shortlist",
            "effort": "medium",
            "owner": "data engineering",
        },
        {
            "priority": "P0",
            "issue": "Extraction drops or paraphrases must-have skills",
            "evidence": "Extraction F1 against the Excel Skills silver standard is well below 1.0; truncation with '...' hides skills",
            "proposed_fix": "Two-pass extraction with evidence spans; use the larger local model on low-F1 documents",
            "expected_impact": "medium-high; improves every downstream stage",
            "effort": "medium",
            "owner": "extraction",
        },
        {
            "priority": "P1",
            "issue": "Keyword clustering under-merges domain-specific synonyms",
            "evidence": "Finance and field-service vocabulary is sparse in a 150-document corpus, so rare synonyms stay in separate clusters",
            "proposed_fix": "Extend the curated alias dictionary with a domain ontology and review the largest clusters",
            "expected_impact": "medium",
            "effort": "medium",
            "owner": "taxonomy",
        },
        {
            "priority": "P1",
            "issue": "Years of experience and seniority are not in the primary score",
            "evidence": "several JDs state explicit minimum years; the AE is keyword-only",
            "proposed_fix": "Add seniority/years as a gated adjustment (e.g. penalise candidates below the stated minimum)",
            "expected_impact": "medium",
            "effort": "low",
            "owner": "modelling",
        },
        {
            "priority": "P1",
            "issue": "The autoencoder optimises reconstruction, not ranking",
            "evidence": "AE vs TF-IDF ranks differ per query with no consistent winner",
            "proposed_fix": "Add a ranking-aware objective (triplet/contrastive loss) or a cross-encoder re-ranker",
            "expected_impact": "medium-high, but needs more labels to train",
            "effort": "high",
            "owner": "modelling",
        },
        {
            "priority": "P1",
            "issue": "Hard lookalikes crowd the top 10",
            "evidence": "role-identical pool CVs (e.g. the nearest TF-IDF lookalike of each hired CV) score highly on shared vocabulary",
            "proposed_fix": "Weight rare/section-specific clusters higher; add domain and seniority features; deduplicate near-identical profiles",
            "expected_impact": "medium",
            "effort": "medium",
            "owner": "modelling",
        },
        {
            "priority": "P2",
            "issue": "Only 10 labelled pairs; no learning-to-rank is possible",
            "evidence": "one relevant CV per JD, Wilson CI spans a wide band",
            "proposed_fix": "Collect the target ~50 recruiter-approved pairs and move to a supervised ranker",
            "expected_impact": "high in the long run",
            "effort": "high",
            "owner": "product",
        },
        {
            "priority": "P2",
            "issue": "Salary, notice period and availability are out of scope",
            "evidence": "JD headers carry salary bands; the baseline ignores them",
            "proposed_fix": "Model expected salary vs budget once candidate salary expectations exist",
            "expected_impact": "medium for recruiter agreement",
            "effort": "high",
            "owner": "product",
        },
        {
            "priority": "P2",
            "issue": "Reasons are templated and not calibrated",
            "evidence": "reasons list matched/missing skills but no confidence statement",
            "proposed_fix": "Calibrate scores per role family and add a short natural-language justification",
            "expected_impact": "low-medium for recruiter trust",
            "effort": "low",
            "owner": "product",
        },
    ]
