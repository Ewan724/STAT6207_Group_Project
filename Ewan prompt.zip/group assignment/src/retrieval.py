"""Retrieval models M0-M6, must-have coverage, and template-based reasons."""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any

import numpy as np
import pandas as pd
from sklearn.preprocessing import normalize

from .keywords import normalise_keyword

MODEL_NAMES = {
    "M0": "Random",
    "M1": "TF-IDF keyword cosine",
    "M2": "SVD-32 cosine",
    "M3": "AE-32 cosine",
    "M4": "AE + metadata",
    "M5": "Hybrid (AE + must-have)",
    "M6": "Role-family heuristic",
}
PRIMARY_MODEL = "M3"


# --------------------------------------------------------------------------- #
# Must-have coverage
# --------------------------------------------------------------------------- #
def must_have_clusters(payload: dict[str, Any], keyword_to_cluster: dict[str, int]) -> list[int]:
    out: list[int] = []
    seen: set[int] = set()
    for raw in payload.get("must_have_keywords", []) or []:
        norm = normalise_keyword(raw)
        cid = keyword_to_cluster.get(norm)
        if cid is None or cid in seen:
            continue
        seen.add(cid)
        out.append(int(cid))
    return out


def must_have_terms(payload: dict[str, Any], keyword_to_cluster: dict[str, int]) -> list[str]:
    terms: list[str] = []
    seen: set[int] = set()
    for raw in payload.get("must_have_keywords", []) or []:
        norm = normalise_keyword(raw)
        cid = keyword_to_cluster.get(norm)
        if cid is None or cid in seen:
            continue
        seen.add(int(cid))
        terms.append(raw)
    return terms


def coverage_table(
    jd_payloads: dict[str, dict[str, Any]],
    doc_ids: list[str],
    matrix: np.ndarray,
    keyword_to_cluster: dict[str, int],
) -> pd.DataFrame:
    """Fraction of each JD's must-have clusters present in each candidate."""
    rows: list[dict[str, Any]] = []
    for jd_id, payload in jd_payloads.items():
        clusters = must_have_clusters(payload, keyword_to_cluster)
        if not clusters:
            for doc_id in doc_ids:
                rows.append({"jd_id": jd_id, "cv_id": doc_id, "coverage": 0.0, "n_must_have": 0, "n_matched": 0})
            continue
        sub = matrix[:, clusters]
        present = (sub > 0).sum(axis=1)
        cov = present / len(clusters)
        for doc_id, c, n in zip(doc_ids, cov, present):
            rows.append(
                {
                    "jd_id": jd_id,
                    "cv_id": doc_id,
                    "coverage": round(float(c), 6),
                    "n_must_have": len(clusters),
                    "n_matched": int(n),
                }
            )
    return pd.DataFrame(rows)


def matched_terms_for_cv(
    jd_payload: dict[str, Any],
    cv_cluster_ids: set[int],
    keyword_to_cluster: dict[str, int],
) -> tuple[list[str], list[str]]:
    """Split the JD's must-have terms into (matched, missing) for one CV."""
    matched: list[str] = []
    missing: list[str] = []
    seen: set[int] = set()
    for raw in jd_payload.get("must_have_keywords", []) or []:
        norm = normalise_keyword(raw)
        cid = keyword_to_cluster.get(norm)
        if cid is None or cid in seen:
            continue
        seen.add(int(cid))
        if int(cid) in cv_cluster_ids:
            matched.append(raw)
        else:
            missing.append(raw)
    return matched, missing


# --------------------------------------------------------------------------- #
# Ranking helpers
# --------------------------------------------------------------------------- #
def cosine_scores(query: np.ndarray, candidates: np.ndarray) -> np.ndarray:
    q = normalize(query.reshape(1, -1))
    c = normalize(candidates)
    return (c @ q.T).ravel()


def rank_from_scores(scores: np.ndarray, ids: list[str]) -> np.ndarray:
    """Deterministic: score descending (6 dp), then id ascending."""
    order = sorted(range(len(scores)), key=lambda i: (-round(float(scores[i]), 6), ids[i]))
    ranks = np.empty(len(scores), dtype=int)
    for rank, i in enumerate(order, start=1):
        ranks[i] = rank
    return ranks


def build_metadata_vectors(meta_df: pd.DataFrame, doc_ids: list[str], weight: float) -> np.ndarray:
    """Standardise metadata columns and scale by ``weight``."""
    df = meta_df.set_index("doc_id").loc[doc_ids]
    num = df.select_dtypes(include=[np.number]).astype(float)
    std = num.std(axis=0).replace(0, 1.0).fillna(1.0)
    mean = num.mean(axis=0)
    z = (num - mean) / std
    arr = z.to_numpy(dtype=float)
    norms = np.linalg.norm(arr, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    return (arr / norms) * weight


# --------------------------------------------------------------------------- #
# Reasons
# --------------------------------------------------------------------------- #
def make_reason(
    *,
    jd_payload: dict[str, Any],
    cv_payload: dict[str, Any],
    jd_meta: dict[str, Any],
    cv_meta: dict[str, Any],
    matched: list[str],
    missing: list[str],
    rank: int,
    score: float,
    max_chars: int = 300,
) -> str:
    n_total = len(matched) + len(missing)
    role_match = (
        "same role family"
        if jd_meta.get("role_family") == cv_meta.get("role_family")
        else "different role family"
    )
    years = cv_payload.get("total_years_experience")
    years_txt = (
        f"{float(years):.0f} years experience"
        if isinstance(years, (int, float)) and years == years
        else "years unknown"
    )
    jd_sen = jd_payload.get("seniority") or "unknown"
    cv_sen = cv_payload.get("seniority") or "unknown"
    sen_txt = (
        f"seniority match ({jd_sen})"
        if jd_sen == cv_sen and jd_sen != "unknown"
        else f"seniority {cv_sen} vs {jd_sen}"
    )

    top_matched = ", ".join(matched[:6])
    miss_txt = ", ".join(missing[:3])
    head = (
        f"Matches {len(matched)}/{n_total} must-have skills ({top_matched})"
        if n_total and top_matched
        else (f"Matches {len(matched)}/{n_total} must-have skills" if n_total else "No must-have skills extracted")
    )
    parts = [head]
    if miss_txt:
        parts.append(f"missing {miss_txt}")
    parts += [role_match, years_txt, sen_txt, f"rank {rank}, score {score:.3f}"]
    text = "; ".join(parts)
    if len(text) > max_chars:
        text = text[: max_chars - 1].rstrip() + "..."
    return text


def hard_filter_note(jd_payload: dict[str, Any], cv_payload: dict[str, Any], jd_meta: dict[str, Any]) -> str:
    """Flag a visible location/language mismatch; the baseline does not filter."""
    notes: list[str] = []
    jd_loc = (jd_payload.get("location") or jd_meta.get("location") or "") or ""
    cv_locs = [str(x) for x in (cv_payload.get("locations") or [])]
    if jd_loc and cv_locs:
        jd_tokens = {t.lower() for t in re.split(r"[^A-Za-z]+", jd_loc) if len(t) > 2}
        cv_tokens = {t.lower() for t in re.split(r"[^A-Za-z]+", " ".join(cv_locs)) if len(t) > 2}
        if jd_tokens and cv_tokens and not (jd_tokens & cv_tokens):
            notes.append(f"location {cv_locs[0]} vs JD {jd_loc}")
    jd_langs = {str(x).lower() for x in (jd_payload.get("languages") or [])}
    cv_langs = {str(x).lower() for x in (cv_payload.get("languages") or [])}
    if jd_langs and cv_langs and not (jd_langs & cv_langs):
        notes.append("language requirement not evidenced")
    return "; ".join(notes)


# --------------------------------------------------------------------------- #
# Score every model
# --------------------------------------------------------------------------- #
def score_all_models(
    *,
    jd_ids: list[str],
    cv_ids: list[str],
    jd_vectors: dict[str, np.ndarray],
    cv_vectors: dict[str, np.ndarray],
    coverage: pd.DataFrame,
    jd_meta: dict[str, dict[str, Any]],
    cv_meta: dict[str, dict[str, Any]],
    metadata_vectors: np.ndarray | None,
    hybrid_weight: float,
    seed: int,
) -> pd.DataFrame:
    """Return a long dataframe: model, jd_id, cv_id, score."""
    rows: list[dict[str, Any]] = []
    cov_pivot = coverage.pivot(index="jd_id", columns="cv_id", values="coverage")

    for jd_id in jd_ids:
        qn = normalize(jd_vectors[jd_id].reshape(1, -1)).ravel()

        for model in ("M1", "M2", "M3"):
            s = cosine_scores(qn, cv_vectors[model])
            for cv_id, val in zip(cv_ids, s):
                rows.append({"model": model, "jd_id": jd_id, "cv_id": cv_id, "score": round(float(val), 6)})

        rng = np.random.default_rng(seed + int(jd_id[1:]))
        for cv_id, val in zip(cv_ids, rng.random(len(cv_ids))):
            rows.append({"model": "M0", "jd_id": jd_id, "cv_id": cv_id, "score": round(float(val), 6)})

        if metadata_vectors is not None:
            combo = normalize(np.hstack([normalize(cv_vectors["M3"]), metadata_vectors]))
            s = cosine_scores(qn, combo)
            for cv_id, val in zip(cv_ids, s):
                rows.append({"model": "M4", "jd_id": jd_id, "cv_id": cv_id, "score": round(float(val), 6)})

        ae_s = cosine_scores(qn, cv_vectors["M3"])
        cov = cov_pivot.loc[jd_id].reindex(cv_ids).fillna(0.0).to_numpy(dtype=float)
        lo, hi = float(cov.min()), float(cov.max())
        cov_norm = (cov - lo) / (hi - lo) if hi > lo else np.zeros_like(cov)
        hyb = hybrid_weight * ae_s + (1.0 - hybrid_weight) * cov_norm
        for cv_id, val in zip(cv_ids, hyb):
            rows.append({"model": "M5", "jd_id": jd_id, "cv_id": cv_id, "score": round(float(val), 6)})

        jd_family = jd_meta.get(jd_id, {}).get("role_family", "unknown")
        same = np.array([1.0 if cv_meta.get(c, {}).get("role_family") == jd_family else 0.0 for c in cv_ids])
        heur = same * 10.0 + ae_s
        for cv_id, val in zip(cv_ids, heur):
            rows.append({"model": "M6", "jd_id": jd_id, "cv_id": cv_id, "score": round(float(val), 6)})

    return pd.DataFrame(rows)


def add_ranks(df: pd.DataFrame) -> pd.DataFrame:
    """Add a rank column per (model, jd_id); score descending then cv_id ascending."""
    parts = []
    for (_, _), grp in df.groupby(["model", "jd_id"], sort=False):
        g = grp.sort_values(["score", "cv_id"], ascending=[False, True]).copy()
        g["rank"] = np.arange(1, len(g) + 1)
        parts.append(g)
    return pd.concat(parts, ignore_index=True)
