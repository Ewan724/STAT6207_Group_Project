"""Local Ollama client: chat completion, JSON repair, caching, privacy masking.

Only ``http://127.0.0.1:11434`` is ever contacted. There is no code path that
can reach an external provider.
"""

from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import requests

# --------------------------------------------------------------------------- #
# Privacy masking
# --------------------------------------------------------------------------- #
_EMAIL_RE = re.compile(r"[\w.+-]+@[\w-]+\.[\w.-]+")
_PHONE_RE = re.compile(r"(?<!\d)(?:\+?\d[\d\s().-]{7,}\d)(?!\d)")
_URL_RE = re.compile(r"https?://\S+|www\.\S+|(?:linkedin|github)\.com/\S+", re.IGNORECASE)
_POSTCODE_RE = re.compile(r"\b[A-Z]{1,2}\d{1,2}[A-Z]?\s?\d[A-Z]{2}\b")


def mask_pii(text: str) -> tuple[str, dict[str, int]]:
    """Mask obvious PII before any text leaves the process."""
    counts = {"email": 0, "phone": 0, "url": 0, "postcode": 0}

    def _sub(pattern, tag, key):
        nonlocal counts
        out, n = pattern.subn(tag, text)
        counts[key] += n
        return out

    text = _sub(_URL_RE, "[URL]", "url")
    text = _sub(_EMAIL_RE, "[EMAIL]", "email")
    text = _sub(_POSTCODE_RE, "[POSTCODE]", "postcode")
    text = _sub(_PHONE_RE, "[PHONE]", "phone")
    return text, counts


# --------------------------------------------------------------------------- #
# JSON handling
# --------------------------------------------------------------------------- #
_FENCE_RE = re.compile(r"^```(?:json)?\s*|\s*```$", re.IGNORECASE | re.MULTILINE)


def strip_fences(text: str) -> str:
    text = text.strip()
    if text.startswith("```"):
        text = _FENCE_RE.sub("", text).strip()
    return text


def parse_json_loose(text: str) -> dict[str, Any]:
    """Parse the first JSON object found in ``text``."""
    cleaned = strip_fences(text)
    try:
        obj = json.loads(cleaned, strict=False)
        if isinstance(obj, dict):
            return obj
        if isinstance(obj, list) and obj and isinstance(obj[0], dict):
            return obj[0]
    except json.JSONDecodeError:
        pass
    # fall back: find the outermost {...}
    start = cleaned.find("{")
    end = cleaned.rfind("}")
    if start >= 0 and end > start:
        snippet = cleaned[start : end + 1]
        try:
            return json.loads(snippet, strict=False)
        except json.JSONDecodeError:
            snippet = re.sub(r",\s*([}\]])", r"\1", snippet)
            try:
                return json.loads(snippet, strict=False)
            except json.JSONDecodeError as exc:
                raise ValueError(f"unparsable JSON: {exc}") from exc
    raise ValueError("no JSON object in response")


def prompt_hash(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


# --------------------------------------------------------------------------- #
# Client
# --------------------------------------------------------------------------- #
@dataclass
class LLMResponse:
    content: str
    model: str
    elapsed_sec: float
    raw: dict[str, Any] = field(default_factory=dict)
    prompt_eval_count: int | None = None
    eval_count: int | None = None


class OllamaClient:
    def __init__(
        self,
        base_url: str = "http://127.0.0.1:11434",
        model: str = "qwen3:8b",
        temperature: float = 0.0,
        top_p: float = 1.0,
        num_ctx: int = 8192,
        num_predict: int = 1600,
        seed: int = 42,
        timeout: int = 300,
        max_retries: int = 2,
        json_mode: bool = True,
        think: bool = False,
        log=None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.model = model
        self.temperature = temperature
        self.top_p = top_p
        self.num_ctx = num_ctx
        self.num_predict = num_predict
        self.seed = seed
        self.timeout = timeout
        self.max_retries = max_retries
        self.json_mode = json_mode
        self.think = think
        self.log = log

    # ---------------------------------------------------------------- health
    def ping(self, timeout: int = 10) -> dict[str, Any]:
        r = requests.get(f"{self.base_url}/api/tags", timeout=timeout)
        r.raise_for_status()
        return r.json()

    def has_model(self, name: str) -> bool:
        try:
            tags = self.ping()
        except Exception:
            return False
        names = {m.get("name") or m.get("model") for m in tags.get("models", [])}
        return any(n and (n == name or n.split(":")[0] == name.split(":")[0]) for n in names)

    # ------------------------------------------------------------------ chat
    def chat(
        self,
        system: str,
        user: str,
        *,
        model: str | None = None,
        num_predict: int | None = None,
        timeout: int | None = None,
    ) -> LLMResponse:
        payload: dict[str, Any] = {
            "model": model or self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "stream": False,
            "options": {
                "temperature": self.temperature,
                "seed": self.seed,
                "num_ctx": self.num_ctx,
                "num_predict": num_predict or self.num_predict,
                "top_p": self.top_p,
            },
        }
        if self.json_mode:
            payload["format"] = "json"
        # qwen3 is a reasoning model: without this it emits chain-of-thought text
        # instead of the JSON object, which breaks structured extraction.
        payload["think"] = False

        last_error: Exception | None = None
        for attempt in range(self.max_retries + 1):
            t0 = time.time()
            try:
                r = requests.post(
                    f"{self.base_url}/api/chat",
                    json=payload,
                    timeout=timeout or self.timeout,
                )
                r.raise_for_status()
                data = r.json()
                elapsed = time.time() - t0
                message = data.get("message", {})
                content = message.get("content", "") or ""
                if not content and message.get("thinking"):
                    content = message.get("thinking", "")
                return LLMResponse(
                    content=content,
                    model=payload["model"],
                    elapsed_sec=elapsed,
                    raw=data,
                    prompt_eval_count=data.get("prompt_eval_count"),
                    eval_count=data.get("eval_count"),
                )
            except Exception as exc:  # noqa: BLE001 - retry everything once
                last_error = exc
                if self.log:
                    self.log.warning("LLM call failed (attempt %d/%d): %s", attempt + 1, self.max_retries + 1, exc)
                time.sleep(min(2 ** attempt, 5))
        raise RuntimeError(f"LLM call failed after {self.max_retries + 1} attempts: {last_error}")


# --------------------------------------------------------------------------- #
# Disk cache
# --------------------------------------------------------------------------- #
class LLMCache:
    """One JSON file per document, keyed by doc_id, validated by prompt hash."""

    def __init__(self, cache_dir: Path, log=None) -> None:
        self.dir = Path(cache_dir)
        self.dir.mkdir(parents=True, exist_ok=True)
        self.log = log

    def path_for(self, doc_id: str) -> Path:
        safe = re.sub(r"[^A-Za-z0-9_.-]", "_", doc_id)
        return self.dir / f"{safe}.json"

    def load(self, doc_id: str, phash: str) -> dict[str, Any] | None:
        p = self.path_for(doc_id)
        if not p.is_file():
            return None
        try:
            payload = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return None
        if payload.get("prompt_hash") != phash:
            if self.log:
                self.log.info("cache invalidated by prompt change: %s", doc_id)
            return None
        return payload

    def save(self, doc_id: str, payload: dict[str, Any]) -> Path:
        p = self.path_for(doc_id)
        p.write_text(json.dumps(payload, ensure_ascii=False, indent=1), encoding="utf-8")
        return p

    def __len__(self) -> int:
        return len(list(self.dir.glob("*.json")))
