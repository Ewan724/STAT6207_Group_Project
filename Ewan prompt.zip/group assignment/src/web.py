"""Shared helpers for the Streamlit multipage app: paths, loading, styling."""

from __future__ import annotations

import json
from pathlib import Path

import pandas as pd
import streamlit as st
import yaml

def _find_root() -> Path:
    """Locate the project root (the directory that contains ``config.yaml``)."""
    here = Path(__file__).resolve().parent
    for candidate in [here, *here.parents]:
        if (candidate / "config.yaml").is_file():
            return candidate
    return here.parent


ROOT = _find_root()
CONFIG_PATH = ROOT / "config.yaml"

PALETTE = {
    "navy": "#0B2545",
    "teal": "#0F7B6C",
    "coral": "#C1292E",
    "grey": "#6B7280",
    "hit": "#009E73",
    "miss": "#D55E00",
    "neutral": "#999999",
    "sky": "#56B4E9",
    "blue": "#0072B2",
    "orange": "#E69F00",
}

OKABE_SEQUENCE = ["#0072B2", "#E69F00", "#009E73", "#56B4E9", "#CC79A7", "#D55E00", "#F0E442", "#999999"]


def load_config() -> dict:
    with open(CONFIG_PATH, encoding="utf-8") as fh:
        return yaml.safe_load(fh)


CFG = load_config()
P = CFG["paths"]
PROCESSED = ROOT / P["processed"]
FIGURES = ROOT / P["figures"]
TABLES = ROOT / P["tables"]
MODELS = ROOT / P["models"]
RESULTS = ROOT / P["results"]
CACHE = ROOT / P["cache_llm"]


def apply_style() -> None:
    st.markdown(
        """
<style>
  .block-container {padding-top: 2.2rem; padding-bottom: 2rem; max-width: 1400px;}
  h1, h2, h3 {color: #0B2545; letter-spacing: -0.01em;}
  h1 {font-size: 1.85rem;}
  h2 {font-size: 1.32rem; margin-top: 1.1rem;}
  h3 {font-size: 1.06rem;}
  .metric-card {background:#F7F9FC;border:1px solid #DCE4EE;border-radius:10px;padding:12px 16px;}
  .metric-card .label {font-size:0.74rem;color:#5A6B82;text-transform:uppercase;letter-spacing:0.05em;}
  .metric-card .value {font-size:1.5rem;color:#0B2545;font-weight:700;line-height:1.25;}
  .metric-card .sub {font-size:0.75rem;color:#6B7280;}
  .badge {display:inline-block;padding:1px 8px;border-radius:999px;font-size:0.72rem;font-weight:600;}
  .badge-hit {background:#DFF3EE;color:#0F7B6C;}
  .badge-miss {background:#FBE9E7;color:#C1292E;}
  .badge-hired {background:#0B2545;color:#FFFFFF;}
  .badge-neutral {background:#EEF2F6;color:#475569;}
  .note {background:#F7F9FC;border-left:3px solid #0F7B6C;padding:8px 14px;font-size:0.85rem;color:#334155;}
  .warn {background:#FFF8E6;border-left:3px solid #E69F00;padding:8px 14px;font-size:0.85rem;color:#5C4400;}
  .caption {font-size:0.78rem;color:#6B7280;margin-top:-0.3rem;}
  footer {visibility:hidden;}
  div[data-testid="stDataFrame"] {font-size:0.83rem;}
</style>
""",
        unsafe_allow_html=True,
    )


def require(paths: list[Path], stage_hint: str) -> bool:
    """Show a friendly message instead of a traceback when artifacts are missing."""
    missing = [p for p in paths if not p.is_file()]
    if missing:
        st.error(
            "Missing required artifact(s):\n\n"
            + "\n".join(f"- `{m.relative_to(ROOT)}`" for m in missing)
            + f"\n\nRun: `{stage_hint}`"
        )
        return False
    return True


def metric_card(col, label: str, value: str, sub: str = "") -> None:
    col.markdown(
        f'<div class="metric-card"><div class="label">{label}</div>'
        f'<div class="value">{value}</div><div class="sub">{sub}</div></div>',
        unsafe_allow_html=True,
    )


def caption(text: str) -> None:
    st.markdown(f'<div class="caption">{text}</div>', unsafe_allow_html=True)


def note(text: str) -> None:
    st.markdown(f'<div class="note">{text}</div>', unsafe_allow_html=True)


def warn(text: str) -> None:
    st.markdown(f'<div class="warn">{text}</div>', unsafe_allow_html=True)


def badge(hit: bool, text: str | None = None) -> str:
    cls = "badge-hit" if hit else "badge-miss"
    return f'<span class="badge {cls}">{text or ("HIT" if hit else "MISS")}</span>'


@st.cache_data(show_spinner=False)
def read_csv_cached(path: str, **kwargs) -> pd.DataFrame:
    return pd.read_csv(path, **kwargs)


def load_csv(name: str, subdir: str = "processed", **kwargs) -> pd.DataFrame:
    base = {"processed": PROCESSED, "tables": TABLES}[subdir]
    return read_csv_cached(str(base / name), **kwargs)


@st.cache_data(show_spinner=False)
def load_json_cached(path: str) -> dict:
    with open(path, encoding="utf-8") as fh:
        return json.load(fh)


def load_json(name: str, subdir: str = "processed") -> dict:
    base = {"processed": PROCESSED, "models": MODELS, "results": RESULTS}[subdir]
    return load_json_cached(str(base / name))


@st.cache_data(show_spinner=False)
def load_jsonl_cached(path: str) -> list[dict]:
    rows = []
    with open(path, encoding="utf-8") as fh:
        for line in fh:
            line = line.strip()
            if line:
                rows.append(json.loads(line))
    return rows


def load_extracted() -> dict[str, dict]:
    """doc_id -> extraction record."""
    out: dict[str, dict] = {}
    for name in ("jd_extracted.jsonl", "cv_extracted.jsonl"):
        for row in load_jsonl_cached(str(PROCESSED / name)):
            out[row["doc_id"]] = row
    return out


def sidebar() -> None:
    with st.sidebar:
        st.markdown("### AI CV Matching\n**Baseline results**")
        st.markdown(
            "<div style='font-size:0.8rem;color:#475569'>Second Talent · STAT6207 group assignment<br>"
            "Keyword + representation baseline, local LLM only.</div>",
            unsafe_allow_html=True,
        )
        st.divider()
        st.markdown("**Data summary**")
        st.markdown(
            "- 100 pool CVs\n- 10 hired CVs (`CAND-101`…`CAND-110`)\n"
            "- 10 labelled JDs (`P01`…`P10`)\n- 50 unlabelled JDs\n- **110 unique candidates**"
        )
        st.divider()
        st.markdown("**Model**")
        st.markdown(
            f"- Ollama `{CFG['llm']['model']}` (local, no external API)\n"
            f"- Keyword clusters: see Autoencoder page\n"
            f"- Seed `{CFG['seed']}`"
        )
        with st.expander("Metric definitions"):
            st.markdown(
                "**Recall@10** = (# relevant CVs in the top 10) / (# relevant CVs). "
                "With exactly one relevant CV per JD this is 1 if the hired CV is in the top 10, else 0. "
                "Mean Recall@10 = hits / 10 (a **hit rate**, not a proportion of the top 10).\n\n"
                "**Precision@10** = (# relevant in the top 10) / 10, maximum 0.1 here. "
                "It is **not** recall.\n\n"
                "**Hit@1 / Hit@5** = fraction of queries whose hired CV is within the top 1 / 5.\n\n"
                "**MRR@10** = mean of 1/rank for hits in the top 10.\n\n"
                "**nDCG@10** = mean of 1/log2(rank+1) for hits in the top 10 (binary, one relevant item)."
            )
        with st.expander("Privacy"):
            st.markdown(
                "All source documents are pre-anonymised by the dataset provider. "
                "Email addresses, phone numbers, URLs and postal codes are regex-masked before any text "
                "reaches the local model. Only `http://127.0.0.1:11434` is contacted; there are no external "
                "API calls, no scraping, and no data uploads."
            )
        st.divider()
        st.caption("Reproducibility")
        try:
            summary = load_json("extraction_summary.json")
            st.caption(f"model `{summary.get('model')}` · prompt `{summary.get('prompt_hash')}`")
        except Exception:  # noqa: BLE001
            st.caption("run stage 1 to populate metadata")
        try:
            ae = load_json("autoencoder_config.json", "models")
            st.caption(f"AE {ae.get('architecture')} · best epoch {ae.get('best_epoch')}")
        except Exception:  # noqa: BLE001
            st.caption("run stage 3 to populate metadata")


def footer() -> None:
    st.divider()
    st.markdown(
        "<div style='font-size:0.72rem;color:#6B7280'>"
        "Data: anonymised Second Talent sample (100 pool CVs, 10 hired CVs, 10 labelled JDs, 50 unlabelled JDs). "
        "Extraction: local Ollama model only. This baseline does not model salary, notice period, or hard "
        "location/language filters. Recall@10 is a hit rate with n = 10; no statistical significance is claimed."
        "</div>",
        unsafe_allow_html=True,
    )
