"""Document x keyword-cluster matrix, PyTorch autoencoder, and baselines.

The AE is trained only on the training corpus (pool CVs + unlabelled JDs). The
10 GT JDs and 10 hired CVs are encoded after the model is frozen.
"""

from __future__ import annotations

import json
import math
import random
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import scipy.sparse as sp
from sklearn.decomposition import PCA, TruncatedSVD
from sklearn.preprocessing import normalize

try:
    import torch
    import torch.nn as nn
    from torch.utils.data import DataLoader, TensorDataset

    TORCH_AVAILABLE = True
except Exception:  # pragma: no cover
    torch = None  # type: ignore
    nn = None  # type: ignore
    TORCH_AVAILABLE = False

# Section-aware weights from the prompt
FIELD_WEIGHTS = {
    # JD
    "must_have_keywords": 3.0,
    "nice_to_have_keywords": 1.0,
    "tools_technologies": 2.0,
    "domain_knowledge": 1.5,
    "key_responsibilities": 0.5,
    # CV
    "skills": 2.0,
    "domains": 1.5,
    "soft_skills": 0.5,
    "certifications": 0.5,
    "education_requirements": 0.5,
}

SENIORITY_LEVELS = ["intern", "junior", "mid", "senior", "lead", "director", "executive", "unknown"]
REMOTE_LEVELS = ["yes", "no", "hybrid", "unknown"]


# --------------------------------------------------------------------------- #
# Matrix construction
# --------------------------------------------------------------------------- #
def build_document_matrix(
    extracted: dict[str, dict[str, Any]],
    docs_meta: dict[str, dict[str, Any]],
    keyword_to_cluster: dict[str, int],
    n_clusters: int,
) -> tuple[sp.csr_matrix, list[str], pd.DataFrame]:
    """Weighted, log1p-damped, TF-IDF document x cluster matrix."""
    from .keywords import normalise_keyword

    doc_ids = list(docs_meta.keys())
    rows, cols, vals = [], [], []
    unmatched: dict[str, list[str]] = {}

    for r, doc_id in enumerate(doc_ids):
        payload = extracted.get(doc_id, {})
        acc: dict[int, float] = {}
        misses: list[str] = []
        for field_name, weight in FIELD_WEIGHTS.items():
            values = payload.get(field_name)
            if not isinstance(values, list):
                continue
            for raw in values:
                norm = normalise_keyword(raw)
                if not norm:
                    continue
                cid = keyword_to_cluster.get(norm)
                if cid is None:
                    misses.append(norm)
                    continue
                acc[int(cid)] = acc.get(int(cid), 0.0) + float(weight)
        if misses:
            unmatched[doc_id] = misses
        for cid, w in acc.items():
            rows.append(r)
            cols.append(cid)
            vals.append(math.log1p(w))

    X = sp.csr_matrix((vals, (rows, cols)), shape=(len(doc_ids), n_clusters), dtype=np.float64)
    from sklearn.feature_extraction.text import TfidfTransformer

    tfidf = TfidfTransformer(sublinear_tf=True, norm="l2")
    X = tfidf.fit_transform(X)

    index = pd.DataFrame(
        {
            "row": range(len(doc_ids)),
            "doc_id": doc_ids,
            "doc_type": [docs_meta[d]["doc_type"] for d in doc_ids],
            "split": [docs_meta[d].get("split", "train") for d in doc_ids],
            "title": [docs_meta[d].get("title", "") for d in doc_ids],
            "role_family": [docs_meta[d].get("role_family", "unknown") for d in doc_ids],
            "n_unmatched_keywords": [len(unmatched.get(d, [])) for d in doc_ids],
        }
    )
    return X.tocsr(), doc_ids, index


def build_metadata_matrix(
    extracted: dict[str, dict[str, Any]],
    docs_meta: dict[str, dict[str, Any]],
    doc_ids: list[str],
    role_families: list[str],
    countries: list[str],
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for doc_id in doc_ids:
        payload = extracted.get(doc_id, {})
        meta = docs_meta.get(doc_id, {})
        row: dict[str, Any] = {"doc_id": doc_id}

        seniority = (payload.get("seniority") or "unknown")
        seniority = seniority if seniority in SENIORITY_LEVELS else "unknown"
        for lvl in SENIORITY_LEVELS:
            row[f"sen_{lvl}"] = 1.0 if seniority == lvl else 0.0

        rf = meta.get("role_family") or payload.get("role_family") or "unknown"
        rf = rf if rf in role_families else "unknown"
        for fam in role_families:
            row[f"rf_{fam}"] = 1.0 if rf == fam else 0.0

        years = payload.get("total_years_experience")
        if isinstance(years, (int, float)) and years == years:
            row["years_scaled"] = float(np.clip(years, 0, 30) / 30.0)
            row["years_unknown"] = 0.0
        else:
            row["years_scaled"] = 0.0
            row["years_unknown"] = 1.0

        country = meta.get("country") or (payload.get("locations") or ["unknown"])[0]
        country = str(country) if country else "unknown"
        country = country if country in countries else "other"
        for c in countries + ["other", "unknown"]:
            row[f"cty_{c}"] = 1.0 if country == c else 0.0

        remote = payload.get("remote") or "unknown"
        remote = remote if remote in REMOTE_LEVELS else "unknown"
        for r in REMOTE_LEVELS:
            row[f"rem_{r}"] = 1.0 if remote == r else 0.0

        rows.append(row)
    df = pd.DataFrame(rows)
    # dedupe duplicated columns created when a country is named "other"/"unknown"
    df = df.loc[:, ~df.columns.duplicated()]
    return df


# --------------------------------------------------------------------------- #
# Model
# --------------------------------------------------------------------------- #
if TORCH_AVAILABLE:

    class Autoencoder(nn.Module):
        def __init__(self, input_dim: int, hidden: list[int], latent_dim: int, dropout: float) -> None:
            super().__init__()
            self.input_dim = input_dim
            self.hidden = hidden
            self.latent_dim = latent_dim
            self.dropout_p = dropout

            enc: list[nn.Module] = []
            prev = input_dim
            for h in hidden:
                enc += [nn.Linear(prev, h), nn.GELU(), nn.Dropout(dropout)]
                prev = h
            enc += [nn.Linear(prev, latent_dim)]
            self.encoder = nn.Sequential(*enc)

            dec: list[nn.Module] = []
            prev = latent_dim
            for h in reversed(hidden):
                dec += [nn.Linear(prev, h), nn.GELU(), nn.Dropout(dropout)]
                prev = h
            dec += [nn.Linear(prev, input_dim)]
            self.decoder = nn.Sequential(*dec)

        def forward(self, x):
            z = self.encoder(x)
            return self.decoder(z), z

        def encode(self, x):
            return self.encoder(x)

        def architecture(self) -> list[int]:
            return [self.input_dim, *self.hidden, self.latent_dim, *reversed(self.hidden), self.input_dim]


def reconstruction_loss(recon, target, *, cosine_weight: float = 1.0, mse_weight: float = 1.0):
    """Composite reconstruction objective.

    Plain MSE on L2-normalised sparse TF-IDF rows is minimised by predicting the
    mean row, which collapses the bottleneck (every document maps to the same
    latent point). The cosine term forces the reconstruction to keep the row's
    *direction*, which is what retrieval actually uses, and the MSE term keeps the
    magnitudes honest.
    """
    mse = torch.mean((recon - target) ** 2)
    cos = torch.nn.functional.cosine_similarity(recon, target, dim=1, eps=1e-8)
    return mse_weight * mse + cosine_weight * torch.mean(1.0 - cos)


def _dense(matrix: sp.csr_matrix) -> np.ndarray:
    arr = matrix.toarray() if sp.issparse(matrix) else np.asarray(matrix)
    return np.asarray(arr, dtype=np.float32)


@dataclass
class AEResult:
    model: Any
    history: pd.DataFrame
    best_epoch: int
    best_val_mse: float
    train_mse: float
    val_mse: float
    latent_dim: int
    dropout: float
    denoising: bool
    architecture: list[int]
    n_train: int
    n_val: int
    nan_seen: bool
    config: dict[str, Any] = field(default_factory=dict)


def train_autoencoder(
    X_train: np.ndarray,
    X_val: np.ndarray,
    *,
    hidden: list[int],
    latent_dim: int,
    dropout: float,
    denoising: bool,
    denoise_rate: float,
    lr: float,
    weight_decay: float,
    batch_size: int,
    max_epochs: int,
    patience: int,
    grad_clip: float,
    seed: int,
    log=None,
) -> AEResult:
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)

    input_dim = X_train.shape[1]
    model = Autoencoder(input_dim, hidden, latent_dim, dropout)
    optim = torch.optim.Adam(model.parameters(), lr=lr, weight_decay=weight_decay)

    train_t = torch.from_numpy(X_train)
    val_t = torch.from_numpy(X_val)
    loader = DataLoader(TensorDataset(train_t), batch_size=batch_size, shuffle=True, drop_last=False)

    best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
    best_val = float("inf")
    best_epoch = 0
    history: list[dict[str, Any]] = []
    nan_seen = False
    no_improve = 0

    for epoch in range(1, max_epochs + 1):
        model.train()
        total, count = 0.0, 0
        for (batch,) in loader:
            if denoising:
                mask = (torch.rand_like(batch) < denoise_rate) & (batch > 0)
                noisy = batch.clone()
                noisy[mask] = 0.0
                inp = noisy
            else:
                inp = batch
            recon, _ = model(inp)
            loss = reconstruction_loss(recon, batch)
            optim.zero_grad()
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), grad_clip)
            optim.step()
            if torch.isnan(loss):
                nan_seen = True
                break
            total += float(loss.item()) * batch.shape[0]
            count += batch.shape[0]

        model.eval()
        with torch.no_grad():
            recon_val, _ = model(val_t)
            val_loss = float(reconstruction_loss(recon_val, val_t).item())
            val_mse = float(torch.mean((recon_val - val_t) ** 2).item())
            recon_tr, _ = model(train_t)
            train_loss = float(reconstruction_loss(recon_tr, train_t).item())
            train_mse = float(torch.mean((recon_tr - train_t) ** 2).item())
        if math.isnan(val_loss) or math.isnan(train_loss):
            nan_seen = True
            break

        history.append(
            {
                "epoch": epoch,
                "train_loss": train_loss,
                "val_loss": val_loss,
                "train_mse": train_mse,
                "val_mse": val_mse,
            }
        )
        if val_loss < best_val - 1e-9:
            best_val = val_loss
            best_epoch = epoch
            best_state = {k: v.detach().clone() for k, v in model.state_dict().items()}
            no_improve = 0
        else:
            no_improve += 1
            if no_improve >= patience:
                if log:
                    log.info("early stopping at epoch %d (best %d)", epoch, best_epoch)
                break

    model.load_state_dict(best_state)
    model.eval()
    with torch.no_grad():
        recon_val, _ = model(val_t)
        val_mse = float(torch.mean((recon_val - val_t) ** 2).item())
        recon_tr, _ = model(train_t)
        train_mse = float(torch.mean((recon_tr - train_t) ** 2).item())

    return AEResult(
        model=model,
        history=pd.DataFrame(history),
        best_epoch=best_epoch,
        best_val_mse=val_mse,
        train_mse=train_mse,
        val_mse=val_mse,
        latent_dim=latent_dim,
        dropout=dropout,
        denoising=denoising,
        architecture=model.architecture(),
        n_train=int(X_train.shape[0]),
        n_val=int(X_val.shape[0]),
        nan_seen=nan_seen,
        config={
            "hidden": hidden,
            "latent_dim": latent_dim,
            "dropout": dropout,
            "denoising": denoising,
            "denoise_rate": denoise_rate if denoising else 0.0,
            "lr": lr,
            "weight_decay": weight_decay,
            "batch_size": batch_size,
            "max_epochs": max_epochs,
            "patience": patience,
            "grad_clip": grad_clip,
            "seed": seed,
            "input_dim": input_dim,
        },
    )


def encode(model, X: np.ndarray) -> np.ndarray:
    model.eval()
    with torch.no_grad():
        z = model.encode(torch.from_numpy(X)).numpy()
    return normalize(z)


def reconstruct(model, X: np.ndarray) -> np.ndarray:
    model.eval()
    with torch.no_grad():
        out, _ = model(torch.from_numpy(X))
    return out.numpy()


def per_document_mse(model, X: np.ndarray) -> np.ndarray:
    rec = reconstruct(model, X)
    return ((rec - X) ** 2).mean(axis=1)


def split_train_val(X: sp.csr_matrix, doc_types: list[str], val_fraction: float, seed: int):
    rng = np.random.default_rng(seed)
    idx_by_type: dict[str, list[int]] = {}
    for i, t in enumerate(doc_types):
        idx_by_type.setdefault(t, []).append(i)
    train_idx: list[int] = []
    val_idx: list[int] = []
    for t, idxs in idx_by_type.items():
        idxs = list(idxs)
        rng.shuffle(idxs)
        n_val = max(1, int(round(len(idxs) * val_fraction))) if len(idxs) > 3 else 0
        val_idx.extend(idxs[:n_val])
        train_idx.extend(idxs[n_val:])
    if not val_idx:  # degenerate corpus
        val_idx = train_idx[-max(1, len(train_idx) // 5) :]
        train_idx = [i for i in train_idx if i not in set(val_idx)]
    return sorted(train_idx), sorted(val_idx)


# --------------------------------------------------------------------------- #
# SVD / PCA baselines
# --------------------------------------------------------------------------- #
def svd_baseline(X_train: np.ndarray, X_all: np.ndarray, n_components: int, seed: int = 42):
    svd = TruncatedSVD(n_components=n_components, random_state=seed)
    svd.fit(X_train)
    Z = svd.transform(X_all)
    rec = svd.inverse_transform(Z)
    return normalize(Z), rec, svd


def pca_baseline(X_train: np.ndarray, X_all: np.ndarray, n_components: int, seed: int = 42):
    pca = PCA(n_components=n_components, random_state=seed)
    pca.fit(X_train)
    Z = pca.transform(X_all)
    rec = pca.inverse_transform(Z)
    return normalize(Z), rec, pca


def cosine_reconstruction(x: np.ndarray, rec: np.ndarray) -> float:
    num = float(np.dot(x, rec))
    den = float(np.linalg.norm(x) * np.linalg.norm(rec))
    return num / den if den else 0.0


def dead_unit_report(Z: np.ndarray) -> dict[str, Any]:
    stds = Z.std(axis=0)
    return {
        "latent_dims": int(Z.shape[1]),
        "dead_units": int((stds < 1e-6).sum()),
        "min_std": float(stds.min()) if len(stds) else 0.0,
        "max_std": float(stds.max()) if len(stds) else 0.0,
        "mean_abs_latent": float(np.abs(Z).mean()),
    }
