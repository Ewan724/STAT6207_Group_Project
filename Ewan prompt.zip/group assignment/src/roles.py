"""Role-family resolution.

The candidate pool CVs carry a role-family label in the Excel metadata, and the
JD headers carry one too. Those are legitimate metadata *for the document they
describe* — but copying a JD's role family onto the CV that was hired for that JD
would leak the label into a candidate feature.

So the rule is:

* **pool CVs** — use the LLM's inference from the CV text, mapped onto the eight
  Excel families plus ``Product``. Fall back to the Excel role family, which
  describes the CV itself (never a JD), so it is not leakage.
* **hired CVs (``CAND-*``)** — use **only** the LLM's inference from the CV text.
  There is no Excel row for these documents, and the JD header family is
  deliberately ignored.
* **JDs** — use the job title / role-family line from the document itself.
"""

from __future__ import annotations

from typing import Any

EXCEL_FAMILIES = [
    "Finance & Legal",
    "Sales & BD",
    "Marketing",
    "Data & AI",
    "Product",
    "Engineering",
    "Design & Creative",
    "Operations & HR",
    "Leadership",
]

# LLM outputs a free-form family; map it onto the controlled vocabulary.
_ALIASES: list[tuple[str, tuple[str, ...]]] = [
    ("Finance & Legal", ("finance", "legal", "accounting", "audit", "risk", "compliance", "tax")),
    ("Sales & BD", ("sales", "business development", "bd", "commercial", "partnership", "account management")),
    ("Marketing", ("marketing", "growth", "brand", "content", "communications", "demand generation", "seo")),
    ("Data & AI", ("data", "ai", "machine learning", "analytics", "ml", "science", "artificial")),
    ("Product", ("product",)),
    ("Engineering", ("engineer", "software", "developer", "devops", "sre", "infrastructure", "technical", "qa")),
    ("Design & Creative", ("design", "creative", "ux", "ui", "art")),
    ("Operations & HR", ("operations", "hr", "human resources", "recruit", "people", "supply chain", "logistics", "admin")),
    ("Leadership", ("leadership", "general manager", "executive", "chief")),
]


def map_role_family(raw: Any, fallback: str = "unknown") -> str:
    """Map a free-form role family onto the controlled vocabulary."""
    if raw is None:
        return fallback
    s = str(raw).strip()
    if not s:
        return fallback
    if s in EXCEL_FAMILIES:
        return s
    low = s.lower()
    # exact-ish alias match first
    for canonical, keys in _ALIASES:
        if low == canonical.lower():
            return canonical
    for canonical, keys in _ALIASES:
        if canonical == "Product" and "product" in low and "productivity" not in low:
            return canonical
    # keyword scoring; the earliest keyword in the list wins ties
    best, best_score = fallback, 0
    for canonical, keys in _ALIASES:
        for key in keys:
            if key in low:
                score = len(key)
                if score > best_score:
                    best, best_score = canonical, score
    return best


def resolve_role_family(doc_type: str, doc_meta: dict[str, Any], llm_payload: dict[str, Any]) -> str:
    """Pick the role family for a document without leaking a JD label into a CV."""
    llm_raw = llm_payload.get("role_family")
    if doc_type == "pool_cv":
        # the Excel label describes this CV; the LLM inference is a second opinion
        excel = doc_meta.get("role_family") or "unknown"
        if excel and excel != "unknown":
            mapped_excel = map_role_family(excel, "unknown")
            if mapped_excel != "unknown":
                return mapped_excel
        return map_role_family(llm_raw, "unknown")
    if doc_type == "gt_cv":
        # NEVER inherit from the JD; only the CV text (via the LLM) may decide
        return map_role_family(llm_raw, "unknown")
    # JDs: the header line is part of the document itself
    doc_rf = doc_meta.get("role_family")
    if doc_rf and doc_rf != "unknown":
        return map_role_family(doc_rf, "unknown")
    return map_role_family(llm_raw, "unknown")
