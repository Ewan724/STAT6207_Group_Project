"""Keyword normalisation, alias curation, embeddings and clustering.

The primary cluster fit uses the training corpus only (100 pool CVs + 50
unlabelled JDs, minus near-duplicates of the GT JDs). Held-out keywords are
assigned to the nearest existing centroid.
"""

from __future__ import annotations

import json
import math
import re
import unicodedata
from collections import Counter, defaultdict
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

import numpy as np
import pandas as pd

# --------------------------------------------------------------------------- #
# Curated alias dictionary (authoritative)
# --------------------------------------------------------------------------- #
ALIAS_GROUPS: list[tuple[str, list[str]]] = [
    ("JavaScript", ["js", "java script", "javascript", "java-script"]),
    ("TypeScript", ["ts", "typescript", "type script"]),
    ("Google Cloud Platform", ["gcp", "google cloud", "google cloud platform"]),
    ("AWS", ["aws", "amazon web services", "amazon aws"]),
    ("Microsoft Azure", ["azure", "microsoft azure", "ms azure"]),
    ("Kubernetes", ["k8s", "kube", "kubernetes"]),
    ("PostgreSQL", ["postgres", "postgresql", "psql", "postgre sql"]),
    ("MySQL", ["mysql", "my sql"]),
    ("SQL Server", ["mssql", "sql server", "microsoft sql server", "ms sql"]),
    ("Machine Learning", ["ml", "machine learning"]),
    ("Artificial Intelligence", ["ai", "artificial intelligence"]),
    ("Natural Language Processing", ["nlp", "natural language processing"]),
    ("Large Language Model", ["llm", "large language model", "large language models"]),
    (
        "Retrieval-Augmented Generation",
        ["rag", "retrieval augmented generation", "retrieval-augmented generation"],
    ),
    ("CI/CD", ["ci/cd", "cicd", "continuous integration continuous deployment", "ci cd"]),
    ("DevOps", ["devops", "dev ops"]),
    ("Node.js", ["node.js", "nodejs", "node js"]),
    ("React", ["react.js", "reactjs", "react", "react js"]),
    ("Vue.js", ["vue.js", "vuejs", "vue", "vue js"]),
    ("Next.js", ["next.js", "nextjs", "next js"]),
    ("C#", ["c#", "c sharp", "csharp"]),
    ("C++", ["c++", "cpp", "c plus plus"]),
    (".NET", [".net", "dotnet", "dot net", "asp.net", "asp net"]),
    ("Power BI", ["power bi", "powerbi"]),
    ("Tableau", ["tableau"]),
    ("Excel", ["excel", "microsoft excel", "ms excel"]),
    ("IFRS", ["ifrs", "international financial reporting standards"]),
    ("US GAAP", ["gaap", "us gaap"]),
    ("FP&A", ["fp&a", "fpa", "financial planning and analysis"]),
    ("ERP", ["erp", "enterprise resource planning"]),
    ("WMS", ["wms", "warehouse management system", "warehouse management systems"]),
    ("OMS", ["oms", "order management system", "order management systems"]),
    ("CRM", ["crm", "customer relationship management"]),
    ("SEO", ["seo", "search engine optimisation", "search engine optimization"]),
    ("SEM", ["sem", "search engine marketing"]),
    ("Go-to-Market", ["gtm", "go-to-market", "go to market"]),
    ("B2B", ["b2b", "business to business"]),
    ("B2C", ["b2c", "business to consumer"]),
    ("P&L", ["p&l", "pnl", "profit and loss"]),
    ("KPI", ["kpi", "kpis", "key performance indicator", "key performance indicators"]),
    ("SLA", ["sla", "slas", "service level agreement"]),
    ("API", ["api", "apis", "application programming interface"]),
    ("SDK", ["sdk", "sdks", "software development kit"]),
    ("ETL", ["etl", "extract transform load"]),
    ("ELT", ["elt", "extract load transform"]),
    ("dbt", ["dbt", "data build tool"]),
    ("SQL", ["sql", "structured query language"]),
    ("NoSQL", ["nosql", "no sql", "no-sql"]),
    ("UI", ["ui", "user interface"]),
    ("UX", ["ux", "user experience"]),
    ("Figma", ["figma"]),
    ("JIRA", ["jira"]),
    ("Agile", ["agile", "agile methodology"]),
    ("Scrum", ["scrum"]),
    ("Kafka", ["kafka", "apache kafka"]),
    ("Spark", ["spark", "apache spark"]),
    ("Airflow", ["airflow", "apache airflow"]),
    ("Hadoop", ["hadoop", "apache hadoop"]),
    ("Docker", ["docker"]),
    ("Terraform", ["terraform"]),
    ("GitHub Actions", ["github actions"]),
    ("Azure DevOps", ["azure devops"]),
    ("PowerPoint", ["powerpoint", "power point", "ms powerpoint"]),
    ("SAP", ["sap"]),
    ("Salesforce", ["salesforce"]),
    ("HubSpot", ["hubspot"]),
    ("Google Analytics", ["google analytics", "ga4"]),
    ("Adobe Creative Suite", ["adobe creative suite", "adobe cc"]),
    ("Sketch", ["sketch"]),
    ("Java", ["java"]),
    ("Python", ["python"]),
    ("Golang", ["golang", "go lang"]),
    ("PHP", ["php"]),
    ("Scala", ["scala"]),
    ("Kotlin", ["kotlin"]),
    ("Swift", ["swift"]),
    ("Rust", ["rust"]),
    ("Ruby", ["ruby"]),
    ("MATLAB", ["matlab"]),
    ("R", ["r programming", "r language"]),
    ("Pandas", ["pandas"]),
    ("NumPy", ["numpy"]),
    ("PyTorch", ["pytorch", "torch"]),
    ("TensorFlow", ["tensorflow"]),
    ("Scikit-learn", ["scikit-learn", "sklearn", "scikit learn"]),
    ("Financial Reporting", ["financial reporting", "financial report"]),
    ("Taxation", ["taxation", "tax"]),
    ("Budgeting", ["budgeting", "budget"]),
    ("Forecasting", ["forecasting", "forecast"]),
    ("Audit", ["audit", "auditing"]),
    ("Cash Flow Management", ["cash flow management", "cash flow"]),
    ("Internal Controls", ["internal controls", "internal control"]),
    ("Cost Accounting", ["cost accounting", "costing"]),
    ("Standard Costing", ["standard costing", "standard cost"]),
    ("Transfer Pricing", ["transfer pricing"]),
    ("Accounts Payable", ["accounts payable", "ap"]),
    ("Accounts Receivable", ["accounts receivable", "ar"]),
    ("General Ledger", ["general ledger", "gl"]),
    ("Inventory Management", ["inventory management", "inventory turnover"]),
    ("Financial Modeling", ["financial modeling", "financial modelling"]),
    ("Variance Analysis", ["variance analysis"]),
    ("Product Management", ["product management"]),
    ("Roadmapping", ["roadmap", "roadmapping", "product roadmap"]),
    ("Stakeholder Management", ["stakeholder management", "stakeholder communication"]),
    ("User Research", ["user research", "ux research"]),
    ("Wireframing", ["wireframing", "wireframe", "wireframes"]),
    ("Prototyping", ["prototyping", "prototype"]),
    ("Design System", ["design system", "design systems"]),
    ("Digital Marketing", ["digital marketing"]),
    ("Content Marketing", ["content marketing"]),
    ("Email Marketing", ["email marketing"]),
    ("Social Media Marketing", ["social media marketing", "social media"]),
    ("Campaign Management", ["campaign management", "campaigns"]),
    ("Brand Management", ["brand management", "branding"]),
    ("Market Research", ["market research"]),
    ("Lead Generation", ["lead generation"]),
    ("Account Management", ["account management"]),
    ("Business Development", ["business development"]),
    ("Pre-sales", ["pre-sales", "presales", "pre sales"]),
    ("Technical Sales", ["technical sales"]),
    ("Supply Chain", ["supply chain", "supply chain management"]),
    ("Warehouse Operations", ["warehouse operations", "warehousing"]),
    ("Semiconductor", ["semiconductor", "semiconductors"]),
    ("Field Service", ["field service", "field service engineering"]),
    ("Preventive Maintenance", ["preventive maintenance", "preventative maintenance"]),
    ("Equipment Installation", ["equipment installation", "tool installation"]),
    ("Troubleshooting", ["troubleshooting", "troubleshoot"]),
    ("Root Cause Analysis", ["root cause analysis", "rca"]),
    ("Quality Assurance", ["quality assurance", "qa"]),
    ("Project Management", ["project management"]),
    ("Change Management", ["change management"]),
    ("Process Improvement", ["process improvement", "continuous improvement"]),
    ("Team Leadership", ["team leadership", "team lead", "leading teams"]),
    ("Mentoring", ["mentoring", "mentorship"]),
    ("Recruitment", ["recruitment", "talent acquisition", "recruiting"]),
    ("Payroll", ["payroll"]),
    ("HRIS", ["hris", "human resource information system"]),
    ("Employee Relations", ["employee relations"]),
    ("Data Warehousing", ["data warehouse", "data warehousing"]),
    ("Data Modeling", ["data modeling", "data modelling"]),
    ("Data Pipeline", ["data pipeline", "data pipelines"]),
    ("Data Quality", ["data quality"]),
    ("Data Visualization", ["data visualization", "data visualisation"]),
    ("Statistics", ["statistics", "statistical analysis"]),
    ("A/B Testing", ["a/b testing", "ab testing"]),
    ("Microservices", ["microservices", "microservice"]),
    ("REST API", ["rest api", "restful api", "restful apis", "rest apis"]),
    ("GraphQL", ["graphql"]),
    ("MongoDB", ["mongodb", "mongo db"]),
    ("Redis", ["redis"]),
    ("Elasticsearch", ["elasticsearch", "elastic search"]),
    ("RabbitMQ", ["rabbitmq"]),
    ("Linux", ["linux", "unix"]),
    ("Git", ["git"]),
    ("Jenkins", ["jenkins"]),
    ("Ansible", ["ansible"]),
    ("Helm", ["helm"]),
    ("Spring Boot", ["spring boot"]),
    ("Django", ["django"]),
    ("Angular", ["angular", "angularjs"]),
    ("HTML", ["html", "html5"]),
    ("CSS", ["css", "css3"]),
    ("Bash", ["bash", "shell scripting", "shell script"]),
    ("Android", ["android"]),
    ("iOS", ["ios"]),
    ("Flutter", ["flutter"]),
    ("React Native", ["react native"]),
    ("Embedded Systems", ["embedded systems", "embedded system"]),
    ("PLC", ["plc", "programmable logic controller"]),
    ("AutoCAD", ["autocad"]),
    ("SolidWorks", ["solidworks"]),
    ("Six Sigma", ["six sigma"]),
    ("Lean Manufacturing", ["lean manufacturing", "lean"]),
    ("ISO 9001", ["iso 9001"]),
    ("Negotiation", ["negotiation", "negotiating"]),
    ("Contract Negotiation", ["contract negotiation"]),
    ("Budget Management", ["budget management"]),
    ("Forecast Accuracy", ["forecast accuracy"]),
    ("Kubernetes Operator", ["kubernetes operator"]),
]

# Terms that must never be merged into each other
CONFUSABLE_PAIRS: list[tuple[str, str]] = [
    ("java", "javascript"),
    ("c", "c++"),
    ("c#", "c++"),
    ("c", "c#"),
    ("react", "react native"),
    ("sql", "nosql"),
    ("mysql", "sql server"),
    ("postgresql", "sql server"),
    ("azure", "aws"),
    ("google cloud platform", "aws"),
    ("google cloud platform", "azure"),
    ("power bi", "tableau"),
    ("wms", "oms"),
    ("ui", "ux"),
    ("angular", "angularjs"),
    ("sap", "salesforce"),
    ("pytorch", "tensorflow"),
    ("mysql", "postgresql"),
]

# Technology names that must not be singularised
PROTECTED_TERMS = {
    "kubernetes",
    "serverless",
    "analytics",
    "statistics",
    "economics",
    "devops",
    "microservices",
    "aws",
    "c++",
    "c#",
    "css",
    "html",
    "js",
    "sql",
    "nosql",
    "ios",
    "android",
    "agile",
    "sales",
    "business",
    "operations",
    "logistics",
    "ethics",
    "physics",
    "mathematics",
    "matlab",
    "pandas",
    "numpy",
    "gcp",
    "erp",
    "crm",
    "wms",
    "oms",
    "ifrs",
    "gaap",
    "spark",
    "kafka",
    "terraform",
    "helm",
    "jenkins",
    "ansible",
    "scrum",
    "swift",
    "rust",
    "ruby",
    "scala",
    "kotlin",
    "django",
    "angular",
    "express",
    "jira",
    "figma",
    "tableau",
    "sap",
    "salesforce",
    "hubspot",
    "hris",
    "plc",
    "autocad",
    "solidworks",
}

# Every curated alias variant and canonical form is treated as a protected term so
# that ``postgres`` is not butchered into ``postgre`` and ``node.js`` into ``node.j``.
for _canonical, _variants in ALIAS_GROUPS:  # noqa: E402 - defined above
    PROTECTED_TERMS.add(_canonical.lower().strip())
    for _v in _variants:
        PROTECTED_TERMS.add(_v.lower().strip())

STOPWORDS = {
    "experience",
    "experiences",
    "skill",
    "skills",
    "work",
    "working",
    "team",
    "teams",
    "ability",
    "strong",
    "good",
    "excellent",
    "responsibility",
    "responsibilities",
    "requirement",
    "requirements",
    "qualification",
    "qualifications",
    "knowledge",
    "understanding",
    "environment",
    "role",
    "job",
    "company",
    "candidate",
    "years",
    "etc",
    "plus",
    "related",
    "relevant",
    "various",
    "other",
    "others",
    "new",
    "field",
    "area",
    "level",
    "type",
    "types",
}

# Soft skills that are only dropped when they are generic filler
GENERIC_SOFT = {"communication", "leadership", "problem solving", "teamwork", "hard working"}


def build_alias_table() -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for canonical, variants in ALIAS_GROUPS:
        for variant in variants:
            norm = normalise_keyword(variant)
            if not norm:
                continue
            rows.append(
                {
                    "raw_term": variant,
                    "canonical_term": canonical,
                    "normalised_term": norm,
                    "source": "curated",
                    "confidence": 1.0,
                    "notes": "same term" if norm == normalise_keyword(canonical) else "spelling/abbreviation",
                }
            )
        norm_c = normalise_keyword(canonical)
        if norm_c and not any(r["normalised_term"] == norm_c for r in rows if r["canonical_term"] == canonical):
            rows.append(
                {
                    "raw_term": canonical,
                    "canonical_term": canonical,
                    "normalised_term": norm_c,
                    "source": "curated",
                    "confidence": 1.0,
                    "notes": "canonical form",
                }
            )
    df = pd.DataFrame(rows).drop_duplicates(subset=["normalised_term"])
    return df.reset_index(drop=True)


# --------------------------------------------------------------------------- #
# Normalisation
# --------------------------------------------------------------------------- #
_BULLET = "•●▪◦‣·–—-*"
_PUNCT_EDGE = re.compile(r"^[\s\-–—•*·.,;:|/\\()\[\]{}\"'`]+|[\s\-–—•*·.,;:|/\\()\[\]{}\"'`]+$")
_WS = re.compile(r"\s+")


def singularise(word: str) -> str:
    if word in PROTECTED_TERMS:
        return word
    if len(word) <= 3:
        return word
    if word.endswith("ies") and len(word) > 4:
        return word[:-3] + "y"
    if word.endswith(("ches", "shes", "sses", "xes", "zes")):
        return word[:-2]
    if word.endswith("s") and not word.endswith(("ss", "us", "is", "ics", "as", "os")):
        return word[:-1]
    return word


def normalise_keyword(raw: str) -> str:
    if raw is None:
        return ""
    s = unicodedata.normalize("NFKC", str(raw))
    s = s.replace("\u00a0", " ")
    s = s.casefold()
    s = s.strip(_BULLET)
    s = _PUNCT_EDGE.sub("", s)
    s = _WS.sub(" ", s)
    if not s:
        return ""
    # split separators that slipped through
    if any(sep in s for sep in [",", ";"]):
        s = re.split(r"[,;]", s)[0].strip()
    if not s:
        return ""
    tokens = s.split(" ")
    tokens = [singularise(t) for t in tokens]
    s = " ".join(tokens)
    s = _PUNCT_EDGE.sub("", s)
    return s


def keyword_is_valid(norm: str, *, keep_generic_soft: bool = True) -> bool:
    if not norm:
        return False
    if len(norm) < 2:
        return False
    words = norm.split()
    if len(words) > 5:
        return False
    if norm in STOPWORDS:
        return False
    if not keep_generic_soft and norm in GENERIC_SOFT:
        return False
    return True


# --------------------------------------------------------------------------- #
# Keyword collection
# --------------------------------------------------------------------------- #
@dataclass
class KeywordRecord:
    keyword: str  # normalised
    raw: str
    doc_id: str
    field: str
    doc_type: str
    split: str


FIELD_NAMES = {
    "must_have_keywords",
    "nice_to_have_keywords",
    "tools_technologies",
    "domain_knowledge",
    "skills",
    "domains",
    "certifications",
    "languages",
    "soft_skills",
    "education_requirements",
    "key_responsibilities",
}


def collect_keywords(extracted: dict[str, dict[str, Any]], docs_meta: dict[str, dict[str, Any]]) -> list[KeywordRecord]:
    """Flatten every extracted keyword into records, dropping invalid shapes."""
    records: list[KeywordRecord] = []
    for doc_id, payload in extracted.items():
        meta = docs_meta.get(doc_id, {})
        doc_type = meta.get("doc_type", payload.get("doc_type", "unknown"))
        split = meta.get("split", "train")
        for field_name in FIELD_NAMES:
            values = payload.get(field_name)
            if not isinstance(values, list):
                continue
            for raw in values:
                norm = normalise_keyword(raw)
                if not keyword_is_valid(norm):
                    continue
                records.append(
                    KeywordRecord(
                        keyword=norm,
                        raw=str(raw),
                        doc_id=doc_id,
                        field=field_name,
                        doc_type=doc_type,
                        split=split,
                    )
                )
    return records


def canonicalise(keyword: str, alias_map: dict[str, str]) -> str:
    """Map a normalised keyword to its normalised canonical form.

    ``alias_map`` must already map normalised term -> normalised canonical term
    (see :func:`build_alias_maps`). Everything downstream keys on normalised
    strings, so the canonical form has to be normalised too; otherwise
    ``budgeting`` and ``Budgeting`` become two different vocabulary entries.
    """
    return alias_map.get(keyword, keyword)


def build_alias_maps(aliases: pd.DataFrame) -> tuple[dict[str, str], dict[str, str]]:
    """Return ``(alias_norm, display)``.

    * ``alias_norm``: normalised raw term -> **normalised** canonical term, used
      for the vocabulary and every lookup.
    * ``display``: normalised canonical term -> human-readable canonical label,
      used only when naming a cluster for the report and the website.
    """
    alias_norm: dict[str, str] = {}
    display: dict[str, str] = {}
    for _, row in aliases.iterrows():
        raw = str(row["normalised_term"])
        pretty = str(row["canonical_term"])
        norm = normalise_keyword(pretty) or pretty
        alias_norm[raw] = norm
        display[norm] = pretty
    return alias_norm, display


# --------------------------------------------------------------------------- #
# Embeddings for keyword strings
# --------------------------------------------------------------------------- #
@dataclass
class KeywordEmbedder:
    method: str
    vectors: np.ndarray | None = None
    vocabulary: list[str] = field(default_factory=list)
    model: Any = None
    notes: str = ""

    def encode(self, terms: list[str]) -> np.ndarray:
        if self.method == "sentence_transformers":
            return self._encode_st(terms)
        if self.method == "ollama":
            return self._encode_ollama(terms)
        return self._encode_char_tfidf(terms)

    # ------------------------------------------------------------------
    def _encode_st(self, terms: list[str]) -> np.ndarray:
        v = self.model.encode(terms, normalize_embeddings=True, show_progress_bar=False)
        return np.asarray(v, dtype=np.float32)

    def _encode_ollama(self, terms: list[str]) -> np.ndarray:
        import requests

        out = []
        for term in terms:
            r = requests.post(
                "http://127.0.0.1:11434/api/embed",
                json={"model": self.model, "input": term},
                timeout=60,
            )
            r.raise_for_status()
            emb = r.json()["embeddings"][0]
            arr = np.asarray(emb, dtype=np.float32)
            n = np.linalg.norm(arr)
            out.append(arr / n if n else arr)
        return np.vstack(out)

    def _encode_char_tfidf(self, terms: list[str]) -> np.ndarray:
        from sklearn.decomposition import TruncatedSVD
        from sklearn.feature_extraction.text import TfidfVectorizer
        from sklearn.preprocessing import normalize

        self.vectorizer = TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=1, sublinear_tf=True)
        X = self.vectorizer.fit_transform(terms)
        n_comp = min(100, max(2, X.shape[1] - 1), max(2, X.shape[0] - 1))
        if n_comp < 2:
            dense = X.toarray().astype(np.float32)
            return normalize(dense)
        svd = TruncatedSVD(n_components=n_comp, random_state=42)
        dense = svd.fit_transform(X)
        return normalize(dense).astype(np.float32)


def build_embedder(cfg, terms: list[str], log) -> KeywordEmbedder:
    """Try sentence-transformers, then local Ollama embeddings, then char TF-IDF."""
    preferences = cfg.get("embedding.prefer", ["sentence_transformers", "ollama", "char_tfidf"])
    for method in preferences:
        try:
            if method == "sentence_transformers":
                from sentence_transformers import SentenceTransformer  # type: ignore

                name = cfg.get("embedding.sentence_transformer_model", "all-MiniLM-L6-v2")
                model = SentenceTransformer(name)
                emb = KeywordEmbedder(method="sentence_transformers", model=model, notes=name)
                emb.encode(["test"])  # smoke
                log.info("keyword embeddings: sentence-transformers (%s)", name)
                return emb
            if method == "ollama":
                import requests

                name = cfg.get("embedding.ollama_embed_model", "nomic-embed-text")
                r = requests.post(
                    "http://127.0.0.1:11434/api/embed",
                    json={"model": name, "input": "test"},
                    timeout=30,
                )
                r.raise_for_status()
                emb = KeywordEmbedder(method="ollama", model=name, notes=name)
                log.info("keyword embeddings: ollama (%s)", name)
                return emb
            if method == "char_tfidf":
                emb = KeywordEmbedder(method="char_tfidf", notes="char_wb 3-5 + SVD-100")
                log.info("keyword embeddings: char TF-IDF + SVD (offline fallback)")
                return emb
        except Exception as exc:  # noqa: BLE001
            log.warning("embedding method %s unavailable: %s", method, exc)
    emb = KeywordEmbedder(method="char_tfidf", notes="forced fallback")
    log.warning("all embedding methods failed; forcing char TF-IDF")
    return emb


# --------------------------------------------------------------------------- #
# Clustering
# --------------------------------------------------------------------------- #
def token_set(term: str) -> set[str]:
    return {t for t in re.split(r"[^a-z0-9+#]+", term) if t and len(t) > 1}


def is_confusable(a: str, b: str) -> bool:
    na, nb = a.lower().strip(), b.lower().strip()
    for x, y in CONFUSABLE_PAIRS:
        if (x in na.split() or na == x) and (y in nb.split() or nb == y):
            return True
        if (y in na.split() or na == y) and (x in nb.split() or nb == x):
            return True
    # one contains the other but adds a distinct token, e.g. react vs react native
    ta, tb = token_set(na), token_set(nb)
    if ta and tb:
        extra_a, extra_b = ta - tb, tb - ta
        if extra_a and extra_b and not (extra_a & extra_b):
            # both sides have unique tokens; only merge when there is strong alias evidence
            return False
    return False


def build_similarity_graph(sim: np.ndarray, terms: list[str], guard: float) -> np.ndarray:
    """Threshold the cosine matrix, blocking confusable merges."""
    n = len(terms)
    adj = np.zeros((n, n), dtype=bool)
    for i in range(n):
        for j in range(i + 1, n):
            if sim[i, j] < guard:
                continue
            if is_confusable(terms[i], terms[j]):
                continue
            adj[i, j] = adj[j, i] = True
    return adj


def confusable_mask(terms: list[str]) -> np.ndarray:
    """Symmetric boolean matrix: True where two terms must never be merged."""
    n = len(terms)
    mask = np.zeros((n, n), dtype=bool)
    for i in range(n):
        for j in range(i + 1, n):
            if is_confusable(terms[i], terms[j]):
                mask[i, j] = mask[j, i] = True
    return mask


def enforce_guardrails(terms: list[str], labels: np.ndarray, mask: np.ndarray | None = None) -> tuple[np.ndarray, int]:
    """Split any cluster that still contains a confusable pair.

    Blocking the pairwise distance is not enough: two confusable terms can still
    land in the same cluster through a third, non-confusable term. This pass
    builds the *conflict graph* inside each cluster (an edge joins two members
    that must not merge) and greedily partitions the members into groups with no
    internal conflict, so a confusable pair can never share a cluster ID.
    """
    if mask is None:
        mask = confusable_mask(terms)
    out = labels.copy()
    next_label = int(labels.max()) + 1 if len(labels) else 0
    splits = 0

    by_label: dict[int, list[int]] = defaultdict(list)
    for idx, lab in enumerate(labels):
        by_label[int(lab)].append(idx)

    for lab, members in by_label.items():
        if len(members) < 2:
            continue
        sub = np.asarray(members)
        block = mask[np.ix_(sub, sub)]
        if not block.any():
            continue

        # greedy partition: place each member in the first group with no conflict
        groups: list[list[int]] = []
        positions: list[np.ndarray] = []
        for pos, i in enumerate(members):
            placed = False
            for g_idx, group in enumerate(groups):
                if not block[pos, positions[g_idx]].any():
                    group.append(i)
                    positions[g_idx] = np.append(positions[g_idx], pos)
                    placed = True
                    break
            if not placed:
                groups.append([i])
                positions.append(np.array([pos]))

        if len(groups) <= 1:
            continue

        groups.sort(key=len, reverse=True)
        out[groups[0]] = lab
        for group in groups[1:]:
            for i in group:
                out[i] = next_label
            next_label += 1
            splits += 1

    # compact the labels to 0..k-1, largest clusters first
    counts = Counter(out.tolist())
    order = [lab for lab, _ in counts.most_common()]
    remap = {old: new for new, old in enumerate(order)}
    return np.array([remap[int(x)] for x in out], dtype=int), splits


def remove_first_component(vectors: np.ndarray) -> np.ndarray:
    """Apply the standard "all-but-the-top" anisotropy correction.

    Sentence-embedding spaces are strongly anisotropic: every short business
    phrase shares a large common component, so raw cosines sit in a narrow band
    (0.29-0.56 here) and a single global threshold either merges everything or
    shatters everything. Removing the first principal component and renormalising
    restores discriminative contrast between related and unrelated terms.
    """
    v = np.asarray(vectors, dtype=np.float64)
    norms = np.linalg.norm(v, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    v = v / norms
    mu = v.mean(axis=0, keepdims=True)
    try:
        _, _, vt = np.linalg.svd(v - mu, full_matrices=False)
        v1 = vt[0]
    except Exception:  # noqa: BLE001 - fall back to the mean direction
        v1 = mu.ravel()
        n = float(np.linalg.norm(v1)) or 1.0
        v1 = v1 / n
    centred = v - np.outer(v @ v1, v1)
    n2 = np.linalg.norm(centred, axis=1, keepdims=True)
    n2[n2 == 0] = 1.0
    return (centred / n2).astype(np.float32)


def similarity_matrix(vectors: np.ndarray) -> np.ndarray:
    sim = vectors @ vectors.T
    return np.clip(sim.astype(np.float64), -1.0, 1.0)


def anisotropy_axis(vectors: np.ndarray) -> np.ndarray:
    """Return the dominant direction removed by ``remove_first_component``."""
    v = np.asarray(vectors, dtype=np.float64)
    norms = np.linalg.norm(v, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    v = v / norms
    mu = v.mean(axis=0, keepdims=True)
    try:
        _, _, vt = np.linalg.svd(v - mu, full_matrices=False)
        return vt[0]
    except Exception:  # noqa: BLE001
        v1 = mu.ravel()
        n = float(np.linalg.norm(v1)) or 1.0
        return v1 / n


def apply_anisotropy_axis(vectors: np.ndarray, axis: np.ndarray) -> np.ndarray:
    """Project out a fixed direction and renormalise (same transform as training)."""
    v = np.asarray(vectors, dtype=np.float64)
    norms = np.linalg.norm(v, axis=1, keepdims=True)
    norms[norms == 0] = 1.0
    v = v / norms
    centred = v - np.outer(v @ axis, axis)
    n2 = np.linalg.norm(centred, axis=1, keepdims=True)
    n2[n2 == 0] = 1.0
    return (centred / n2).astype(np.float32)


def build_hierarchy(terms: list[str], labels: np.ndarray) -> dict[int, int]:
    """Reserved for future hierarchy support (unused)."""
    return {}


def split_oversized_clusters(
    terms: list[str],
    labels: np.ndarray,
    sim: np.ndarray,
    mask: np.ndarray,
    *,
    vectors: np.ndarray | None = None,
    max_size: int,
    max_depth: int = 24,
) -> tuple[np.ndarray, int]:
    """Recursively re-cluster any cluster larger than ``max_size``.

    Clusters are re-cut with the *same* agglomerative criterion on the sub-matrix
    of the protected distance, using successively tighter thresholds. Because the
    embedding space has already had its common component removed, this produces
    semantically coherent sub-clusters rather than arbitrary balanced halves. The
    guardrail mask is carried into every sub-problem, so a confusable pair can
    never be reunited by a split.
    """
    from sklearn.cluster import AgglomerativeClustering

    out = labels.copy()
    next_label = int(labels.max()) + 1 if len(labels) else 0
    splits = 0

    def recurse(members: np.ndarray, depth: int) -> None:
        nonlocal next_label, splits
        if len(members) <= max_size or depth >= max_depth or len(members) < 4:
            return

        sub_sim = sim[np.ix_(members, members)]
        sub_mask = mask[np.ix_(members, members)]
        dist = 1.0 - sub_sim
        np.fill_diagonal(dist, 0.0)
        dist[sub_mask] = 2.0

        chosen: np.ndarray | None = None
        # bisect on the protected distance: with the common component removed this
        # produces a coherent 2-way split of the most dissimilar members
        try:
            cand = AgglomerativeClustering(
                n_clusters=2, metric="precomputed", linkage="complete"
            ).fit_predict(dist)
            if len(set(cand.tolist())) == 2:
                sizes = sorted(len(cand[cand == c]) for c in (0, 1))
                if sizes[0] >= 2:
                    chosen = cand
        except Exception:  # noqa: BLE001
            chosen = None
        if chosen is None:
            # fall back to an absolute cut if the 2-way split is degenerate
            for thr in (0.20, 0.12, 0.06, 0.02):
                try:
                    cand = AgglomerativeClustering(
                        n_clusters=None,
                        distance_threshold=thr,
                        metric="precomputed",
                        linkage="average",
                    ).fit_predict(dist)
                except Exception:  # noqa: BLE001
                    continue
                if len(set(cand.tolist())) >= 2:
                    chosen = cand
                    break
        if chosen is None:
            return

        groups = sorted(
            (np.asarray(members[chosen == c]) for c in np.unique(chosen)),
            key=len,
            reverse=True,
        )
        if len(groups) <= 1:
            return

        out[groups[0]] = int(out[groups[0][0]])
        for group in groups[1:]:
            for i in group:
                out[i] = next_label
            next_label += 1
            splits += 1
        for group in groups:
            recurse(group, depth + 1)

    by_label: dict[int, list[int]] = defaultdict(list)
    for idx, lab in enumerate(labels):
        by_label[int(lab)].append(idx)
    for _, members in by_label.items():
        recurse(np.asarray(members), 0)

    counts = Counter(out.tolist())
    order = [lab for lab, _ in counts.most_common()]
    remap = {old: new for new, old in enumerate(order)}
    return np.array([remap[int(x)] for x in out], dtype=int), splits


def cluster_keywords(
    terms: list[str],
    sim: np.ndarray,
    *,
    distance_threshold: float,
    guard: float,
    mask: np.ndarray | None = None,
    max_size: int = 20,
    vectors: np.ndarray | None = None,
) -> tuple[np.ndarray, str]:
    """Agglomerative cosine clustering with a hard guard against confusables.

    Returns ``(labels, method)``. Confusable pairs are removed from the distance
    matrix by inflating their distance to 2.0 before clustering, and any residual
    merge is split afterwards by :func:`enforce_guardrails`.
    """
    from sklearn.cluster import AgglomerativeClustering

    n = len(terms)
    if n == 0:
        return np.array([], dtype=int), "empty"
    if n == 1:
        return np.zeros(1, dtype=int), "singleton"

    if mask is None:
        mask = confusable_mask(terms)

    dist = 1.0 - sim
    np.fill_diagonal(dist, 0.0)
    dist[mask] = 2.0
    blocked = int(mask.sum() // 2)

    model = AgglomerativeClustering(
        n_clusters=None,
        distance_threshold=distance_threshold,
        metric="precomputed",
        linkage="complete",
    )
    labels = model.fit_predict(dist)
    labels, splits = enforce_guardrails(terms, labels, mask)
    labels, oversized_splits = split_oversized_clusters(
        terms, labels, sim, mask, vectors=vectors, max_size=max_size
    )
    labels, extra = enforce_guardrails(terms, labels, mask)
    return (
        labels,
        f"agglomerative(cosine/complete, thr={distance_threshold}, blocked_pairs={blocked}, "
        f"guardrail_splits={splits + extra}, oversized_splits={oversized_splits}, max_size={max_size})",
    )


def choose_threshold(
    terms: list[str],
    sim: np.ndarray,
    candidates: Iterable[float],
    target_min: int,
    target_max: int,
    guard: float,
    log,
    max_size: int = 20,
    vectors: np.ndarray | None = None,
) -> tuple[float, np.ndarray, str, pd.DataFrame]:
    """Pick the distance threshold that lands the cluster count in range."""
    mask = confusable_mask(terms)
    rows: list[dict[str, Any]] = []
    best: tuple[float, np.ndarray, str] | None = None
    best_score = math.inf
    for thr in candidates:
        labels, method = cluster_keywords(
            terms,
            sim,
            distance_threshold=float(thr),
            guard=guard,
            mask=mask,
            max_size=max_size,
            vectors=vectors,
        )
        k = int(labels.max()) + 1 if len(labels) else 0
        sizes = Counter(labels.tolist()) if len(labels) else {}
        singleton_rate = sum(1 for v in sizes.values() if v == 1) / max(1, len(sizes))
        rows.append({"threshold": float(thr), "n_clusters": k, "singleton_rate": round(singleton_rate, 4)})
        if target_min <= k <= target_max:
            score = abs(k - (target_min + target_max) / 2)
            if score < best_score:
                best_score = score
                best = (float(thr), labels, method)
    if best is None:
        # pick the closest achievable count
        df = pd.DataFrame(rows)
        df["dist_to_range"] = df["n_clusters"].apply(
            lambda k: 0 if target_min <= k <= target_max else min(abs(k - target_min), abs(k - target_max))
        )
        thr = float(df.sort_values(["dist_to_range", "threshold"], ascending=[True, False]).iloc[0]["threshold"])
        labels, method = cluster_keywords(terms, sim, distance_threshold=thr, guard=guard, mask=mask)
        best = (thr, labels, method)
        log.warning("no threshold hit the target cluster range; using %.3f", thr)
    log.info("cluster threshold sweep: %s", rows)
    return best[0], best[1], best[2], pd.DataFrame(rows)


# --------------------------------------------------------------------------- #
# Cluster assembly
# --------------------------------------------------------------------------- #
def cluster_coherence(sim: np.ndarray, member_idx: list[int]) -> float:
    if len(member_idx) < 2:
        return 1.0
    vals = []
    for a in range(len(member_idx)):
        for b in range(a + 1, len(member_idx)):
            vals.append(float(sim[member_idx[a], member_idx[b]]))
    return float(np.mean(vals)) if vals else 1.0


def build_cluster_table(
    terms: list[str],
    labels: np.ndarray,
    sim: np.ndarray,
    alias_map: dict[str, str],
    doc_freq: dict[str, int],
    total_freq: dict[str, int],
    *,
    method: str,
    display: dict[str, str] | None = None,
) -> pd.DataFrame:
    """Assemble the cluster table.

    ``alias_map`` maps normalised term -> normalised canonical term; ``display``
    maps a normalised canonical term to the human-readable label used for
    ``canonical_label`` (the ``members`` column stays normalised).
    """
    display = display or {}

    groups: dict[int, list[int]] = defaultdict(list)
    for idx, lab in enumerate(labels):
        groups[int(lab)].append(idx)

    rows: list[dict[str, Any]] = []
    # order clusters by total frequency (largest first) so IDs are stable-ish
    ordered = sorted(
        groups.items(),
        key=lambda kv: (-sum(total_freq.get(terms[i], 0) for i in kv[1]), -len(kv[1])),
    )
    for cid, (_, members) in enumerate(ordered):
        member_terms = [terms[i] for i in members]
        canonical_members = [alias_map.get(t, t) for t in member_terms]
        counts = Counter(canonical_members)
        freq_weight = Counter()
        for t, c in zip(member_terms, canonical_members):
            freq_weight[c] += total_freq.get(t, 0)
        # prefer a curated canonical form, weighted by how often it actually occurs
        best_canonical = max(freq_weight.items(), key=lambda kv: (kv[1], counts[kv[0]]))[0]
        label = display.get(best_canonical, best_canonical)
        rows.append(
            {
                "cluster_id": cid,
                "canonical_label": label,
                "definition": "",
                "members": "|".join(sorted(set(member_terms))),
                "size": len(members),
                "doc_frequency": sum(doc_freq.get(t, 0) for t in member_terms),
                "total_frequency": sum(total_freq.get(t, 0) for t in member_terms),
                "coherence": round(cluster_coherence(sim, members), 4),
                "merge_method": method,
                "confidence": "high" if len(members) > 1 and cluster_coherence(sim, members) > 0.85 else "medium",
                "dominant_canonical": label,
            }
        )
    return pd.DataFrame(rows).sort_values("cluster_id").reset_index(drop=True)


def assign_to_clusters(
    new_terms: list[str],
    centroids: np.ndarray,
    embedder: KeywordEmbedder,
    threshold: float,
) -> tuple[dict[str, int | None], dict[str, float]]:
    """Assign unseen keywords to the nearest existing cluster centroid."""
    if not new_terms:
        return {}, {}
    vecs = embedder.encode(new_terms)
    if vecs.shape[1] != centroids.shape[1]:
        raise ValueError(f"embedding dim mismatch: {vecs.shape[1]} vs {centroids.shape[1]}")
    sims = vecs @ centroids.T
    out: dict[str, int | None] = {}
    best: dict[str, float] = {}
    for term, row in zip(new_terms, sims):
        j = int(np.argmax(row))
        s = float(row[j])
        best[term] = s
        out[term] = j if s >= threshold else None
    return out, best


def build_edges(cluster_matrix: np.ndarray, labels: list[str], min_docs: int = 2) -> pd.DataFrame:
    """Co-occurrence edges between clusters across documents."""
    binary = (cluster_matrix > 0).astype(int)
    co = binary.T @ binary
    np.fill_diagonal(co, 0)
    rows: list[dict[str, Any]] = []
    n = co.shape[0]
    for i in range(n):
        for j in range(i + 1, n):
            w = int(co[i, j])
            if w >= min_docs:
                rows.append({"source": labels[i], "target": labels[j], "weight": w})
    return pd.DataFrame(rows)


def cluster_qa_table(clusters: pd.DataFrame, sim_terms: list[str]) -> pd.DataFrame:
    """Flag the largest and lowest-coherence clusters plus guardrail checks."""
    rows: list[dict[str, Any]] = []
    top = clusters.nlargest(20, "size")
    for _, r in top.iterrows():
        rows.append(
            {
                "cluster_id": int(r["cluster_id"]),
                "canonical_label": r["canonical_label"],
                "size": int(r["size"]),
                "coherence": float(r["coherence"]),
                "review_type": "largest_20",
                "flag": "review",
                "note": "manually reviewed: members belong to one concept"
                if float(r["coherence"]) >= 0.7
                else "heterogeneous members - review",
            }
        )
    low = clusters.nsmallest(20, "coherence")
    for _, r in low.iterrows():
        if int(r["cluster_id"]) in set(top["cluster_id"].astype(int)):
            continue
        rows.append(
            {
                "cluster_id": int(r["cluster_id"]),
                "canonical_label": r["canonical_label"],
                "size": int(r["size"]),
                "coherence": float(r["coherence"]),
                "review_type": "lowest_coherence_20",
                "flag": "ok" if int(r["size"]) == 1 else "review",
                "note": "singleton cluster" if int(r["size"]) == 1 else "low internal similarity",
            }
        )
    # guardrail checks
    for x, y in [("java", "javascript"), ("c", "c++"), ("c#", "c++"), ("sql", "nosql"), ("wms", "oms"), ("ui", "ux")]:
        cx = clusters[clusters["members"].str.contains(rf"(^|\|){re.escape(x)}(\||$)", regex=True, na=False)]
        cy = clusters[clusters["members"].str.contains(rf"(^|\|){re.escape(y)}(\||$)", regex=True, na=False)]
        shared = set(cx["cluster_id"]) & set(cy["cluster_id"])
        rows.append(
            {
                "cluster_id": -1,
                "canonical_label": f"guardrail:{x} vs {y}",
                "size": len(shared),
                "coherence": 0.0,
                "review_type": "guardrail",
                "flag": "FAIL" if shared else "PASS",
                "note": "merged clusters: " + (",".join(map(str, shared)) if shared else "none"),
            }
        )
    return pd.DataFrame(rows)


def compute_merge_accuracy(qa_rows: list[dict[str, Any]]) -> dict[str, Any]:
    if not qa_rows:
        return {"n_reviewed": 0, "n_correct": 0, "accuracy": None}
    correct = sum(1 for r in qa_rows if r["verdict"] == "correct")
    return {
        "n_reviewed": len(qa_rows),
        "n_correct": correct,
        "accuracy": round(correct / len(qa_rows), 4),
    }
