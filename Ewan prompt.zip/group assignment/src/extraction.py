"""LLM-driven structured extraction with schema validation and rule fallback."""

from __future__ import annotations

import hashlib
import json
import re
import time
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from .llm import LLMCache, OllamaClient, mask_pii, parse_json_loose, prompt_hash

SENIORITY = ["intern", "junior", "mid", "senior", "lead", "director", "executive", "unknown"]
REMOTE = ["yes", "no", "hybrid", "unknown"]
ROLE_FAMILIES = [
    "Finance & Legal",
    "Sales & BD",
    "Marketing",
    "Data & AI",
    "Product",
    "Engineering",
    "Design & Creative",
    "Operations & HR",
    "Leadership",
    "unknown",
]

GENERIC_STOPWORDS = {
    "experience",
    "experiences",
    "skill",
    "skills",
    "work",
    "working",
    "team",
    "teams",
    "ability",
    "strong",
    "good",
    "excellent",
    "communication",
    "responsibility",
    "responsibilities",
    "requirement",
    "requirements",
    "qualification",
    "qualifications",
    "knowledge",
    "understanding",
    "environment",
    "role",
    "job",
    "company",
    "candidate",
    "years",
    "plus",
    "etc",
    "eg",
    "ie",
}

ALIAS_SUPPORT = {
    # abbreviation -> phrase that may appear verbatim in the source
    "gcp": "google cloud platform",
    "js": "javascript",
    "ts": "typescript",
    "k8s": "kubernetes",
    "ml": "machine learning",
    "ai": "artificial intelligence",
    "nlp": "natural language processing",
    "llm": "large language model",
    "rag": "retrieval-augmented generation",
    "ci/cd": "continuous integration",
    "cicd": "continuous integration",
    "db": "database",
    "qa": "quality assurance",
    "ux": "user experience",
    "ui": "user interface",
    "hr": "human resources",
    "gtm": "go-to-market",
    "crm": "customer relationship management",
    "erp": "enterprise resource planning",
    "wms": "warehouse management system",
    "oms": "order management system",
    "seo": "search engine optimisation",
    "sem": "search engine marketing",
    "fp&a": "financial planning and analysis",
    "p&l": "profit and loss",
    "kpi": "key performance indicator",
    "sla": "service level agreement",
    "api": "application programming interface",
    "sdk": "software development kit",
    "etl": "extract transform load",
    "elt": "extract load transform",
    "sql": "structured query language",
    "nosql": "no sql",
    "ifrs": "international financial reporting standards",
    "gaap": "generally accepted accounting principles",
    "b2b": "business to business",
    "b2c": "business to consumer",
    "cd": "continuous deployment",
    "fe": "frontend",
    "be": "backend",
    "aws": "amazon web services",
    "bi": "business intelligence",
    "rpa": "robotic process automation",
    "saas": "software as a service",
    "mvp": "minimum viable product",
    "roi": "return on investment",
    "ta": "talent acquisition",
}


# --------------------------------------------------------------------------- #
# Schema helpers
# --------------------------------------------------------------------------- #
def jd_schema(doc_id: str) -> dict[str, Any]:
    return {
        "type": "object",
        "required": ["doc_id", "doc_type", "job_title", "must_have_keywords"],
        "properties": {
            "doc_id": {"type": "string"},
            "doc_type": {"type": "string"},
            "job_title": {"type": ["string", "null"]},
            "role_family": {"type": ["string", "null"]},
            "seniority": {"type": ["string", "null"]},
            "location": {"type": ["string", "null"]},
            "remote": {"type": ["string", "null"]},
            "min_years_experience": {"type": ["number", "integer", "null"]},
            "must_have_keywords": {"type": "array", "items": {"type": "string"}},
            "nice_to_have_keywords": {"type": "array", "items": {"type": "string"}},
            "tools_technologies": {"type": "array", "items": {"type": "string"}},
            "domain_knowledge": {"type": "array", "items": {"type": "string"}},
            "education_requirements": {"type": "array", "items": {"type": "string"}},
            "certifications": {"type": "array", "items": {"type": "string"}},
            "languages": {"type": "array", "items": {"type": "string"}},
            "soft_skills": {"type": "array", "items": {"type": "string"}},
            "key_responsibilities": {"type": "array", "items": {"type": "string"}},
        },
    }


def cv_schema(doc_id: str) -> dict[str, Any]:
    return {
        "type": "object",
        "required": ["doc_id", "doc_type", "current_title", "skills"],
        "properties": {
            "doc_id": {"type": "string"},
            "doc_type": {"type": "string"},
            "current_title": {"type": ["string", "null"]},
            "current_company": {"type": ["string", "null"]},
            "role_family": {"type": ["string", "null"]},
            "seniority": {"type": ["string", "null"]},
            "total_years_experience": {"type": ["number", "integer", "null"]},
            "skills": {"type": "array", "items": {"type": "string"}},
            "tools_technologies": {"type": "array", "items": {"type": "string"}},
            "domains": {"type": "array", "items": {"type": "string"}},
            "education": {"type": "array"},
            "certifications": {"type": "array", "items": {"type": "string"}},
            "languages": {"type": "array", "items": {"type": "string"}},
            "locations": {"type": "array", "items": {"type": "string"}},
            "soft_skills": {"type": "array", "items": {"type": "string"}},
            "work_history": {"type": "array"},
        },
    }


ARRAY_FIELDS = {
    "must_have_keywords",
    "nice_to_have_keywords",
    "tools_technologies",
    "domain_knowledge",
    "education_requirements",
    "certifications",
    "languages",
    "soft_skills",
    "key_responsibilities",
    "skills",
    "domains",
    "locations",
}


def _coerce_list(value: Any) -> list[str]:
    if value is None:
        return []
    if isinstance(value, str):
        parts = re.split(r"[,;\n]", value)
        return [p.strip() for p in parts if p.strip()]
    if isinstance(value, list):
        out: list[str] = []
        for v in value:
            if isinstance(v, str):
                out.append(v.strip())
            elif isinstance(v, dict):
                # education entries
                label = v.get("degree") or v.get("field") or v.get("institution")
                if label:
                    out.append(str(label).strip())
            elif v is not None:
                out.append(str(v))
        return [x for x in out if x]
    return [str(value)]


def _coerce_scalar(value: Any, allowed: list[str] | None = None) -> Any:
    if value is None:
        return None
    if isinstance(value, str):
        v = value.strip()
        if not v or v.lower() in {"null", "none", "n/a", "na", "unknown", ""}:
            return None if allowed else v
        if allowed is not None:
            low = v.lower()
            if low in allowed:
                return low
            return "unknown"
        return v
    if allowed is not None:
        return str(value).lower() if str(value).lower() in allowed else "unknown"
    return value


def _coerce_years(value: Any) -> float | None:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return None if value != value else float(value)
    m = re.search(r"\d+(?:\.\d+)?", str(value))
    return float(m.group()) if m else None


def normalise_payload(payload: dict[str, Any], doc_type: str) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for key, value in payload.items():
        if key in ARRAY_FIELDS:
            out[key] = _coerce_list(value)
        elif key == "seniority":
            out[key] = _coerce_scalar(value, SENIORITY)
        elif key == "remote":
            out[key] = _coerce_scalar(value, REMOTE)
        elif key in {"min_years_experience", "total_years_experience"}:
            out[key] = _coerce_years(value)
        elif key in {"education", "work_history"}:
            out[key] = value if isinstance(value, list) else []
        else:
            out[key] = _coerce_scalar(value)
    return out


def validate_payload(payload: dict[str, Any], doc_id: str, doc_type: str) -> list[str]:
    errors: list[str] = []
    required = ["doc_id", "doc_type", "job_title", "must_have_keywords"] if doc_type == "jd" else [
        "doc_id",
        "doc_type",
        "current_title",
        "skills",
    ]
    for field_name in required:
        if field_name not in payload:
            errors.append(f"missing field: {field_name}")
    if payload.get("doc_type") not in {"jd", "cv"}:
        errors.append(f"bad doc_type: {payload.get('doc_type')!r}")
    for arr in ("must_have_keywords", "nice_to_have_keywords", "skills", "tools_technologies"):
        v = payload.get(arr, [])
        if v and not isinstance(v, list):
            errors.append(f"{arr} is not a list")
    return errors


# --------------------------------------------------------------------------- #
# Keyword grounding
# --------------------------------------------------------------------------- #
_WORD_RE = re.compile(r"[a-z0-9+#./&]+")


def _norm_for_match(s: str) -> str:
    return re.sub(r"\s+", " ", s.lower().replace("_", " ")).strip()


def keyword_in_source(keyword: str, source_norm: str) -> bool:
    kw = _norm_for_match(keyword)
    if not kw:
        return False
    if kw in source_norm:
        return True
    # alias expansion
    if kw in ALIAS_SUPPORT and _norm_for_match(ALIAS_SUPPORT[kw]) in source_norm:
        return True
    # singular/plural tolerance on the final token
    if kw.endswith("s") and kw[:-1] in source_norm:
        return True
    if f"{kw}s" in source_norm:
        return True
    # hyphen / space tolerance
    if kw.replace(" ", "-") in source_norm or kw.replace("-", " ") in source_norm:
        return True
    # all significant tokens present
    tokens = [t for t in _WORD_RE.findall(kw) if len(t) > 1]
    if tokens and all(t in source_norm for t in tokens):
        return True
    return False


def keyword_shape_ok(keyword: str) -> tuple[bool, str]:
    kw = keyword.strip()
    if not kw:
        return False, "empty"
    words = kw.split()
    if len(words) < 1:
        return False, "empty"
    if len(words) > 4:
        return False, "too_many_words"
    if len(kw) < 2:
        return False, "too_short"
    if _norm_for_match(kw) in GENERIC_STOPWORDS:
        return False, "generic_stopword"
    if len(words) == 1 and _norm_for_match(kw) in {"develop", "manage", "build", "lead", "support"}:
        return False, "generic_verb"
    if kw.endswith(".") and len(words) == 1:
        return False, "sentence"
    return True, ""


def ground_keywords(
    payload: dict[str, Any], source_text: str
) -> tuple[dict[str, Any], list[dict[str, str]]]:
    """Drop keywords that are not grounded in the source; return (payload, dropped)."""
    source_norm = _norm_for_match(source_text)
    dropped: list[dict[str, str]] = []
    for field_name in (
        "must_have_keywords",
        "nice_to_have_keywords",
        "tools_technologies",
        "domain_knowledge",
        "skills",
        "domains",
        "certifications",
        "languages",
        "soft_skills",
    ):
        if field_name not in payload:
            continue
        kept: list[str] = []
        for kw in payload[field_name]:
            ok_shape, reason = keyword_shape_ok(kw)
            if not ok_shape:
                dropped.append({"keyword": kw, "field": field_name, "reason": reason})
                continue
            if not keyword_in_source(kw, source_norm):
                dropped.append({"keyword": kw, "field": field_name, "reason": "not_in_source"})
                continue
            kept.append(kw)
        # dedupe preserving order
        seen: set[str] = set()
        uniq: list[str] = []
        for kw in kept:
            k = _norm_for_match(kw)
            if k in seen:
                continue
            seen.add(k)
            uniq.append(kw)
        payload[field_name] = uniq
    return payload, dropped


# --------------------------------------------------------------------------- #
# Deterministic fallback
# --------------------------------------------------------------------------- #
SECTION_HEADS = [
    "skills",
    "requirements",
    "qualifications",
    "nice to have",
    "must have",
    "bonus",
    "preferred",
    "technical skills",
    "key skills",
    "core competencies",
]


def fallback_extract(text: str, doc_id: str, doc_type: str) -> dict[str, Any]:
    """Rule-based extraction used when the LLM output cannot be repaired."""
    lines = [ln.strip() for ln in text.split("\n")]
    keywords: list[str] = []
    capture = False
    for line in lines:
        low = line.lower().strip("-• ").strip()
        if low in SECTION_HEADS:
            capture = True
            continue
        if capture:
            if not line:
                capture = False
                continue
            if re.match(r"^[A-Z][A-Za-z &/]{3,40}$", line) and low not in SECTION_HEADS:
                capture = False
                continue
            for chunk in re.split(r"[,;|]", line.strip("- ")):
                c = chunk.strip(" .-")
                if 2 <= len(c) <= 60 and 1 <= len(c.split()) <= 4:
                    keywords.append(c)
    # also mine capitalised technology-looking tokens
    for token in re.findall(r"\b[A-Z][A-Za-z0-9+#.]{2,20}\b", text):
        if token.lower() in GENERIC_STOPWORDS:
            continue
        keywords.append(token)
    seen: set[str] = set()
    uniq: list[str] = []
    for kw in keywords:
        k = kw.lower()
        if k in seen:
            continue
        seen.add(k)
        uniq.append(kw)

    if doc_type == "jd":
        return {
            "doc_id": doc_id,
            "doc_type": "jd",
            "job_title": lines[0] if lines else "",
            "role_family": None,
            "seniority": "unknown",
            "location": None,
            "remote": "unknown",
            "min_years_experience": None,
            "must_have_keywords": uniq[:15],
            "nice_to_have_keywords": [],
            "tools_technologies": uniq[15:25],
            "domain_knowledge": [],
            "education_requirements": [],
            "certifications": [],
            "languages": [],
            "soft_skills": [],
            "key_responsibilities": [],
        }
    return {
        "doc_id": doc_id,
        "doc_type": "cv",
        "current_title": lines[0] if lines else "",
        "current_company": None,
        "role_family": None,
        "seniority": "unknown",
        "total_years_experience": None,
        "skills": uniq[:20],
        "tools_technologies": uniq[20:32],
        "domains": [],
        "education": [],
        "certifications": [],
        "languages": [],
        "locations": [],
        "soft_skills": [],
        "work_history": [],
    }


# --------------------------------------------------------------------------- #
# Extraction driver
# --------------------------------------------------------------------------- #
@dataclass
class ExtractionResult:
    doc_id: str
    doc_type: str
    status: str  # ok | repaired | fallback | failed
    payload: dict[str, Any]
    dropped: list[dict[str, str]]
    elapsed_sec: float
    model: str
    cache_path: str = ""
    raw_path: str = ""
    errors: list[str] = None  # type: ignore[assignment]

    def __post_init__(self) -> None:
        if self.errors is None:
            self.errors = []


class Extractor:
    def __init__(self, cfg, client: OllamaClient, cache: LLMCache, log) -> None:
        self.cfg = cfg
        self.client = client
        self.cache = cache
        self.log = log
        self.system_prompt = cfg.prompt("system_extraction.txt")
        self.jd_template = cfg.prompt("jd_extraction.txt")
        self.cv_template = cfg.prompt("cv_extraction.txt")
        self.phash = prompt_hash(self.system_prompt + self.jd_template + self.cv_template)
        self.raw_dir = cfg.path("processed") / "raw_responses"
        self.raw_dir.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------ prompt
    def build_prompt(self, doc_id: str, doc_type: str, text: str) -> str:
        masked, counts = mask_pii(text)
        if sum(counts.values()):
            self.log.info("masked PII in %s: %s", doc_id, counts)
        template = self.jd_template if doc_type == "jd" else self.cv_template
        body = template.replace("{DOCUMENT_TEXT}", masked)
        # the schema examples use a placeholder doc_id; give the model the real one
        header = (
            f"Use doc_id={doc_id!r} and doc_type={doc_type!r} in the JSON object.\n\n"
        )
        return header + body

    # ------------------------------------------------------------------ chunk
    def chunk_text(self, text: str) -> list[str]:
        limit = int(self.cfg.get("extraction.chunk_chars", 8000))
        if len(text) <= limit:
            return [text]
        overlap = int(self.cfg.get("extraction.chunk_overlap", 200))
        chunks: list[str] = []
        start = 0
        while start < len(text):
            end = min(start + limit, len(text))
            chunks.append(text[start:end])
            if end >= len(text):
                break
            start = max(end - overlap, start + 1)
        return chunks

    def _merge_chunks(self, payloads: list[dict[str, Any]], doc_id: str, doc_type: str) -> dict[str, Any]:
        merged = payloads[0].copy()
        for payload in payloads[1:]:
            for key, value in payload.items():
                if key in ARRAY_FIELDS and isinstance(value, list):
                    existing = {str(x).lower() for x in merged.get(key, [])}
                    for item in value:
                        if str(item).lower() not in existing:
                            merged.setdefault(key, []).append(item)
                            existing.add(str(item).lower())
                elif key in {"total_years_experience", "min_years_experience"}:
                    a = merged.get(key)
                    b = value
                    if isinstance(a, (int, float)) and isinstance(b, (int, float)):
                        merged[key] = max(a, b)
                    elif merged.get(key) is None:
                        merged[key] = b
                elif merged.get(key) in (None, "", [], "unknown") and value not in (None, "", [], "unknown"):
                    merged[key] = value
        merged["doc_id"] = doc_id
        merged["doc_type"] = doc_type
        return merged

    # ------------------------------------------------------------------- call
    def extract(self, doc_id: str, doc_type: str, text: str, *, force: bool = False) -> ExtractionResult:
        cached = None if force else self.cache.load(doc_id, self.phash)
        if cached and cached.get("status") in {"ok", "repaired"}:
            payload = cached["parsed"]
            return ExtractionResult(
                doc_id=doc_id,
                doc_type=doc_type,
                status=cached["status"],
                payload=payload,
                dropped=cached.get("dropped_keywords", []),
                elapsed_sec=float(cached.get("elapsed_sec", 0.0)),
                model=cached.get("model", self.client.model),
                cache_path=str(self.cache.path_for(doc_id)),
                raw_path=cached.get("raw_path", ""),
                errors=list(cached.get("validation_errors", [])),
            )

        chunks = self.chunk_text(text)
        payloads: list[dict[str, Any]] = []
        errors: list[str] = []
        raw_all: list[str] = []
        elapsed = 0.0
        status = "ok"
        model_used = self.client.model

        for chunk_idx, chunk in enumerate(chunks):
            prompt = self.build_prompt(doc_id, doc_type, chunk)
            parsed: dict[str, Any] | None = None
            chunk_errors: list[str] = []
            for attempt in range(3):
                try:
                    resp = self.client.chat(self.system_prompt, prompt)
                    elapsed += resp.elapsed_sec
                    model_used = resp.model
                    raw_all.append(resp.content)
                    obj = parse_json_loose(resp.content)
                    obj = normalise_payload(obj, doc_type)
                    obj["doc_id"] = doc_id
                    obj["doc_type"] = doc_type
                    chunk_errors = validate_payload(obj, doc_id, doc_type)
                    if chunk_errors:
                        raise ValueError("; ".join(chunk_errors))
                    parsed = obj
                    break
                except Exception as exc:  # noqa: BLE001
                    chunk_errors.append(str(exc))
                    if attempt < 2:
                        correction = (
                            "The previous answer was invalid: "
                            + str(exc)
                            + "\nReturn ONLY one valid JSON object matching the schema. "
                            "Use the provided doc_id and doc_type exactly."
                        )
                        prompt = self.build_prompt(doc_id, doc_type, chunk) + "\n\n" + correction
                        status = "repaired"
            if parsed is None:
                status = "fallback"
                errors.extend(chunk_errors)
                parsed = fallback_extract(chunk, doc_id, doc_type)
            payloads.append(parsed)

        merged = self._merge_chunks(payloads, doc_id, doc_type)
        merged, dropped = ground_keywords(merged, text)

        if status == "ok" and dropped:
            # grounding drops are expected; only structural problems count as repairs
            pass

        raw_path = self.raw_dir / f"{doc_id}.txt"
        raw_path.write_text("\n\n-----CHUNK-----\n\n".join(raw_all), encoding="utf-8")

        payload = {
            "doc_id": doc_id,
            "doc_type": doc_type,
            "model": model_used,
            "prompt_hash": self.phash,
            "timestamp": datetime.now().isoformat(timespec="seconds"),
            "elapsed_sec": round(elapsed, 2),
            "status": status,
            "chunk_count": len(chunks),
            "merged_from_chunks": len(chunks) > 1,
            "raw_response": raw_all[0] if raw_all else "",
            "raw_path": str(raw_path.relative_to(self.cfg.root)),
            "parsed": merged,
            "dropped_keywords": dropped,
            "validation_errors": errors,
        }
        cache_path = self.cache.save(doc_id, payload)
        return ExtractionResult(
            doc_id=doc_id,
            doc_type=doc_type,
            status=status,
            payload=merged,
            dropped=dropped,
            elapsed_sec=elapsed,
            model=model_used,
            cache_path=str(cache_path),
            raw_path=str(raw_path.relative_to(self.cfg.root)),
            errors=errors,
        )
