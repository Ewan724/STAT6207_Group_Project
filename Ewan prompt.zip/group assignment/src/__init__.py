"""AI CV Matching baseline - shared source package.

Importing this package makes console output UTF-8 safe on Windows (the default
cp950 console cannot print the middle dots and dashes present in the source
documents).
"""

from __future__ import annotations

import sys


def _setup_console() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:  # pragma: no cover - depends on the host terminal
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:  # pragma: no cover
            pass


_setup_console()

__all__ = ["__version__"]
__version__ = "1.0.0"
