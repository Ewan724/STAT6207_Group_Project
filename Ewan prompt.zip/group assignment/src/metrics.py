"""Metrics: Recall@K (hit rate), Hit@K, MRR, nDCG, Precision@K, Wilson & bootstrap CIs."""

from __future__ import annotations

import math
from typing import Any, Iterable

import numpy as np
import pandas as pd


# --------------------------------------------------------------------------- #
# Per-query metrics
# --------------------------------------------------------------------------- #
def wilson_interval(k: int, n: int, z: float = 1.959963984540054) -> tuple[float, float]:
    """Wilson score interval for a binomial proportion."""
    if n == 0:
        return (0.0, 0.0)
    p = k / n
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = (z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))) / denom
    return (max(0.0, centre - half), min(1.0, centre + half))


def bootstrap_ci(values: Iterable[float], resamples: int = 10000, seed: int = 42, alpha: float = 0.05) -> tuple[float, float]:
    arr = np.asarray(list(values), dtype=float)
    if arr.size == 0:
        return (0.0, 0.0)
    rng = np.random.default_rng(seed)
    idx = rng.integers(0, arr.size, size=(resamples, arr.size))
    means = arr[idx].mean(axis=1)
    lo = float(np.quantile(means, alpha / 2))
    hi = float(np.quantile(means, 1 - alpha / 2))
    return (lo, hi)


def per_query_metrics(
    rankings: pd.DataFrame,
    relevance: pd.DataFrame,
    k_values: tuple[int, ...] = (1, 5, 10),
) -> pd.DataFrame:
    """Compute per-(model, jd) metrics.

    ``relevance`` has columns ``jd_id``, ``cv_id`` (the hired CV).
    """
    rows: list[dict[str, Any]] = []
    rel_map = dict(zip(relevance["jd_id"], relevance["cv_id"]))
    for (model, jd_id), grp in rankings.groupby(["model", "jd_id"], sort=True):
        hired = rel_map.get(jd_id)
        if hired is None:
            continue
        sub = grp[grp["cv_id"] == hired]
        if sub.empty:
            raise ValueError(f"hired CV {hired} missing from rankings for {model}/{jd_id}")
        row = sub.iloc[0]
        rank = int(row["rank"])
        score = float(row["score"])
        top1 = grp.sort_values(["rank"]).iloc[0]
        out: dict[str, Any] = {
            "model": model,
            "jd_id": jd_id,
            "hired_cv_id": hired,
            "rank": rank,
            "score": round(score, 6),
            "top1_cv_id": top1["cv_id"],
            "top1_score": round(float(top1["score"]), 6),
            "score_margin": round(score - float(top1["score"]), 6),
            "reciprocal_rank": round(1.0 / rank if rank <= 10 else 0.0, 6),
            "ndcg_at_10": round(1.0 / math.log2(rank + 1) if rank <= 10 else 0.0, 6),
            "precision_at_10": round(1.0 / 10.0 if rank <= 10 else 0.0, 6),
            "is_relevant_top10": int(rank <= 10),
        }
        for k in k_values:
            out[f"hit_at_{k}"] = int(rank <= k)
        rows.append(out)
    return pd.DataFrame(rows)


def summarise(
    per_query: pd.DataFrame,
    relevance: pd.DataFrame,
    *,
    n_candidates: int,
    bootstrap_resamples: int = 10000,
    seed: int = 42,
) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for model, grp in per_query.groupby("model", sort=True):
        n = len(grp)
        hits10 = int((grp["rank"] <= 10).sum())
        recall10 = hits10 / n if n else 0.0
        w_lo, w_hi = wilson_interval(hits10, n)
        b_lo, b_hi = bootstrap_ci((grp["rank"] <= 10).astype(float).tolist(), bootstrap_resamples, seed)
        # recompute RR / nDCG / precision from the rank so the numbers are not
        # affected by the 6 dp rounding used in the saved per-query table
        ranks = grp["rank"].astype(int).to_numpy()
        rr = np.where(ranks <= 10, 1.0 / ranks, 0.0)
        ndcg = np.where(ranks <= 10, 1.0 / np.log2(ranks + 1.0), 0.0)
        prec = np.where(ranks <= 10, 0.1, 0.0)
        rows.append(
            {
                "model": model,
                "n_queries": n,
                "n_candidates": n_candidates,
                "hits": hits10,
                "recall_at_10": round(recall10, 6),
                "hit_at_1": round(float((grp["rank"] <= 1).mean()), 6),
                "hit_at_5": round(float((grp["rank"] <= 5).mean()), 6),
                "hit_at_10": round(float((grp["rank"] <= 10).mean()), 6),
                "mrr_at_10": round(float(rr.mean()), 6),
                "ndcg_at_10": round(float(ndcg.mean()), 6),
                "precision_at_10": round(float(prec.mean()), 6),
                "median_rank": float(grp["rank"].median()),
                "wilson_ci_low": round(w_lo, 6),
                "wilson_ci_high": round(w_hi, 6),
                "bootstrap_ci_low": round(b_lo, 6),
                "bootstrap_ci_high": round(b_hi, 6),
            }
        )
    return pd.DataFrame(rows)


# --------------------------------------------------------------------------- #
# Random baseline
# --------------------------------------------------------------------------- #
def random_baseline(n_candidates: int, k: int, permutations: int, seed: int = 42) -> dict[str, Any]:
    rng = np.random.default_rng(seed)
    expected = k / n_candidates
    hits = []
    for _ in range(permutations):
        pos = rng.integers(0, n_candidates)  # position of the relevant item
        hits.append(1.0 if pos < k else 0.0)
    arr = np.asarray(hits)
    return {
        "n_candidates": n_candidates,
        "k": k,
        "expected_recall": round(expected, 6),
        "empirical_mean": round(float(arr.mean()), 6),
        "p2_5": round(float(np.quantile(arr, 0.025)), 6),
        "p97_5": round(float(np.quantile(arr, 0.975)), 6),
        "n_permutations": permutations,
    }


# --------------------------------------------------------------------------- #
# Independent recomputation (validation)
# --------------------------------------------------------------------------- #
def recompute_from_rankings(rankings: pd.DataFrame, relevance: pd.DataFrame) -> pd.DataFrame:
    """Recompute Recall@10 / Hit@1 / Hit@5 / MRR@10 straight from rankings.csv."""
    rows: list[dict[str, Any]] = []
    rel_map = dict(zip(relevance["jd_id"], relevance["cv_id"]))
    for model, grp in rankings.groupby("model"):
        jds = grp["jd_id"].unique()
        hits = 0
        hit1 = hit5 = 0
        rr = []
        for jd in jds:
            hired = rel_map[jd]
            sub = grp[(grp["jd_id"] == jd) & (grp["cv_id"] == hired)]
            if sub.empty:
                raise ValueError(f"missing hired CV row: {model}/{jd}")
            rank = int(sub.iloc[0]["rank"])
            if rank <= 10:
                hits += 1
                rr.append(1.0 / rank)
            else:
                rr.append(0.0)
            hit1 += int(rank == 1)
            hit5 += int(rank <= 5)
        n = len(jds)
        rows.append(
            {
                "model": model,
                "n_queries": n,
                "hits_at_10": hits,
                "recall_at_10": round(hits / n, 6),
                "hit_at_1": round(hit1 / n, 6),
                "hit_at_5": round(hit5 / n, 6),
                "mrr_at_10": round(float(np.mean(rr)), 6),
            }
        )
    return pd.DataFrame(rows)


def assert_close(a: float, b: float, tol: float = 1e-9) -> bool:
    return abs(float(a) - float(b)) <= tol
