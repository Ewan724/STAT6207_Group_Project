"""Logging helpers: one log file per stage plus console output."""

from __future__ import annotations

import logging
import sys
from pathlib import Path

_FMT = "%(asctime)s | %(levelname)-7s | %(name)-18s | %(message)s"
_DATE = "%H:%M:%S"
_CONFIGURED: set[str] = set()


def get_logger(name: str, log_dir: Path | None = None, quiet: bool = False) -> logging.Logger:
    logger = logging.getLogger(name)
    key = f"{name}|{log_dir}"
    if key in _CONFIGURED:
        return logger

    logger.setLevel(logging.INFO)
    logger.propagate = False
    fmt = logging.Formatter(_FMT, datefmt=_DATE)

    if not quiet:
        sh = logging.StreamHandler(sys.stdout)
        sh.setFormatter(fmt)
        sh.setLevel(logging.INFO)
        logger.addHandler(sh)

    if log_dir is not None:
        log_dir = Path(log_dir)
        log_dir.mkdir(parents=True, exist_ok=True)
        fh = logging.FileHandler(log_dir / f"{name}.log", mode="a", encoding="utf-8")
        fh.setFormatter(fmt)
        fh.setLevel(logging.DEBUG)
        logger.addHandler(fh)

    _CONFIGURED.add(key)
    return logger


def banner(logger: logging.Logger, title: str) -> None:
    line = "=" * 78
    logger.info(line)
    logger.info(title)
    logger.info(line)
