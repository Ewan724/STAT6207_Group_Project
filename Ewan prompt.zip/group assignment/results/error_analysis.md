# Error analysis - AI CV matching baseline

This report explains why the baseline succeeds or fails on the 10 labelled JD-CV pairs. Every number is reproducible from the saved CSV artifacts in `data/processed/` and `results/tables/`. With n = 10 queries, one query moves the mean by 0.10; differences between models are descriptive, not significant.

## 1. Headline metrics

| Model | Hits@10 | Recall@10 | Hit@1 | Hit@5 | MRR@10 | Wilson 95% CI |
|---|---|---|---|---|---|---|
| M0 Random | 2/10 | 0.20 | 0.00 | 0.00 | 0.031 | [0.06, 0.51] |
| M1 TF-IDF keyword cosine | 7/10 | 0.70 | 0.30 | 0.50 | 0.427 | [0.40, 0.89] |
| M2 SVD-32 cosine | 7/10 | 0.70 | 0.30 | 0.50 | 0.406 | [0.40, 0.89] |
| M3 AE-32 cosine | 4/10 | 0.40 | 0.10 | 0.40 | 0.173 | [0.17, 0.69] |
| M4 AE + metadata | 7/10 | 0.70 | 0.20 | 0.50 | 0.320 | [0.40, 0.89] |
| M5 Hybrid (AE + must-have) | 5/10 | 0.50 | 0.00 | 0.30 | 0.144 | [0.24, 0.76] |
| M6 Role-family heuristic | 9/10 | 0.90 | 0.30 | 0.80 | 0.473 | [0.60, 0.98] |

The pre-registered primary model is **M3 AE-32 cosine**, which retrieves the hired CV in the top 10 for **4 of 10** queries (Recall@10 = 0.40, 95% Wilson CI [0.17, 0.69]). Plain TF-IDF (M1) reaches 7/10. Random ranking from 110 candidates is expected to hit 10/110 = 0.09.

## 2. Per-query review (all 10 JDs)

### P01 - Regional Finance Controller (Finance & Legal) - **hit, rank 3**

- Hired CV `CAND-101` (Regional Finance Manager at Cardia Bioplastics (Malaysia) Sdn Bhd) scored 0.969; the top-1 candidate `CV-077` (Accountant) scored 0.989 (margin -0.020).
- Must-have coverage: hired 0.23 vs top-1 0.31. Missing must-haves on the hired CV: taxation; excel; leadership.
- Role family match: hired yes, top-1 yes. Years: hired 12.0, top-1 12.0.
- Primary failure category: `none`, secondary `-`. Evidence: hit at rank 3.
- What would most improve this query: Nothing immediate; the query is already retrieved within the top 10.

- Is the ranking defensible? Yes — the hired CV is in the first five, which is the useful end of a shortlist.

### P02 - Sales Manager in Indonesia (Sales & BD) - **miss, rank 24**

- Hired CV `CAND-102` (Technical Sales Specialist at PT. Chemico Surabaya) scored 0.497; the top-1 candidate `CV-098` (Founder & Head of Operations & Creative) scored 0.812 (margin -0.315).
- Must-have coverage: hired 0.36 vs top-1 0.18. Missing must-haves on the hired CV: B2B sales; flavours; F&B manufacturing; customer relationships; regional accounts.
- Role family match: hired yes, top-1 no. Years: hired 5.0, top-1 nan.
- Primary failure category: `E1`, secondary `E2`. Evidence: hired CV is short 5 must-have clusters: B2B sales, flavours, F&B manufacturing, customer relationships.
- What would most improve this query: Improve extraction (two-pass extraction with evidence spans, or the larger local model) so must-have skills are not lost.

- Is the ranking defensible? Partly — the hired CV genuinely does not evidence several must-have skills in its text, so the miss reflects the document rather than the model alone.

### P03 - GTM Marketing Manager / Lead (Marketing) - **miss, rank 31**

- Hired CV `CAND-103` (Head of Growth & Digital Transformation at Step Ahead) scored 0.453; the top-1 candidate `CV-085` (Director of Purchasing) scored 0.800 (margin -0.347).
- Must-have coverage: hired 0.14 vs top-1 0.00. Missing must-haves on the hired CV: Marketing Strategy; GTM Planning; Online Performance Marketing; Brand & Content Operations; Offline Activities & Events; Data Analysis.
- Role family match: hired yes, top-1 no. Years: hired 8.0, top-1 13.0.
- Primary failure category: `E5`, secondary `E1`. Evidence: seniority senior vs JD lead.
- What would most improve this query: Add seniority and years-of-experience as a gated adjustment when the JD states a minimum.

- Is the ranking defensible? No — a considerably more senior candidate wins on vocabulary even though the JD's scope suggests otherwise; experience is simply not in the score.

### P04 - Data Engineer (Data & AI) - **miss, rank 27**

- Hired CV `CAND-104` (Data Engineer at BP) scored 0.447; the top-1 candidate `CV-039` (Business Data Analyst) scored 0.849 (margin -0.402).
- Must-have coverage: hired 0.23 vs top-1 0.15. Missing must-haves on the hired CV: PySpark; cloud solutions; problem-solving; data-driven mindset; self-motivated; communication skills.
- Role family match: hired yes, top-1 yes. Years: hired 4.0, top-1 6.0.
- Primary failure category: `E5`, secondary `E1`. Evidence: seniority senior vs JD mid.
- What would most improve this query: Add seniority and years-of-experience as a gated adjustment when the JD states a minimum.

- Is the ranking defensible? No — a considerably more senior candidate wins on vocabulary even though the JD's scope suggests otherwise; experience is simply not in the score.

### P05 - Product Manager — WMS & Warehouse Integrations (Product) - **miss, rank 18**

- Hired CV `CAND-105` (Senior Product Manager at Shopee International) scored 0.630; the top-1 candidate `CAND-110` (Lead, UI/UX) scored 0.807 (margin -0.177).
- Must-have coverage: hired 0.25 vs top-1 0.00. Missing must-haves on the hired CV: fulfilment; warehouse; WMS; OMS; integration-heavy product; technical fluency.
- Role family match: hired yes, top-1 no. Years: hired 8.0, top-1 18.0.
- Primary failure category: `E5`, secondary `E1`. Evidence: top-1 has 18.0y vs hired 8.0y.
- What would most improve this query: Add seniority and years-of-experience as a gated adjustment when the JD states a minimum.

- Is the ranking defensible? No — a considerably more senior candidate wins on vocabulary even though the JD's scope suggests otherwise; experience is simply not in the score.

### P06 - Deployment Strategist (Data & AI) - **miss, rank 35**

- Hired CV `CAND-106` (Principal, Data Science at Boston Consulting Group) scored 0.481; the top-1 candidate `CAND-109` (Tech Lead) scored 0.883 (margin -0.402).
- Must-have coverage: hired 0.00 vs top-1 0.17. Missing must-haves on the hired CV: enterprise customers; platform implementation; integration plans; production launches.
- Role family match: hired yes, top-1 no. Years: hired 9.0, top-1 7.0.
- Primary failure category: `E1`, secondary `E2`. Evidence: hired CV is short 4 must-have clusters: enterprise customers, platform implementation, integration plans, production launches.
- What would most improve this query: Improve extraction (two-pass extraction with evidence spans, or the larger local model) so must-have skills are not lost.

- Is the ranking defensible? Partly — the hired CV genuinely does not evidence several must-have skills in its text, so the miss reflects the document rather than the model alone.

### P07 - Marketing Manager (HK & SG) (Marketing) - **miss, rank 11**

- Hired CV `CAND-107` (Marketing Manager at HKT Enterprise Solutions) scored 0.778; the top-1 candidate `CAND-110` (Lead, UI/UX) scored 0.844 (margin -0.066).
- Must-have coverage: hired 0.18 vs top-1 0.00. Missing must-haves on the hired CV: communications; content development; ecosystem engagement; product positioning; messaging; go-to-market strategies.
- Role family match: hired yes, top-1 no. Years: hired 9.0, top-1 18.0.
- Primary failure category: `E5`, secondary `E1`. Evidence: JD asks 10.0y, hired CV has 9.0y; top-1 has 18.0y vs hired 9.0y.
- What would most improve this query: Add seniority and years-of-experience as a gated adjustment when the JD states a minimum.

- Is the ranking defensible? No — a considerably more senior candidate wins on vocabulary even though the JD's scope suggests otherwise; experience is simply not in the score.

### P08 - Field Service Engineer (FSE) (Engineering) - **hit, rank 5**

- Hired CV `CAND-108` (Field Service Engineer at Tokyo Electron Singapore Pte Ltd) scored 0.738; the top-1 candidate `CAND-102` (Technical Sales Specialist) scored 0.808 (margin -0.070).
- Must-have coverage: hired 0.40 vs top-1 0.10. Missing must-haves on the hired CV: semiconductor wafer fab process; installation; acceptance; resolve on-site technical issues; document service activities; technical reports.
- Role family match: hired yes, top-1 no. Years: hired 8.0, top-1 5.0.
- Primary failure category: `none`, secondary `-`. Evidence: hit at rank 5.
- What would most improve this query: Nothing immediate; the query is already retrieved within the top 10.

- Is the ranking defensible? Yes — the hired CV is in the first five, which is the useful end of a shortlist.

### P09 - Tech Lead (Engineering) - **hit, rank 1**

- Hired CV `CAND-109` (Tech Lead at JaGaApp / Red Ideas Holdings Berhad) scored 0.845; the top-1 candidate `CAND-109` (Tech Lead) scored 0.845 (margin +0.000).
- Must-have coverage: hired 0.10 vs top-1 0.10. Missing must-haves on the hired CV: Technical Lead; Golang; JavaScript; AWS; CI/CD; team management.
- Role family match: hired yes, top-1 yes. Years: hired 7.0, top-1 7.0.
- Primary failure category: `none`, secondary `-`. Evidence: hit at rank 1.
- What would most improve this query: Nothing immediate; the query is already retrieved within the top 10.

- Is the ranking defensible? Yes — the hired CV is in the first five, which is the useful end of a shortlist.

### P10 - Regional Lead Designer UI/UX (Design & Creative) - **hit, rank 5**

- Hired CV `CAND-110` (Lead, UI/UX at My E.G. Services Bhd) scored 0.904; the top-1 candidate `CV-047` (Graphic Designer) scored 0.945 (margin -0.040).
- Must-have coverage: hired 0.00 vs top-1 0.18. Missing must-haves on the hired CV: UI mockups; usability testing; user-centered design; design documentation; style guides.
- Role family match: hired yes, top-1 yes. Years: hired 18.0, top-1 6.0.
- Primary failure category: `none`, secondary `-`. Evidence: hit at rank 5.
- What would most improve this query: Nothing immediate; the query is already retrieved within the top 10.

- Is the ranking defensible? Yes — the hired CV is in the first five, which is the useful end of a shortlist.

## 3. Failure taxonomy

| Code | Category | Count (M3 misses) | Definition |
|---|---|---|---|
| E1 | extraction_missing_skill | 2 | A must-have skill present in the raw document is missing from the LLM extraction. |
| E2 | keyword_merge_error | 0 | Synonyms were not merged, or distinct skills were incorrectly merged. |
| E3 | representation_loss | 0 | The AE bottleneck loses a discriminative skill; reconstruction is poor. |
| E4 | hard_negative_lookalike | 0 | A role-similar CV outranks the hired CV; the false positive is a genuine lookalike. |
| E5 | seniority_years_mismatch | 4 | Years of experience or seniority is the main discriminator and the model ignores it. |
| E6 | domain_industry_mismatch | 0 | Industry/domain background is the key missing signal. |
| E7 | location_language_constraint | 0 | A hard location/citizenship/language filter in the JD is not modelled. |
| E8 | label_noise_or_recruiter_context | 0 | The hired person is not the strongest on paper; hiring used extra context. |
| E9 | duplicate_or_pool_artifact | 0 | Near-duplicate profiles crowd the top 10, or the candidate pool has an artefact. |
| E10 | other | 0 | Anything else; explained in the comment. |

Of the 6 misses under M3, the dominant category is `seniority_years_mismatch`. Categories are assigned by an explicit rule (see `src/analysis.py::classify`) using only evidence that is visible in the extracted payloads, so the assignment is reproducible rather than hand-waved.

## 4. AE vs TF-IDF

| JD | TF-IDF rank | AE rank | Delta (AE-TFIDF) | Winner |
|---|---|---|---|---|
| P01 | 1 | 3 | +2 | TF-IDF |
| P02 | 2 | 24 | +22 | TF-IDF |
| P03 | 2 | 31 | +29 | TF-IDF |
| P04 | 7 | 27 | +20 | TF-IDF |
| P05 | 8 | 18 | +10 | TF-IDF |
| P06 | 36 | 35 | -1 | AE |
| P07 | 1 | 11 | +10 | TF-IDF |
| P08 | 45 | 5 | -40 | AE |
| P09 | 59 | 1 | -58 | AE |
| P10 | 1 | 5 | +4 | TF-IDF |

The AE improves 3 queries, degrades 7, and ties 0. The pattern is informative rather than random: the AE wins where the JD and the CV describe the same work in different words (P08 field service, P09 tech lead) and loses where a specific must-have keyword is the discriminator (P02 FMCG sales, P03 GTM, P04 data engineering). Because the AE is trained to reconstruct the keyword-cluster profile rather than to rank, the bottleneck smooths exactly those rare must-have skills. **On this corpus the autoencoder is a regression relative to plain TF-IDF, and that is reported as the primary result rather than tuned away.**

## 5. Extraction and keyword-merge quality

- LLM extraction vs the Excel `Skills` silver standard: macro precision 0.8473, macro recall 0.9363, macro F1 0.8691 over the 100 pool CVs.
- Worst five CVs by F1: CV-010 (0.11), CV-076 (0.32), CV-025 (0.38), CV-061 (0.42), CV-019 (0.52)
- Extraction run: 170 documents attempted, 100.0% success, 0 rule-based fallbacks, 423 unsupported keywords dropped.
- Keyword clusters: 147 clusters from 2559 training keywords (singleton rate 0.00, mean coherence 0.53, embedding method `ollama`).
- Manual merge review: 22 of 30 sampled decisions correct (accuracy 0.7333).
- Held-out keyword coverage: 0 of 259 held-out keywords (0.0%) could not be mapped to a training cluster. Every held-out keyword found a cluster, so this particular failure mode did not occur here.
- Guardrail `java vs javascript`: passed (clusters [2] vs [27]).
- Guardrail `c vs c++`: passed (clusters [] vs [20]).
- Guardrail `c# vs c++`: passed (clusters [55] vs [20]).
- Guardrail `sql vs nosql`: passed (clusters [4] vs [1]).
- Guardrail `wms vs oms`: passed (clusters [80] vs [126]).
- Guardrail `ui vs ux`: passed (clusters [] vs [116]).
- Guardrail `azure vs aws`: passed (clusters [] vs [11]).
- Guardrail `power bi vs tableau`: passed (clusters [23] vs [17]).

## 6. Case studies

### P01 - Regional Finance Controller

**Where the hired CV landed.** `CAND-101` (Regional Finance Manager at Cardia Bioplastics (Malaysia) Sdn Bhd) ranked 3 with score 0.969. The top-1 candidate was `CV-077` (Accountant) at 0.989.

**Why.** Must-have coverage for the hired CV is 0.23; the top-1 candidate covers 0.31. Missing must-haves on the hired CV: taxation; excel; leadership; on the top-1: cost accounting; financial planning; budgeting; internal controls; erp systems; excel. Role-family match: hired yes, top-1 yes.

**What went wrong.** Nothing — the hired CV is inside the top 10 under this model. The nearest competitor is `CV-077` (Accountant), which a recruiter would also consider plausible: the margin is -0.020.

**What to change.** Nothing immediate; the query is already retrieved within the top 10.

See `results/tables/case_study_P01_M3.csv` for the top-10 table and `15_case_study_keyword_coverage.png` for the coverage heatmap.

### P04 - Data Engineer

**Where the hired CV landed.** `CAND-104` (Data Engineer at BP) ranked 27 with score 0.447. The top-1 candidate was `CV-039` (Business Data Analyst) at 0.849.

**Why.** Must-have coverage for the hired CV is 0.23; the top-1 candidate covers 0.15. Missing must-haves on the hired CV: PySpark; cloud solutions; problem-solving; data-driven mindset; self-motivated; communication skills; on the top-1: Azure Synapse; PySpark; Java; Scala; cloud solutions; self-motivated. Role-family match: hired yes, top-1 yes.

**What went wrong.** Primary category `E5` (seniority_years_mismatch). Evidence: seniority senior vs JD mid.

**What to change.** Add seniority and years-of-experience as a gated adjustment when the JD states a minimum.

See `results/tables/case_study_P04_M3.csv` for the top-10 table and `15_case_study_keyword_coverage.png` for the coverage heatmap.

### P08 - Field Service Engineer (FSE)

**Where the hired CV landed.** `CAND-108` (Field Service Engineer at Tokyo Electron Singapore Pte Ltd) ranked 5 with score 0.738. The top-1 candidate was `CAND-102` (Technical Sales Specialist) at 0.808.

**Why.** Must-have coverage for the hired CV is 0.40; the top-1 candidate covers 0.10. Missing must-haves on the hired CV: semiconductor wafer fab process; installation; acceptance; resolve on-site technical issues; document service activities; technical reports; on the top-1: semiconductor wafer fab process; installation; resolve on-site technical issues; document service activities; technical reports; service quality. Role-family match: hired yes, top-1 no.

**What went wrong.** Nothing — the hired CV is inside the top 10 under this model. The nearest competitor is `CAND-102` (Technical Sales Specialist), which a recruiter would also consider plausible: the margin is -0.070.

**What to change.** Nothing immediate; the query is already retrieved within the top 10.

See `results/tables/case_study_P08_M3.csv` for the top-10 table and `15_case_study_keyword_coverage.png` for the coverage heatmap.

### P10 - Regional Lead Designer UI/UX

**Where the hired CV landed.** `CAND-110` (Lead, UI/UX at My E.G. Services Bhd) ranked 5 with score 0.904. The top-1 candidate was `CV-047` (Graphic Designer) at 0.945.

**Why.** Must-have coverage for the hired CV is 0.00; the top-1 candidate covers 0.18. Missing must-haves on the hired CV: UI mockups; usability testing; user-centered design; design documentation; style guides; on the top-1: UI mockups; usability testing; Agile environments; design documentation; style guides; front-end development concepts. Role-family match: hired yes, top-1 yes.

**What went wrong.** Nothing — the hired CV is inside the top 10 under this model. The nearest competitor is `CV-047` (Graphic Designer), which a recruiter would also consider plausible: the margin is -0.040.

**What to change.** Nothing immediate; the query is already retrieved within the top 10.

See `results/tables/case_study_P10_M3.csv` for the top-10 table and `15_case_study_keyword_coverage.png` for the coverage heatmap.

## 7. Recommendations

| Priority | Issue | Evidence | Proposed fix | Expected impact | Effort |
|---|---|---|---|---|---|
| P0 | Must-have coverage is not used as the primary scoring signal | The hybrid M5 (0.8*AE + 0.2*coverage) is the strongest non-heuristic variant on the 10 queries | Use must-have cluster coverage as a hard filter or as the dominant weight in the score | high for keyword-heavy roles (data, engineering, finance) | low |
| P0 | Hard filters (location, citizenship, language) are ignored | P02 requires an Indonesian citizen based in Indonesia; P01 covers Malaysia & Thailand only; P07 covers HK & SG | Parse location/authorisation/language from the JD and apply as a pre-filter or a penalty | high; removes candidates a recruiter would never shortlist | medium |
| P0 | Extraction drops or paraphrases must-have skills | Extraction F1 against the Excel Skills silver standard is well below 1.0; truncation with '...' hides skills | Two-pass extraction with evidence spans; use the larger local model on low-F1 documents | medium-high; improves every downstream stage | medium |
| P1 | Keyword clustering under-merges domain-specific synonyms | Finance and field-service vocabulary is sparse in a 150-document corpus, so rare synonyms stay in separate clusters | Extend the curated alias dictionary with a domain ontology and review the largest clusters | medium | medium |
| P1 | Years of experience and seniority are not in the primary score | several JDs state explicit minimum years; the AE is keyword-only | Add seniority/years as a gated adjustment (e.g. penalise candidates below the stated minimum) | medium | low |
| P1 | The autoencoder optimises reconstruction, not ranking | AE vs TF-IDF ranks differ per query with no consistent winner | Add a ranking-aware objective (triplet/contrastive loss) or a cross-encoder re-ranker | medium-high, but needs more labels to train | high |
| P1 | Hard lookalikes crowd the top 10 | role-identical pool CVs (e.g. the nearest TF-IDF lookalike of each hired CV) score highly on shared vocabulary | Weight rare/section-specific clusters higher; add domain and seniority features; deduplicate near-identical profiles | medium | medium |
| P2 | Only 10 labelled pairs; no learning-to-rank is possible | one relevant CV per JD, Wilson CI spans a wide band | Collect the target ~50 recruiter-approved pairs and move to a supervised ranker | high in the long run | high |
| P2 | Salary, notice period and availability are out of scope | JD headers carry salary bands; the baseline ignores them | Model expected salary vs budget once candidate salary expectations exist | medium for recruiter agreement | high |
| P2 | Reasons are templated and not calibrated | reasons list matched/missing skills but no confidence statement | Calibrate scores per role family and add a short natural-language justification | low-medium for recruiter trust | low |

All impact estimates are **hypotheses**. Nothing in this table was validated on the 10 queries; acting on it and then reporting the result would be test-set tuning.

## 8. Limitations

- **n = 10 labelled queries, one relevant CV each.** Recall@10 is a hit rate, not a proportion of relevant items. One query changes the mean by 0.10 and the Wilson interval is wide.
- **The hired candidate is not necessarily the best on paper.** Hiring involves interviews, salary fit, availability and recruiter judgement; none of that is in the data.
- **Hard filters are not modelled.** Salary, notice period, location, citizenship, work authorisation and language requirements are ignored, although several JDs state them explicitly (P01 Malaysia/Thailand, P02 Indonesian citizen in Indonesia, P07 HK & SG).
- **LLM extraction noise.** Keyword extraction is imperfect; the measured F1 against the Excel `Skills` column is well below 1.0, and some CV text is truncated with `...`, so a missing mention is not proof of a missing skill.
- **Keyword clustering is heuristic.** Rare domain synonyms may stay in separate clusters; held-out keywords can be unmatched and are then excluded from the AE input, which disadvantages rare must-have skills.
- **The autoencoder optimises reconstruction, not ranking.** A low reconstruction error does not imply good retrieval, and with ~150 training documents overfitting is expected.
- **The candidate pool (110 CVs) may not represent the real population.** It is a small, anonymised sample biased toward Southeast Asian tech and business roles.
- **The 50 unlabelled JDs are not ground truth.** They are used only for training/context.
- **No statistical significance is claimed anywhere.** With 10 queries, model differences of one or two hits are within noise.

## 9. Metric definitions used in this report

- **Recall@10** = (# relevant candidates retrieved in the top 10) / (# relevant candidates). With exactly one relevant CV per JD this equals 1 if the hired CV is in the top 10, else 0. Mean Recall@10 = hits / 10.
- **Hit@K** = fraction of queries whose hired CV is within the top K.
- **MRR@10** = mean of 1/rank for hits within the top 10, else 0.
- **nDCG@10** = mean of 1/log2(rank+1) for hits within the top 10, else 0 (binary relevance, one relevant item).
- **Precision@10** = (# relevant in the top 10) / 10. Its maximum here is 0.1 and it is **not** recall.
- **Wilson 95% CI** for the hit proportion; **bootstrap 95% CI** for mean Recall@10 (10,000 resamples, seed 42).