"""AI CV Matching - Baseline Results.

Streamlit entry point. Run from the project root:

    py -m streamlit run "app.py"

The app is fully offline: it reads only files under this folder and contacts no
network service. If an artifact is missing it says which stage to run instead of
raising a traceback.
"""

from __future__ import annotations

import sys
from pathlib import Path

import streamlit as st

sys.path.insert(0, str(Path(__file__).resolve().parent))

from src.overview import render  # noqa: E402
from src.web import apply_style, footer, sidebar  # noqa: E402

st.set_page_config(page_title="AI CV Matching — Baseline", layout="wide")
apply_style()
sidebar()
render()
footer()
