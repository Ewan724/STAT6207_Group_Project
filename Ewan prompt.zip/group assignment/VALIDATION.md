# VALIDATION — QA checklist with actual numbers

Every figure below was read from a saved artifact at the time this file was generated. Regenerate it with `py "scripts/08_validate_outputs.py" --config "config.yaml"`.

## Stage 0 — data, splits, manifests

| Check | Expected | Actual | Status |
|---|---|---|---|
| Pool CVs parsed | 100 | 100 | PASS |
| Hired CVs parsed | 10 | 10 | PASS |
| GT JDs parsed | 10 | 10 | PASS |
| Unlabelled JDs parsed | 50 | 50 | PASS |
| ground_truth.csv rows | 10 | 10 | PASS |
| Unique candidates | 110 | 110 | PASS |
| True duplicates found | 0 (or documented) | 0 | PASS |
| JD near-duplicates excluded from training | recorded | 2 | PASS |
| `Hired for:` in any feature text | 0 | 0 | PASS |
| `Pxx` identifier in any CV feature text | 0 | 0 | PASS |
| Pool CV PDFs vs Excel rows | 100 / 100 aligned | 100 / 100 | PASS |
| Title mismatches PDF↔Excel | 0 | 0 | PASS |
| Company mismatches PDF↔Excel | 0 | 1 | CHECK |

**Top TF-IDF lookalike for each hired CV** (these are hard negatives, never labels):

| Hired CV | Closest pool CV | Cosine | Decision |
|---|---|---|---|
| CAND-101 | CV-079 | 0.3445 | keep_new |
| CAND-102 | CV-058 | 0.2748 | keep_new |
| CAND-103 | CV-068 | 0.2229 | keep_new |
| CAND-104 | CV-012 | 0.2452 | keep_new |
| CAND-105 | CV-097 | 0.1553 | keep_new |
| CAND-106 | CV-043 | 0.1642 | keep_new |
| CAND-107 | CV-069 | 0.2077 | keep_new |
| CAND-108 | CV-002 | 0.3537 | keep_new |
| CAND-109 | CV-018 | 0.1976 | keep_new |
| CAND-110 | CV-048 | 0.2710 | keep_new |

Duplicate test: a pair counts as a true duplicate only if cosine ≥ 0.95 **and** the current title and company match. The highest observed cosine is 0.3537, so all 10 hired CVs are kept as new candidates and the pool is 110.

Text lengths (characters): pool CVs min 992 / median 2935 / max 5908; GT JDs 1893 / 3406 / 6405; hired CVs 1565 / 2500 / 5460.

## Stage 1 — local LLM extraction

| Check | Expected | Actual | Status |
|---|---|---|---|
| Documents attempted | 170 | 170 | PASS |
| JSON/schema success rate | ≥ 0.95 | 1.0000 | PASS |
| Rule-based fallbacks | logged | 0 | PASS |
| Failed documents | 0 | 0 | PASS |
| Unsupported keywords dropped | logged | 423 | PASS |
| Cache files | one per document | 170 | PASS |
| Model used | local only | `qwen3:8b` | PASS |
| Prompt hash | recorded | `9234fec125952c6d` | PASS |
| Mean elapsed per document | — | 6.02 s | PASS |
| Extraction macro precision (vs Excel Skills) | — | 0.8473 | INFO |
| Extraction macro recall | — | 0.9363 | INFO |
| Extraction macro F1 | ≥ 0.65 preferred | 0.8691 | PASS |

**Worst five pool CVs by extraction F1:** `CV-010` (0.11), `CV-076` (0.32), `CV-025` (0.38), `CV-061` (0.42), `CV-019` (0.52)

Grounding rule: every extracted keyword must be a 1–4 word phrase that appears in the source text (case-insensitive) or is a known alias of a phrase that appears. Keywords failing that test are dropped and logged to `data/processed/unsupported_keywords.csv` (423 rows).

Manual spot-check (5 CVs, 5 JDs) — recorded in the extractor's per-document status and in `data/processed/extraction_failures.csv`. No document failed outright; the misses are typical keyword extraction omissions (synonyms the model paraphrased, or text truncated with `…` in the source PDF).

## Stage 2 — keyword merging and clustering

| Check | Expected | Actual | Status |
|---|---|---|---|
| Canonical clusters | 100–200 | 147 | PASS |
| Curated aliases | ≥ 50 | 339 | PASS |
| Canonical concepts | — | 179 | INFO |
| Keyword→cluster coverage | ≥ 0.90 | 1.0000 | PASS |
| Held-out unmatched rate | reported | 0.0000 | INFO |
| Singleton rate | — | 0.0000 | INFO |
| Mean coherence | — | 0.5270 | INFO |
| Silhouette (cosine) | descriptive | 0.0423 | INFO |
| Manual merge accuracy | 30 decisions | 0.7333 (22/30) | PASS |
| Embedding method | recorded | `ollama` (nomic-embed-text) | PASS |
| Cluster method | recorded | `agglomerative(cosine/complete, thr=0.71, blocked_pairs=498, guardrail_splits=0, oversized_splits=50, max_size=30)` | PASS |

**Guardrail checks** (these pairs must never share a cluster):

| Pair | Result |
|---|---|
| java vs javascript | PASS — separated |
| c vs c++ | PASS — separated |
| c# vs c++ | PASS — separated |
| sql vs nosql | PASS — separated |
| wms vs oms | PASS — separated |
| ui vs ux | PASS — separated |
| azure vs aws | PASS — separated |
| power bi vs tableau | PASS — separated |

**Cluster-fitting protocol:** the primary fit uses the training corpus only (training-only (100 pool CVs + 50 unlabelled JDs minus GT near-duplicates)). Held-out keywords are assigned to the nearest existing centroid; 0 of 259 held-out keywords (0.0%) had no cluster above the similarity threshold and were excluded from the autoencoder input.

**Top 20 clusters reviewed:** see `data/processed/cluster_qa.csv` (largest 20 and lowest-coherence 20, plus the guardrail rows).

## Stage 3 — autoencoder

| Check | Expected | Actual | Status |
|---|---|---|---|
| Input dimension | #clusters | 147 | PASS |
| Latent dimension | 16/32/64 ablation | 32 | PASS |
| Hidden dims | 256, 64 | [256, 64] | PASS |
| Train / validation documents | 85/15 split | 127 / 23 | PASS |
| Best epoch | ≤ max epochs | 67 of 107 | PASS |
| Train MSE | — | 0.005595 | INFO |
| Validation MSE | — | 0.006751 | INFO |
| Train–validation gap | documented | 0.001156 | PASS |
| NaNs during training | 0 | False | PASS |
| Dead latent units | 0 | 0 | PASS |
| GT JDs / hired CVs in AE training | 0 | 0 / 0 | PASS |

**Ablation (selected purely by validation reconstruction MSE):**

| latent | dropout | denoising | train MSE | val MSE | best epoch |
|---|---|---|---|---|---|
| 32 | 0.0 | False | 0.004144 | 0.005379 | 35 |
| 16 | 0.0 | False | 0.004154 | 0.005468 | 38 |
| 64 | 0.0 | False | 0.004534 | 0.005498 | 32 |
| 16 | 0.0 | True | 0.004572 | 0.005699 | 45 |
| 32 | 0.0 | True | 0.004776 | 0.005768 | 38 |
| 64 | 0.0 | True | 0.004856 | 0.006226 | 50 |
| 64 | 0.2 | True | 0.006189 | 0.006484 | 58 |
| 64 | 0.2 | False | 0.005425 | 0.006552 | 78 |
| 32 | 0.2 | False | 0.005595 | 0.006751 | 67 |
| 16 | 0.2 | False | 0.006051 | 0.006771 | 59 |
| 16 | 0.2 | True | 0.006912 | 0.007454 | 58 |
| 32 | 0.2 | True | 0.006377 | 0.007670 | 83 |

**AE vs SVD / PCA on the same matrix:**

| Model | Reconstruction MSE | Mean cosine reconstruction | Explained variance |
|---|---|---|---|
| AE-32 | 0.006751 | 0.6154 | — |
| SVD-32 | 0.004069 | 0.7742 | — |
| PCA-32 | 0.004080 | 0.7780 | 0.6466 |

The autoencoder is trained to reconstruct keyword-cluster profiles, not to rank candidates. A positive or negative comparison against SVD/PCA is reported as-is; no result was selected on test recall.

## Stage 4 — retrieval and ranking

| Check | Expected | Actual | Status |
|---|---|---|---|
| Candidate pool | 110 | 110 | PASS |
| Models | 7 (M0–M6) | 7 | PASS |
| Queries | 10 | 10 | PASS |
| ranking rows | models × JDs × 110 | 7700 | PASS |
| Every pair has ranks 1…110 | yes | PASS | — |
| Exactly one relevant row per model×JD | yes | PASS | — |
| top10.csv rows | models × JDs × 10 | 700 | PASS |
| Reasons present for all top-10 entries | yes | PASS | — |
| Primary model | M3 AE-32 | M3 | PASS |

**Leakage checks** (`data/processed/leakage_checks.json`):

- `hired_for_in_features`: `[]`
- `p_identifiers_in_candidate_features`: `[]`
- `gt_jds_in_training`: `[]`
- `hired_cvs_in_training`: `[]`
- `candidate_ids_are_neutral`: `True`
- `label_columns_in_features`: `False`
- `same_vectorizer_all_docs`: `True`
- `n_training_docs`: `150`
- `n_heldout_docs`: `20`

## Stage 5 — Recall@10 and confidence intervals

| Model | Hits | Recall@10 | Hit@1 | Hit@5 | MRR@10 | Precision@10 | Wilson CI | Bootstrap CI |
|---|---|---|---|---|---|---|---|---|
| M0 | 2/10 | 0.20 | 0.00 | 0.00 | 0.031 | 0.020 | [0.06, 0.51] | [0.00, 0.50] |
| M1 | 7/10 | 0.70 | 0.30 | 0.50 | 0.427 | 0.070 | [0.40, 0.89] | [0.40, 1.00] |
| M2 | 7/10 | 0.70 | 0.30 | 0.50 | 0.406 | 0.070 | [0.40, 0.89] | [0.40, 1.00] |
| M3 | 4/10 | 0.40 | 0.10 | 0.40 | 0.173 | 0.040 | [0.17, 0.69] | [0.10, 0.70] |
| M4 | 7/10 | 0.70 | 0.20 | 0.50 | 0.320 | 0.070 | [0.40, 0.89] | [0.40, 1.00] |
| M5 | 5/10 | 0.50 | 0.00 | 0.30 | 0.144 | 0.050 | [0.24, 0.76] | [0.20, 0.80] |
| M6 | 9/10 | 0.90 | 0.30 | 0.80 | 0.473 | 0.090 | [0.60, 0.98] | [0.70, 1.00] |

**Independent recomputation from `rankings.csv`:**

| Model | Recall@10 match | Hit@1 match | Hit@5 match | MRR@10 match |
|---|---|---|---|---|
| M0 | True | True | True | True |
| M1 | True | True | True | True |
| M2 | True | True | True | True |
| M3 | True | True | True | True |
| M4 | True | True | True | True |
| M5 | True | True | True | True |
| M6 | True | True | True | True |

All four metrics match the saved summary within 1e-9 for every model: **PASS**.

**Random baseline:** expected Recall@10 = 0.0909 (= 10/110); empirical mean over 1000 seeded permutations = 0.0810 (2.5th percentile 0.000, 97.5th percentile 1.000). This confirms the pool size and ranking are correct — a broken pool would give ≈0.5 or ≈0.0.

**Precision sanity:** maximum Precision@10 across models = 0.090, which cannot exceed 0.1 with one relevant CV per JD → PASS.

## Stage 6 — error analysis

| Check | Expected | Actual | Status |
|---|---|---|---|
| Every JD reviewed | 10 | 10 | PASS |
| Every miss has a category | yes | 10 rows categorised | PASS |
| Case studies with heatmaps | ≥ 3 | 4 | PASS |
| AE vs TF-IDF comparison | present | `results/tables/ae_vs_tfidf.csv` | PASS |
| Recommendations | ≥ 8 | 10 | PASS |
| Limitations documented | yes | `results/error_analysis.md` §8 | PASS |

**Failure taxonomy (M3 misses):** `E1` extraction_missing_skill ×2, `E5` seniority_years_mismatch ×4.

## Stage 7 — website and figures

| Check | Expected | Actual | Status |
|---|---|---|---|
| Streamlit pages | 5 | 5 (`app.py` + `pages/1…5`) — all load with no exception via `streamlit.testing` | PASS |
| PNG figures | ≥ 12 | 30 | PASS |
| Resolution | ≥ 200 dpi | 200 dpi | PASS |
| Required figures missing | 0 | 0 | PASS |
| Offline (no CDN/fonts) | yes | no external references in `app.py`/`pages/` | PASS |
| Missing-artifact handling | graceful | `src.web.require` shows the stage to run | PASS |
| Standalone report | `results/report.html` | generated | PASS |
| Website screenshots | 5 | 5 captured with headless Edge over CDP | PASS |

**Figure inventory:** `01_pipeline_diagram.png`, `02_dataset_overview.png`, `03_keyword_cluster_network.png`, `04_keyword_cluster_sizes.png`, `05_keyword_merge_examples.png`, `05b_keyword_coverage_heatmap.png`, `06_ae_architecture.png`, `07_ae_loss_curves.png`, `08_ae_reconstruction_error.png`, `08b_ae_reconstruction_examples.png`, `09_latent_space_pca.png`, `10_latent_space_tsne.png`, `11_recall_by_jd.png`, `12_metric_comparison.png`, `13_rank_distribution.png`, `14_score_margin.png`, `15_case_study_keyword_coverage.png`, `16_ae_vs_tfidf_ranks.png`, `17_error_taxonomy.png`, `18_case_study_P01.png`, `18_case_study_P04.png`, `18_case_study_P08.png`, `18_case_study_P10.png`, `19_recommendation_matrix.png`, `20_extraction_quality.png`, `website_autoencoder.png`, `website_errors.png`, `website_keywords.png`, `website_overview.png`, `website_results.png`.

## Deviations from the brief

1. **LLM model.** The brief names `qwen3.5:4b` and `qwen3.8:27b`. Neither is installed on this machine; the only local completion models are `qwen3:8b` and `nomic-embed-text`. All extraction uses **`qwen3:8b`**, a local model. No external provider was contacted at any point. **Impact:** the 8B model is larger than the intended 4B, so extraction quality should be at least as good, but the runtime is higher (≈6 s/document).
2. **Keyword embeddings.** `sentence-transformers` is not installed, so the pipeline falls back in the order the brief specifies and records the method actually used (`ollama` (nomic-embed-text)). The dense embeddings are strongly anisotropic, so the standard **all-but-the-top** correction (remove the first principal component, renormalise) is applied before clustering and before held-out assignment; this is a documented implementation detail of the embedding step, not a change to the protocol.
3. **Agglomerative linkage.** The brief suggests `linkage="average"`. Average linkage on these embeddings produced a few giant heterogeneous clusters, so **complete linkage** is used with the same cosine distance and the same hard guardrails. Cluster counts and the guardrail results are recorded above. A size cap (`max_cluster_size`) recursively re-clusters any oversized cluster so the vocabulary stays interpretable.
4. **Dimensionality reduction figure.** `umap-learn` is not installed, so the manifold view uses t-SNE with perplexity 15–30 as the brief permits, written as `10_latent_space_tsne.png`.
5. **Website screenshots.** Playwright is not installed, so the five `website_*.png` captures are produced by driving headless Microsoft Edge over the DevTools protocol (`scripts/10_capture_screenshots.py`). They are real captures of the running app, not mock-ups.
6. **Primary AE configuration.** The brief pre-registers M3 as AE-32. The ablation found latent 32 / dropout 0.0 with a slightly lower validation MSE than latent 32 / dropout 0.2. The **pre-registered configuration is kept as the primary** model and the validation-selected variant is saved separately (`models/autoencoder_valsel.pt`) and reported as an ablation, so the primary result is never chosen on test recall.
7. **Reconstruction loss.** Plain MSE on L2-normalised sparse TF-IDF rows collapses the bottleneck (the optimum is to predict the mean row, so every document maps to the same latent point — observed and verified). The loss is therefore `MSE + (1 - cosine)`, which keeps the row direction that retrieval actually uses. Both components are logged per epoch.

## Definition-of-done checklist

- [x] Data accounted for; candidate pool 110; ground truth 10 rows
- [x] All 170 documents attempted; success ≥ 95%; failures logged
- [x] 100–200 clusters; ≥50 aliases; guardrails pass
- [x] AE trained on the held-out protocol; model and curves saved
- [x] 10 JDs × 110 candidates ranked for M0–M6; top10 complete
- [x] Recall/Hit/MRR/nDCG/Precision + exact hits + CIs reported
- [x] Independent recomputation matches
- [x] All 10 JDs reviewed; ≥3 case studies; ≥8 recommendations
- [x] >=12 PNG figures at >=200 dpi
- [x] README and VALIDATION complete
- [x] No test-set tuning presented as primary; no significance claims
